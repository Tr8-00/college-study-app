/* Scribe renderer: Markdown + LaTeX (KaTeX) + chemistry (\ce). Used inside a WebView. */
(function (root) {
  var cache = {};
  function esc(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

  function renderMath(tex, display) {
    var k = (display ? 'D' : 'I') + tex;
    if (cache[k]) return cache[k];
    var html;
    try {
      html = katex.renderToString(tex, { displayMode: display, throwOnError: false, strict: false, output: 'html', trust: false });
    } catch (e) { html = '<code>' + esc(tex) + '</code>'; }
    return (cache[k] = display ? '<div class="math-block">' + html + '</div>' : html);
  }

  function extractMath(md, store) {
    function put(tex, display) { store.push({ tex: tex.trim(), display: display }); return '\u0000M' + (store.length - 1) + '\u0000'; }
    var out = md;
    out = out.replace(/\$\$([\s\S]+?)\$\$/g, function (_, t) { return put(t, true); });
    out = out.replace(/\\\[([\s\S]+?)\\\]/g, function (_, t) { return put(t, true); });
    out = out.replace(/\\\(([\s\S]+?)\\\)/g, function (_, t) { return put(t, false); });
    out = out.replace(/(^|[^\\$\w])\$(?!\s)([^$\n]+?)(?<!\s)\$(?![\d$])/g, function (_, pre, t) { return pre + put(t, false); });
    // bare \ce{...} (chemistry) with balanced braces
    var res = '', i = 0;
    while (i < out.length) {
      var j = out.indexOf('\\ce{', i);
      if (j < 0) { res += out.slice(i); break; }
      res += out.slice(i, j);
      var d = 0, k = j + 3;
      for (; k < out.length; k++) { if (out[k] === '{') d++; else if (out[k] === '}') { d--; if (d === 0) break; } }
      if (d !== 0) { res += out.slice(j); break; }
      res += put(out.slice(j, k + 1), false);
      i = k + 1;
    }
    return res;
  }

  function blocks(md) {
    var math = [];
    md = extractMath(String(md == null ? '' : md), math);
    md = md.replace(/\u0000M(\d+)\u0000/g, function (m, i) { return math[+i].display ? '\n\n' + m + '\n\n' : m; });
    function restore(t) { return t.replace(/\u0000M(\d+)\u0000/g, function (_, i) { var m = math[+i]; return renderMath(m.tex, m.display); }); }
    function inline(t) {
      t = esc(t);
      t = t.replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/(^|[^*\w])\*([^*\s][^*]*?)\*(?![*\w])/g, '$1<em>$2</em>');
      return restore(t);
    }
    var lines = md.replace(/\r/g, '').split('\n'), out = [], i = 0;
    var listRe = /^\s*([-*•]|\d+[.)])\s+(.*)$/;
    while (i < lines.length) {
      var l = lines[i];
      if (!l.trim()) { i++; continue; }
      var m;
      if (/^```/.test(l.trim())) {
        var code = []; i++;
        while (i < lines.length && !/^```/.test(lines[i].trim())) { code.push(lines[i]); i++; }
        i++; out.push('<pre><code>' + esc(code.join('\n')) + '</code></pre>'); continue;
      }
      if ((m = /^(#{1,4})\s+(.*)$/.exec(l))) { out.push('<h' + m[1].length + '>' + inline(m[2]) + '</h' + m[1].length + '>'); i++; continue; }
      if (/^\s*(-{3,}|\*{3,})\s*$/.test(l)) { out.push('<hr>'); i++; continue; }
      if ((m = /^\s*\u0000M(\d+)\u0000\s*$/.exec(l)) && math[+m[1]].display) { out.push(restore(l.trim())); i++; continue; }
      if (l.indexOf('|') >= 0 && i + 1 < lines.length && /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(lines[i + 1])) {
        var cells = function (r) { return r.trim().replace(/^\||\|$/g, '').split('|').map(function (c) { return c.trim(); }); };
        var head = cells(l); i += 2; var rows = [];
        while (i < lines.length && lines[i].indexOf('|') >= 0 && lines[i].trim()) { rows.push(cells(lines[i])); i++; }
        out.push('<div class="tbl"><table><thead><tr>' + head.map(function (c) { return '<th>' + inline(c) + '</th>'; }).join('') + '</tr></thead><tbody>' +
          rows.map(function (r) { return '<tr>' + r.map(function (c) { return '<td>' + inline(c) + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody></table></div>');
        continue;
      }
      if (/^>\s?/.test(l)) {
        var q = [];
        while (i < lines.length && /^>\s?/.test(lines[i])) { q.push(lines[i].replace(/^>\s?/, '')); i++; }
        out.push('<blockquote>' + q.map(inline).join('<br>') + '</blockquote>'); continue;
      }
      if ((m = listRe.exec(l))) {
        var ordered = /\d/.test(m[1]), items = [];
        while (i < lines.length && (m = listRe.exec(lines[i])) && /\d/.test(m[1]) === ordered) { items.push('<li>' + inline(m[2]) + '</li>'); i++; }
        out.push((ordered ? '<ol>' : '<ul>') + items.join('') + (ordered ? '</ol>' : '</ul>')); continue;
      }
      var para = [];
      while (i < lines.length && lines[i].trim() && !/^(#{1,4}\s|```|>\s?)/.test(lines[i]) && !listRe.test(lines[i]) && !/^\s*\u0000M\d+\u0000\s*$/.test(lines[i])) { para.push(lines[i]); i++; }
      if (!para.length) { para.push(lines[i]); i++; }
      out.push('<p>' + para.map(inline).join('<br>') + '</p>');
    }
    return out;
  }

  var lastH = -1;
  function report() {
    var c = document.getElementById('c'); if (!c) return;
    var h = Math.ceil(c.getBoundingClientRect().height) + 4;
    if (h !== lastH) { lastH = h; if (root.ScribeBridge && root.ScribeBridge.h) root.ScribeBridge.h(h); }
  }

  root.setContent = function (md, streaming) {
    var c = document.getElementById('c'), bl = blocks(md), kids = c.children;
    for (var i = 0; i < bl.length; i++) {
      var html = bl[i] + (streaming && i === bl.length - 1 ? '<span class="cursor"></span>' : '');
      if (i < kids.length) { if (kids[i].__h !== html) { kids[i].innerHTML = html; kids[i].__h = html; } }
      else {
        var d = document.createElement('div'); d.className = 'b new'; d.style.animationDelay = Math.min(i * 40, 360) + 'ms';
        d.innerHTML = html; d.__h = html; c.appendChild(d);
      }
    }
    while (c.children.length > bl.length) c.removeChild(c.lastChild);
    if (streaming && bl.length === 0) { /* nothing yet */ }
    report();
  };
  root.setTheme = function (o) {
    var s = document.documentElement.style;
    for (var k in o) if (k === 'dir') document.documentElement.dir = o[k]; else s.setProperty('--' + k, o[k]);
    report();
  };
  if (typeof ResizeObserver !== 'undefined') document.addEventListener('DOMContentLoaded', function () { new ResizeObserver(report).observe(document.getElementById('c')); });
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(report);
  root.__blocks = blocks;
})(typeof window !== 'undefined' ? window : globalThis);
