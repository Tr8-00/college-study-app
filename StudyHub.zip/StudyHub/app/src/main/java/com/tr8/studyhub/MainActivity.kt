package com.tr8.studyhub

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudyApp() }
    }
}

@Composable
fun StudyApp() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx.applicationContext) }
    var tab by remember { mutableIntStateOf(0) }
    var openId by remember { mutableStateOf<String?>(null) }
    BackHandler(enabled = openId != null) { openId = null }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Teal, background = Navy, surface = CardBg,
            onBackground = Cream, onSurface = Cream, onPrimary = Navy,
            surfaceVariant = CardBg, onSurfaceVariant = Cream
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Navy, contentColor = Cream) {
            val sub = store.data.subjects.firstOrNull { it.id == openId }
            if (sub != null) {
                SubjectScreen(store, sub) { openId = null }
            } else {
                val tabs = listOf("📚" to "Courses", "🗓" to "Schedule", "⚙" to "Settings")
                Scaffold(
                    containerColor = Navy,
                    bottomBar = {
                        NavigationBar(containerColor = CardBg) {
                            tabs.forEachIndexed { i, t ->
                                NavigationBarItem(
                                    selected = tab == i, onClick = { tab = i },
                                    icon = { Text(t.first, fontSize = 20.sp) }, label = { Text(t.second) }
                                )
                            }
                        }
                    }
                ) { pad ->
                    Box(Modifier.padding(pad).statusBarsPadding().fillMaxSize()) {
                        when (tab) {
                            0 -> CoursesTab(store) { openId = it }
                            1 -> ScheduleTab(store)
                            else -> SettingsTab(store)
                        }
                    }
                }
            }
        }
    }
}

/* ---------------- Courses ---------------- */

@Composable
fun TodayCard(store: Store) {
    val today = LocalDate.now().dayOfWeek.value
    val list = store.data.slots.filter { it.day == today }.sortedBy { it.time }
    Panel("Today · ${DAYS[today - 1]}", Gold) {
        if (list.isEmpty()) {
            Text("Nothing scheduled. Add class times in the Schedule tab.", fontSize = 14.sp, color = Cream.copy(alpha = 0.7f))
        } else list.forEach { sl ->
            val n = store.data.subjects.firstOrNull { it.id == sl.subjectId }?.name ?: "?"
            Text("${sl.time}   $n (${kindLabel(sl.kind)})" + if (sl.place.isNotEmpty()) " · ${sl.place}" else "", fontSize = 15.sp)
        }
    }
}

@Composable
fun CoursesTab(store: Store, onOpen: (String) -> Unit) {
    var year by remember { mutableIntStateOf(1) }
    var sem by remember { mutableIntStateOf(1) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Subject?>(null) }
    val subs = store.data.subjects.filter { it.year == year && it.sem == sem }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Serif("Study Hub", 28.sp) }
        item { TodayCard(store) }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (1..5).forEach { y -> FilterChip(selected = year == y, onClick = { year = y }, label = { Text("Year $y") }) }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (1..2).forEach { s -> FilterChip(selected = sem == s, onClick = { sem = s }, label = { Text("Semester $s") }) }
            }
        }
        if (subs.isEmpty()) {
            item { Text("No subjects yet for Year $year, Semester $sem.", color = Cream.copy(alpha = 0.7f)) }
        }
        items(subs, key = { it.id }) { s ->
            val count = store.data.items.count { it.subjectId == s.id }
            Card(
                Modifier.fillMaxWidth().clickable { onOpen(s.id) },
                colors = CardDefaults.cardColors(containerColor = CardBg)
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Serif(s.name, 18.sp)
                        Text(
                            listOfNotNull("Lecture".takeIf { s.lecture }, "Section".takeIf { s.section }, "Lab".takeIf { s.lab }).joinToString(" • ") +
                                "  ·  $count file" + if (count == 1) "" else "s",
                            fontSize = 12.sp, color = Cream.copy(alpha = 0.7f)
                        )
                    }
                    TextButton(onClick = { deleting = s }) { Text("✕", color = Rose) }
                }
            }
        }
        item { Button(onClick = { adding = true }) { Text("+ Add subject") } }
    }

    if (adding) AddSubjectDialog(
        onDismiss = { adding = false },
        onAdd = { n, l, s, lab -> store.addSubject(n, year, sem, l, s, lab); adding = false }
    )
    deleting?.let { d ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete ${d.name}?") },
            text = { Text("This removes its files, notes and class times from this phone.") },
            confirmButton = { TextButton(onClick = { store.deleteSubject(d.id); deleting = null }) { Text("Delete", color = Rose) } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun AddSubjectDialog(onDismiss: () -> Unit, onAdd: (String, Boolean, Boolean, Boolean) -> Unit) {
    var name by remember { mutableStateOf("") }
    var l by remember { mutableStateOf(true) }
    var s by remember { mutableStateOf(true) }
    var lab by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add subject") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Subject name") }, singleLine = true)
                Text("What does it have each week?", fontSize = 13.sp, color = Cream.copy(alpha = 0.7f))
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(l, { l = it }); Text("Lecture") }
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(s, { s = it }); Text("Section / sheet") }
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(lab, { lab = it }); Text("Lab") }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (name.isNotBlank() && (l || s || lab)) onAdd(name, l, s, lab) }) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/* ---------------- Subject / weeks ---------------- */

@Composable
fun SubjectScreen(store: Store, sub: Subject, onBack: () -> Unit) {
    var week by remember { mutableIntStateOf(1) }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Back", color = Teal) }
            Serif(sub.name, 20.sp)
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            (1..store.weeks).forEach { w -> FilterChip(selected = week == w, onClick = { week = w }, label = { Text("Week $w") }) }
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            KINDS.filter { (it == "lecture" && sub.lecture) || (it == "section" && sub.section) || (it == "lab" && sub.lab) }
                .forEach { kind -> KindCard(store, sub, week, kind) }
        }
    }
}

@Composable
fun KindCard(store: Store, sub: Subject, week: Int, kind: String) {
    val scope = rememberCoroutineScope()
    val items = store.data.items.filter { it.subjectId == sub.id && it.week == week && it.kind == kind }
    var aiItem by remember { mutableStateOf<Item?>(null) }
    var failed by remember { mutableStateOf(false) }
    val key = noteKey(sub.id, week, kind)
    var text by remember(key) { mutableStateOf(store.data.notes[key] ?: "") }
    LaunchedEffect(key, text) { delay(600); store.setNote(key, text) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        scope.launch { uris.forEach { if (!store.addFile(sub.id, week, kind, it)) failed = true } }
    }

    Panel("${kindLabel(kind)} · Week $week") {
        if (items.isEmpty()) Text("No files yet.", fontSize = 13.sp, color = Cream.copy(alpha = 0.6f))
        items.forEach { it ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(it.name, Modifier.weight(1f).clickable { store.openFile(it) }, fontSize = 14.sp, color = Cream)
                TextButton(onClick = { aiItem = it }) { Text("✨ AI", color = Gold) }
                TextButton(onClick = { store.deleteItem(it) }) { Text("✕", color = Rose) }
            }
        }
        OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text("+ Add files (PDF, photos, slides)") }
        if (failed) Text("Couldn't copy one of the files.", color = Rose, fontSize = 12.sp)
        OutlinedTextField(
            text, { text = it }, Modifier.fillMaxWidth(), label = { Text("My notes") }, minLines = 2
        )
    }

    aiItem?.let { item ->
        AiDialog(store, sub, week, item,
            onSaveNote = { r -> text = (if (text.isBlank()) "" else text + "\n\n") + r },
            onClose = { aiItem = null })
    }
}

/* ---------------- AI ---------------- */

@Composable
fun AiDialog(store: Store, sub: Subject, week: Int, item: Item, onSaveNote: (String) -> Unit, onClose: () -> Unit) {
    var result by remember { mutableStateOf<String?>(null) }
    var action by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    var question by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun run(a: String) {
        if (store.apiKey.isBlank()) { err = "Add your free Gemini key in Settings first."; return }
        val mime = mimeOf(item.name)
        if (mime !in AI_MIMES) { err = "AI can read PDFs, photos and text. Export PPTX / Word files as PDF first."; return }
        if (a == "ask" && question.isBlank()) { err = "Type your question first."; return }
        val f = File(store.filesDir, item.file)
        if (f.length() > 15_000_000) { err = "File is too large (limit about 15 MB)."; return }
        busy = true; err = null; action = a; saved = false
        scope.launch {
            try {
                val t = withContext(Dispatchers.IO) {
                    Ai.ask(store.apiKey, store.model, Ai.prompt(a, sub.name, week, item.kind, question), f, mime)
                }
                result = Ai.clean(t)
            } catch (e: Exception) {
                err = e.message ?: "Something went wrong."
            }
            busy = false
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onClose() },
        title = { Text(item.name, fontSize = 16.sp, maxLines = 2) },
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val r = result
                if (r == null) {
                    Text("Only this file is sent to Google's Gemini with your own key.", fontSize = 12.sp, color = Cream.copy(alpha = 0.6f))
                    listOf(
                        "summary" to "📋 Summarize + extract formulas", "explain" to "💡 Explain it simply",
                        "solve" to "✅ Solve / review this sheet", "quiz" to "📝 Make a quiz", "cards" to "🃏 Make flashcards"
                    ).forEach { (a, label) ->
                        OutlinedButton(onClick = { run(a) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(label) }
                    }
                    OutlinedTextField(question, { question = it }, label = { Text("Or ask a question about it") }, modifier = Modifier.fillMaxWidth())
                    OutlinedButton(onClick = { run("ask") }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("❓ Ask") }
                    if (busy) { LinearProgressIndicator(Modifier.fillMaxWidth(), color = Teal); Text("Thinking… this can take a minute.", fontSize = 12.sp) }
                    err?.let { Text(it, color = Rose, fontSize = 13.sp) }
                } else {
                    val cards = if (action == "cards") Ai.parseCards(r) else emptyList()
                    if (cards.isNotEmpty()) Flashcards(cards) else SelectionContainer { Text(r, fontSize = 14.sp) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { result = null; err = null }) { Text("‹ Back") }
                        OutlinedButton(onClick = { onSaveNote(r); saved = true }, enabled = !saved) { Text(if (saved) "Saved ✓" else "Save to notes") }
                    }
                }
            }
        }
    )
}

@Composable
fun Flashcards(cards: List<Pair<String, String>>) {
    var i by remember { mutableIntStateOf(0) }
    var flipped by remember { mutableStateOf(false) }
    val c = cards[i]
    Text("Card ${i + 1} of ${cards.size} · tap the card to flip", fontSize = 12.sp, color = Cream.copy(alpha = 0.6f))
    Card(
        Modifier.fillMaxWidth().heightIn(min = 150.dp).clickable { flipped = !flipped },
        colors = CardDefaults.cardColors(containerColor = if (flipped) Teal else Navy)
    ) {
        Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
            Serif(if (flipped) c.second else c.first, 16.sp, if (flipped) Navy else Cream, align = TextAlign.Center)
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { if (i > 0) { i--; flipped = false } }, enabled = i > 0) { Text("‹ Prev") }
        OutlinedButton(onClick = { if (i < cards.size - 1) { i++; flipped = false } }, enabled = i < cards.size - 1) { Text("Next ›") }
    }
}

/* ---------------- Schedule ---------------- */

@Composable
fun ScheduleTab(store: Store) {
    var adding by remember { mutableStateOf(false) }
    val today = LocalDate.now().dayOfWeek.value
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Serif("Weekly schedule", 28.sp)
                Button(onClick = { adding = true }, enabled = store.data.subjects.isNotEmpty()) { Text("+ Add class time") }
                if (store.data.subjects.isEmpty()) Text("Add a subject in the Courses tab first.", color = Cream.copy(alpha = 0.7f))
            }
        }
        for (d in 1..7) {
            val list = store.data.slots.filter { it.day == d }.sortedBy { it.time }
            if (list.isNotEmpty()) {
                item(key = "day$d") {
                    Serif(DAYS[d - 1] + if (d == today) "  (today)" else "", 18.sp, if (d == today) Gold else Teal, Modifier.padding(top = 8.dp))
                }
                items(list, key = { it.id }) { sl ->
                    val n = store.data.subjects.firstOrNull { it.id == sl.subjectId }?.name ?: "?"
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(sl.time, color = Teal, fontSize = 16.sp, modifier = Modifier.width(60.dp))
                        Column(Modifier.weight(1f)) {
                            Text("$n · ${kindLabel(sl.kind)}", fontSize = 15.sp)
                            if (sl.place.isNotEmpty()) Text(sl.place, fontSize = 12.sp, color = Cream.copy(alpha = 0.6f))
                        }
                        TextButton(onClick = { store.deleteSlot(sl.id) }) { Text("✕", color = Rose) }
                    }
                }
            }
        }
    }
    if (adding) AddSlotDialog(store) { adding = false }
}

@Composable
fun AddSlotDialog(store: Store, onClose: () -> Unit) {
    var subId by remember { mutableStateOf(store.data.subjects.first().id) }
    var day by remember { mutableIntStateOf(1) }
    var kind by remember { mutableStateOf("lecture") }
    var time by remember { mutableStateOf("09:00") }
    var place by remember { mutableStateOf("") }
    var bad by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Add class time") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Subject", fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    store.data.subjects.forEach { s -> FilterChip(selected = subId == s.id, onClick = { subId = s.id }, label = { Text(s.name) }) }
                }
                Text("Day", fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DAYS.forEachIndexed { i, d -> FilterChip(selected = day == i + 1, onClick = { day = i + 1 }, label = { Text(d) }) }
                }
                Text("Type", fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    KINDS.forEach { k -> FilterChip(selected = kind == k, onClick = { kind = k }, label = { Text(kindLabel(k).substringBefore(" ")) }) }
                }
                OutlinedTextField(time, { time = it; bad = false }, label = { Text("Time (24h, like 09:00 or 14:30)") }, singleLine = true, isError = bad)
                OutlinedTextField(place, { place = it }, label = { Text("Room / place (optional)") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val m = Regex("^([01]?\\d|2[0-3]):([0-5]\\d)$").matchEntire(time.trim())
                if (m == null) bad = true
                else {
                    store.addSlot(subId, day, m.groupValues[1].padStart(2, '0') + ":" + m.groupValues[2], kind, place)
                    onClose()
                }
            }) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

/* ---------------- Settings ---------------- */

@Composable
fun SettingsTab(store: Store) {
    val scope = rememberCoroutineScope()
    val uri = LocalUriHandler.current
    var models by remember { mutableStateOf<List<String>>(emptyList()) }
    var msg by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Serif("Settings", 28.sp)
        Panel("Privacy") {
            Text(
                "Your files, notes and schedule are stored only in this app's private storage on your phone. " +
                    "Nothing is sent anywhere unless you tap an AI button, and then only that one file goes to " +
                    "Google's Gemini API using your own key. Google says free-tier content may be used to improve " +
                    "its products, so don't send anything confidential.",
                fontSize = 13.sp
            )
        }
        Panel("AI (optional, free)") {
            Text("Get a free key from Google AI Studio, then paste it here.", fontSize = 13.sp, color = Cream.copy(alpha = 0.75f))
            OutlinedButton(onClick = { uri.openUri("https://aistudio.google.com/app/apikey") }) { Text("Get a free key") }
            OutlinedTextField(
                store.apiKey, { store.apiKey = it; store.saveSettings() }, Modifier.fillMaxWidth(),
                label = { Text("Gemini API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation()
            )
            OutlinedTextField(
                store.model, { store.model = it; store.saveSettings() }, Modifier.fillMaxWidth(),
                label = { Text("Model") }, singleLine = true
            )
            OutlinedButton(
                enabled = !loading && store.apiKey.isNotBlank(),
                onClick = {
                    loading = true; msg = ""
                    scope.launch {
                        try {
                            models = withContext(Dispatchers.IO) { Ai.models(store.apiKey) }
                            msg = if (models.isEmpty()) "Key works, but no models were listed." else "Key works. Tap a model to use it."
                        } catch (e: Exception) { msg = e.message ?: "Couldn't reach Google."; models = emptyList() }
                        loading = false
                    }
                }
            ) { Text(if (loading) "Checking…" else "Test key + list models") }
            if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = if (models.isEmpty()) Rose else Teal)
            models.forEach { m ->
                TextButton(onClick = { store.model = m; store.saveSettings() }) {
                    Text((if (store.model == m) "✓ " else "") + m, color = if (store.model == m) Gold else Cream)
                }
            }
        }
        Panel("Weeks per semester") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = { if (store.weeks > 1) { store.weeks--; store.saveSettings() } }) { Text("−") }
                Text("${store.weeks}", fontSize = 20.sp)
                OutlinedButton(onClick = { if (store.weeks < 30) { store.weeks++; store.saveSettings() } }) { Text("+") }
            }
        }
    }
}
