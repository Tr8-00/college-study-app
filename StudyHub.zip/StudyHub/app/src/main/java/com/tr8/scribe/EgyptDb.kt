package com.tr8.scribe

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Uni(val id: String, val en: String, val ar: String, val type: String, val city: String, val aliases: List<String>, val faculties: List<String>)
data class Major(val en: String, val ar: String)

/** Offline list of Egyptian universities, faculties and majors (bundled in assets/egypt_universities.json). */
object EgyptDb {
    val TYPES = listOf("Public", "Private", "National", "Technological", "International")
    private var unis: List<Uni> = emptyList()
    private var tpl: Map<String, Pair<String, List<Major>>> = emptyMap()
    private var over: Map<String, List<Major>> = emptyMap()

    private fun majorsOf(a: JSONArray): List<Major> = (0 until a.length()).map { a.getJSONObject(it) }.map { Major(it.getString("en"), it.getString("ar")) }
    private fun strs(a: JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).map { a.getString(it) }

    @Synchronized
    private fun ensure(ctx: Context) {
        if (unis.isNotEmpty()) return
        try {
            val o = JSONObject(ctx.assets.open("egypt_universities.json").bufferedReader().use { it.readText() })
            val t = o.getJSONObject("facultyTemplates")
            val m = LinkedHashMap<String, Pair<String, List<Major>>>()
            t.keys().forEach { k -> val f = t.getJSONObject(k); m[k] = f.getString("ar") to majorsOf(f.getJSONArray("majors")) }
            tpl = m
            val ov = o.getJSONObject("overrides")
            val om = HashMap<String, List<Major>>()
            ov.keys().forEach { k -> om[k] = majorsOf(ov.getJSONArray(k)) }
            over = om
            val ua = o.getJSONArray("universities")
            unis = (0 until ua.length()).map { ua.getJSONObject(it) }.map {
                Uni(it.getString("id"), it.getString("en"), it.getString("ar"), it.getString("type"), it.optString("city"), strs(it.optJSONArray("aliases")), strs(it.optJSONArray("faculties")))
            }
        } catch (e: Exception) { }
    }

    fun search(ctx: Context, q: String, type: String): List<Uni> {
        ensure(ctx)
        val tokens = q.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }
        return unis.filter { u ->
            (type.isEmpty() || u.type == type) &&
                (tokens.isEmpty() || (u.en + " " + u.ar + " " + u.aliases.joinToString(" ") + " " + u.city + " " + u.type).lowercase().let { hay -> tokens.all { hay.contains(it) } })
        }.take(40)
    }

    fun find(ctx: Context, name: String): Uni? {
        ensure(ctx)
        val n = name.trim().lowercase()
        if (n.isEmpty()) return null
        return unis.firstOrNull { it.en.lowercase() == n || it.ar == name.trim() } ?: unis.firstOrNull { u -> u.aliases.any { it.lowercase() == n } }
    }

    fun faculties(ctx: Context, uniName: String): List<String> {
        ensure(ctx)
        return find(ctx, uniName)?.faculties?.filter { it in tpl } ?: tpl.keys.toList()
    }

    fun facultyLabel(ctx: Context, key: String, ar: Boolean): String { ensure(ctx); return if (ar) (tpl[key]?.first ?: key) else key }

    fun majors(ctx: Context, uniName: String, faculty: String): List<Major> {
        ensure(ctx)
        val u = find(ctx, uniName)
        return (if (u != null) over[u.id + "|" + faculty] else null) ?: tpl[faculty]?.second ?: emptyList()
    }
}
