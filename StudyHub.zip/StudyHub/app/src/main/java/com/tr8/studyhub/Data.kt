package com.tr8.studyhub

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class Subject(
    val id: String, val name: String, val year: Int, val sem: Int,
    val lecture: Boolean, val section: Boolean, val lab: Boolean
)
data class Item(val id: String, val subjectId: String, val week: Int, val kind: String, val name: String, val file: String)
data class Slot(val id: String, val subjectId: String, val day: Int, val time: String, val kind: String, val place: String)
data class Data(
    val subjects: List<Subject> = emptyList(),
    val items: List<Item> = emptyList(),
    val slots: List<Slot> = emptyList(),
    val notes: Map<String, String> = emptyMap()
)

val KINDS = listOf("lecture", "section", "lab")
val DAYS = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
fun kindLabel(k: String) = when (k) { "lecture" -> "Lecture"; "section" -> "Section / Sheet"; else -> "Lab" }
fun noteKey(subjectId: String, week: Int, kind: String) = "$subjectId|$week|$kind"

fun mimeOf(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
    "pdf" -> "application/pdf"
    "png" -> "image/png"
    "jpg", "jpeg" -> "image/jpeg"
    "webp" -> "image/webp"
    "heic" -> "image/heic"
    "heif" -> "image/heif"
    "txt" -> "text/plain"
    "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    else -> "application/octet-stream"
}

private fun <T> JSONArray?.mapObjs(f: (JSONObject) -> T): List<T> =
    if (this == null) emptyList() else (0 until length()).map { f(getJSONObject(it)) }

/** Everything is stored in this app's private storage on the phone. */
class Store(private val ctx: Context) {
    private val dataFile = File(ctx.filesDir, "studyhub.json")
    val filesDir = File(ctx.filesDir, "files").apply { mkdirs() }
    private val prefs = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var data by mutableStateOf(load())
        private set
    var apiKey by mutableStateOf(prefs.getString("key", "") ?: "")
    var model by mutableStateOf(prefs.getString("model", "gemini-flash-latest") ?: "gemini-flash-latest")
    var weeks by mutableStateOf(prefs.getInt("weeks", 14))

    fun saveSettings() {
        prefs.edit().putString("key", apiKey.trim()).putString("model", model.trim()).putInt("weeks", weeks).apply()
    }

    private fun load(): Data = try {
        if (!dataFile.exists()) Data() else {
            val o = JSONObject(dataFile.readText())
            val notes = HashMap<String, String>()
            o.optJSONObject("notes")?.let { n -> n.keys().forEach { k -> notes[k] = n.getString(k) } }
            Data(
                o.optJSONArray("subjects").mapObjs {
                    Subject(it.getString("id"), it.getString("name"), it.getInt("year"), it.getInt("sem"),
                        it.getBoolean("lecture"), it.getBoolean("section"), it.getBoolean("lab"))
                },
                o.optJSONArray("items").mapObjs {
                    Item(it.getString("id"), it.getString("subjectId"), it.getInt("week"), it.getString("kind"),
                        it.getString("name"), it.getString("file"))
                },
                o.optJSONArray("slots").mapObjs {
                    Slot(it.getString("id"), it.getString("subjectId"), it.getInt("day"), it.getString("time"),
                        it.getString("kind"), it.getString("place"))
                },
                notes
            )
        }
    } catch (e: Exception) { Data() }

    private fun update(d: Data) {
        data = d
        val o = JSONObject()
        o.put("subjects", JSONArray().also { a -> d.subjects.forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("year", it.year).put("sem", it.sem)
                .put("lecture", it.lecture).put("section", it.section).put("lab", it.lab)) } })
        o.put("items", JSONArray().also { a -> d.items.forEach {
            a.put(JSONObject().put("id", it.id).put("subjectId", it.subjectId).put("week", it.week)
                .put("kind", it.kind).put("name", it.name).put("file", it.file)) } })
        o.put("slots", JSONArray().also { a -> d.slots.forEach {
            a.put(JSONObject().put("id", it.id).put("subjectId", it.subjectId).put("day", it.day)
                .put("time", it.time).put("kind", it.kind).put("place", it.place)) } })
        val n = JSONObject()
        d.notes.forEach { (k, v) -> n.put(k, v) }
        o.put("notes", n)
        dataFile.writeText(o.toString())
    }

    fun addSubject(name: String, year: Int, sem: Int, lecture: Boolean, section: Boolean, lab: Boolean) {
        update(data.copy(subjects = data.subjects + Subject(UUID.randomUUID().toString(), name.trim(), year, sem, lecture, section, lab)))
    }

    fun deleteSubject(id: String) {
        data.items.filter { it.subjectId == id }.forEach { File(filesDir, it.file).delete() }
        update(Data(
            data.subjects.filter { it.id != id }, data.items.filter { it.subjectId != id },
            data.slots.filter { it.subjectId != id }, data.notes.filterKeys { !it.startsWith("$id|") }
        ))
    }

    suspend fun addFile(subjectId: String, week: Int, kind: String, uri: Uri): Boolean = try {
        val (name, fname) = withContext(Dispatchers.IO) {
            var n = "file"
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) n = c.getString(i) ?: "file"
                }
            }
            val id = UUID.randomUUID().toString()
            val f = File(filesDir, id + "_" + n.replace(Regex("[^A-Za-z0-9._-]"), "_"))
            ctx.contentResolver.openInputStream(uri)!!.use { inp -> f.outputStream().use { out -> inp.copyTo(out) } }
            n to f.name
        }
        update(data.copy(items = data.items + Item(UUID.randomUUID().toString(), subjectId, week, kind, name, fname)))
        true
    } catch (e: Exception) { false }

    fun deleteItem(item: Item) {
        File(filesDir, item.file).delete()
        update(data.copy(items = data.items.filter { it.id != item.id }))
    }

    fun setNote(key: String, text: String) {
        if ((data.notes[key] ?: "") == text) return
        update(data.copy(notes = if (text.isEmpty()) data.notes - key else data.notes + (key to text)))
    }

    fun addSlot(subjectId: String, day: Int, time: String, kind: String, place: String) {
        update(data.copy(slots = data.slots + Slot(UUID.randomUUID().toString(), subjectId, day, time, kind, place.trim())))
    }

    fun deleteSlot(id: String) = update(data.copy(slots = data.slots.filter { it.id != id }))

    fun openFile(item: Item) {
        try {
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", File(filesDir, item.file))
            val i = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeOf(item.name))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(ctx, "No app found to open this file.", Toast.LENGTH_SHORT).show()
        }
    }
}
