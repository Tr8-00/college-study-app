package com.tr8.scribe

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date

private fun actionIcon(a: String): String = when (a) {
    "summary" -> "📋"
    "explain" -> "💡"
    "solve" -> "✅"
    "quiz" -> "📝"
    "cards" -> "🃏"
    "ask" -> "❓"
    else -> "💬"
}

@Composable
private fun actionName(a: String): String = when (a) {
    "summary" -> tr("Summary", "ملخص")
    "explain" -> tr("Explain", "شرح")
    "solve" -> tr("Solutions", "حلول")
    "quiz" -> tr("Quiz", "اختبار")
    "cards" -> tr("Cards", "بطاقات")
    "ask" -> tr("Question", "سؤال")
    else -> tr("Chat", "محادثة")
}

private fun preview(t: String): String =
    t.replace('$', ' ').replace(Regex("[#*`\\\\]+"), "").replace(Regex("\\s+"), " ").trim().take(150)

/** "Physics (1) · Week 3 · Section / Sheet · Physics-1_Sem1_Sec3.pdf" */
private fun whereText(store: Store, e: Entry, ar: Boolean): String {
    val parts = ArrayList<String>()
    store.data.subjects.firstOrNull { it.id == e.subjectId }?.let { parts.add(it.name) }
    if (e.week > 0) parts.add((if (ar) "أسبوع " else "Week ") + e.week)
    if (e.kind.isNotEmpty()) parts.add(kindLabel(e.kind, ar))
    val names = e.fileIds.mapNotNull { id -> store.data.items.firstOrNull { it.id == id }?.name }
    if (names.isNotEmpty()) parts.add(names.joinToString(", ").take(60))
    return parts.joinToString(" · ")
}

@Composable
private fun HistoryCard(store: Store, e: Entry, ar: Boolean, fmt: DateFormat, onOpen: () -> Unit) {
    val where = whereText(store, e, ar)
    val status = when (e.status) {
        "queued" -> tr("⏳ Waiting", "⏳ في الانتظار")
        "running" -> tr("⏳ Working…", "⏳ جارٍ العمل…")
        "failed" -> tr("⚠ Failed. Tap to open and redo.", "⚠ فشل. اضغط للفتح والإعادة.")
        else -> ""
    }
    Column(
        Modifier.fillMaxWidth().background(C.card, RoundedCornerShape(16.dp)).clickable { onOpen() }.padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                actionIcon(e.action) + "  " + e.title.ifBlank { actionName(e.action) },
                fontSize = 15.sp, color = C.text, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
            )
            Text(
                if (e.pinned) "📌" else "☆", fontSize = 18.sp, color = C.gold,
                modifier = Modifier.clickable { store.togglePin(e.id) }.padding(6.dp)
            )
        }
        if (where.isNotEmpty()) Text(where, fontSize = 12.sp, color = C.gold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (status.isNotEmpty()) Text(status, fontSize = 12.sp, color = if (e.status == "failed") C.rose else C.dim)
        else if (e.text.isNotBlank()) Text(preview(e.text), fontSize = 12.sp, color = C.dim, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text(fmt.format(Date(e.ts)), fontSize = 11.sp, color = C.dim)
    }
}

/** Every summary, solution, quiz, flashcard set, question and chat answer, with where it came from. */
@Composable
fun HistoryScreen(store: Store) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val ar = store.lang == "ar"
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("") }
    var opened by remember { mutableStateOf<String?>(null) }
    var deleting by remember { mutableStateOf<Entry?>(null) }
    BackHandler(enabled = true) {
        if (opened != null) opened = null else { store.historyOpen = false; store.historyFileId = "" }
    }

    val fileFilter = store.historyFileId
    val fileName = store.data.items.firstOrNull { it.id == fileFilter }?.name ?: ""
    val all = store.data.chat.filter { it.role == "ai" }
    val q = query.trim().lowercase()
    val list = all.filter { e ->
        (fileFilter.isEmpty() || fileFilter in e.fileIds) &&
            (filter.isEmpty() || (filter == "pinned" && e.pinned) || e.action == filter) &&
            (q.isEmpty() || (e.title + " " + whereText(store, e, ar) + " " + e.text).lowercase().contains(q))
    }.sortedWith(compareByDescending<Entry> { it.pinned }.thenByDescending { it.ts })

    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT) }
    val copiedMsg = tr("Copied", "تم النسخ")
    val regenMsg = tr("Working on it again. You'll get a notification when it's ready.", "نعمل عليه مجدداً. سيصلك إشعار عند الانتهاء.")
    val savedMsg = tr("Saved to notes", "تم الحفظ في الملاحظات")
    val searchHint = tr("Search summaries, solutions, subjects, files…", "ابحث في الملخصات والحلول والمواد والملفات…")
    val emptyMsg = if (all.isEmpty())
        tr("Everything you ask Scribe's AI is saved here: summaries, solutions, quizzes, flashcards and chats, each with the subject, week and file it came from.",
            "كل ما تطلبه من ذكاء Scribe يُحفظ هنا: ملخصات وحلول واختبارات وبطاقات ومحادثات، مع المادة والأسبوع والملف الذي جاءت منه.")
    else tr("Nothing matches.", "لا توجد نتائج.")
    val filters = listOf(
        "" to tr("All", "الكل"), "pinned" to "📌", "summary" to "📋", "explain" to "💡", "solve" to "✅",
        "quiz" to "📝", "cards" to "🃏", "ask" to "❓", "chat" to "💬"
    )

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { store.historyOpen = false; store.historyFileId = "" }) { Text("←  " + tr("Back", "رجوع"), color = C.accent) }
            Serif(tr("History", "السجل"), 26.sp, modifier = Modifier.weight(1f))
            Text("${list.size}", color = C.dim, fontSize = 13.sp, modifier = Modifier.padding(end = 8.dp))
        }
        OutlinedTextField(
            query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            singleLine = true, shape = RoundedCornerShape(26.dp), placeholder = { Text(searchHint) }
        )
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            if (fileFilter.isNotEmpty()) FilterChip(true, { store.historyFileId = "" }, { Text("📄 " + fileName.take(24) + "  ✕") })
            filters.forEach { (k, label) -> FilterChip(filter == k, { filter = k }, { Text(label) }) }
        }
        if (list.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth().padding(28.dp), contentAlignment = Alignment.Center) {
                Text(emptyMsg, color = C.dim, fontSize = 14.sp, textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(list, key = { it.id }) { e -> HistoryCard(store, e, ar, fmt) { opened = e.id } }
            }
        }
    }

    val openedEntry = opened?.let { id -> store.data.chat.firstOrNull { it.id == id } }
    openedEntry?.let { e ->
        AlertDialog(
            onDismissRequest = { opened = null },
            confirmButton = { TextButton(onClick = { opened = null }) { Text(tr("Close", "إغلاق")) } },
            title = { Text(actionIcon(e.action) + " " + e.title.ifBlank { actionName(e.action) }, fontSize = 15.sp, maxLines = 3) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val w = whereText(store, e, ar)
                    if (w.isNotEmpty()) Text(w, fontSize = 12.sp, color = C.gold)
                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        if (e.status == "done" && e.text.isNotBlank()) {
                            TextButton(onClick = {
                                clipboard.setText(AnnotatedString(e.text))
                                Toast.makeText(ctx, copiedMsg, Toast.LENGTH_SHORT).show()
                            }) { Text(tr("📋 Copy", "📋 نسخ"), fontSize = 12.sp) }
                            TextButton(onClick = {
                                val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, e.text) }
                                ctx.startActivity(Intent.createChooser(i, null))
                            }) { Text(tr("📤 Share", "📤 مشاركة"), fontSize = 12.sp) }
                            if (e.subjectId.isNotEmpty() && e.action != "chat") TextButton(onClick = {
                                val k = noteKey(e.subjectId, e.week, e.kind)
                                val old = store.data.notes[k] ?: ""
                                store.setNote(k, (if (old.isBlank()) "" else "$old\n\n") + e.text)
                                Toast.makeText(ctx, savedMsg, Toast.LENGTH_SHORT).show()
                            }) { Text(tr("💾 Notes", "💾 ملاحظات"), fontSize = 12.sp) }
                        }
                        if (e.status == "done" || e.status == "failed") TextButton(onClick = {
                            store.retry(e.id); startWork(ctx)
                            Toast.makeText(ctx, regenMsg, Toast.LENGTH_LONG).show()
                            opened = null
                        }) { Text(tr("↻ Redo", "↻ إعادة"), fontSize = 12.sp) }
                        TextButton(onClick = { store.togglePin(e.id) }) { Text(if (e.pinned) tr("📌 Unpin", "📌 إلغاء التثبيت") else tr("☆ Pin", "☆ تثبيت"), fontSize = 12.sp) }
                        TextButton(onClick = { deleting = e }) { Text(tr("🗑 Delete", "🗑 حذف"), fontSize = 12.sp, color = C.rose) }
                    }
                    when (e.status) {
                        "done" -> {
                            val cards = if (e.action == "cards") Ai.parseCards(e.text) else emptyList()
                            if (cards.isNotEmpty()) Flashcards(cards, "h" + e.id) else MathView(e.text, cacheKey = "h" + e.id)
                        }
                        "failed" -> Text(e.text, color = C.rose, fontSize = 14.sp)
                        else -> Text(tr("Still working on this one…", "ما زلنا نعمل على هذا…"), color = C.dim, fontSize = 13.sp)
                    }
                }
            }
        )
    }

    deleting?.let { e ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(tr("Delete this from history?", "حذف هذا من السجل؟")) },
            text = { Text(e.title.ifBlank { actionName(e.action) }, fontSize = 14.sp) },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text(tr("Cancel", "إلغاء")) } },
            confirmButton = {
                TextButton(onClick = { store.deleteEntry(e.id); deleting = null; opened = null }) { Text(tr("Delete", "حذف"), color = C.rose) }
            }
        )
    }
}
