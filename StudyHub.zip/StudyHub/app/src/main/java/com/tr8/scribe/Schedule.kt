package com.tr8.scribe

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.time.LocalDate

data class PSlot(val subject: String, val day: Int, val start: String, val end: String, val room: String, val kind: String)

fun parseDay(s: String): Int {
    val t = s.trim().lowercase()
    return when {
        t.startsWith("mon") || t.contains("اثنين") || t.contains("إثنين") || t.contains("الاثنين") -> 1
        t.startsWith("tue") || t.contains("ثلاثاء") -> 2
        t.startsWith("wed") || t.contains("اربعاء") || t.contains("أربعاء") -> 3
        t.startsWith("thu") || t.contains("خميس") -> 4
        t.startsWith("fri") || t.contains("جمعة") -> 5
        t.startsWith("sat") || t.contains("سبت") -> 6
        t.startsWith("sun") || t.contains("احد") || t.contains("أحد") -> 7
        else -> t.toIntOrNull()?.takeIf { it in 1..7 } ?: 0
    }
}

fun parseTime(s: String): String {
    val m = Regex("(\\d{1,2})[:.](\\d{2})\\s*(am|pm|ص|م)?", RegexOption.IGNORE_CASE).find(s) ?: return ""
    var h = m.groupValues[1].toInt()
    val min = m.groupValues[2]
    val ap = m.groupValues[3].lowercase()
    if ((ap == "pm" || ap == "م") && h < 12) h += 12
    if ((ap == "am" || ap == "ص") && h == 12) h = 0
    return if (h in 0..23) "%02d:%s".format(h, min) else ""
}

fun parseKind(s: String): String {
    val t = s.lowercase()
    return when {
        t.contains("lab") || t.contains("معمل") -> "lab"
        t.contains("sec") || t.contains("tut") || t.contains("سكشن") || t.contains("تمارين") -> "section"
        else -> "lecture"
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimeDialog(initial: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val p = initial.split(":")
    val st = rememberTimePickerState(p.getOrNull(0)?.toIntOrNull() ?: 9, p.getOrNull(1)?.toIntOrNull() ?: 0, false)
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onPick("%02d:%02d".format(st.hour, st.minute)) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Cancel", "إلغاء")) } },
        text = { TimePicker(state = st) }
    )
}

@Composable
fun SlotCard(store: Store, sl: Slot) {
    val ar = store.lang == "ar"
    val n = store.data.subjects.firstOrNull { it.id == sl.subjectId }?.name ?: "?"
    Row(
        Modifier.fillMaxWidth().background(C.card, RoundedCornerShape(18.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.width(92.dp)) {
            Serif(fmtTime(sl.time, ar), 17.sp, C.accent)
            if (sl.end.isNotEmpty()) Text(fmtTime(sl.end, ar), fontSize = 12.sp, color = C.dim)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Serif(n, 18.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                val kc = when (sl.kind) { "lab" -> C.rose; "section" -> C.gold; else -> C.accent }
                Text(kindLabel(sl.kind, ar), fontSize = 12.sp, color = kc, modifier = Modifier.background(kc.copy(alpha = 0.15f), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 2.dp))
                if (sl.place.isNotEmpty()) Text("📍 ${sl.place}", fontSize = 13.sp, color = C.text)
            }
        }
        TextButton(onClick = { store.deleteSlot(sl.id) }) { Text("✕", color = C.rose) }
    }
}

@Composable
fun ScheduleTab(store: Store) {
    val ar = store.lang == "ar"
    val today = LocalDate.now().dayOfWeek.value
    val pager = rememberPagerState(initialPage = today - 1) { 7 }
    val scope = rememberCoroutineScope()
    var adding by remember { mutableStateOf(false) }
    var importing by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        TopBar(store, tr("Schedule", "الجدول"))
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (d in 1..7) {
                val sel = pager.currentPage == d - 1
                val count = store.data.slots.count { it.day == d }
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(if (sel) C.accent else C.card)
                        .clickable { scope.launch { pager.animateScrollToPage(d - 1) } }.padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(dayName(d, ar, true), fontSize = 12.sp, color = if (sel) C.onAccent else C.text)
                    Box(Modifier.padding(vertical = 3.dp).size(6.dp).clip(CircleShape)
                        .background(if (d == today) (if (sel) C.onAccent else C.gold) else Color.Transparent))
                    Text(if (count > 0) "$count" else "-", fontSize = 11.sp, color = if (sel) C.onAccent else C.dim)
                }
            }
        }
        HorizontalPager(pager, Modifier.weight(1f)) { page ->
            val d = page + 1
            val list = store.data.slots.filter { it.day == d }.sortedBy { it.time }
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Serif(dayName(d, ar), 26.sp)
                        if (d == today) Text(tr("Today", "اليوم"), fontSize = 12.sp, color = C.onAccent,
                            modifier = Modifier.background(C.gold, RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 3.dp))
                    }
                }
                if (list.isEmpty()) item { Text(tr("No classes. Enjoy the free time ☕", "لا توجد محاضرات. استمتع بوقتك ☕"), color = C.dim) }
                items(list, key = { it.id }) { sl -> SlotCard(store, sl) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { adding = true }, enabled = store.data.subjects.isNotEmpty()) { Text(tr("+ Add class", "+ إضافة محاضرة")) }
            OutlinedButton(onClick = { importing = true }) { Text(tr("📷 Import schedule", "📷 استيراد جدول")) }
        }
        if (store.data.subjects.isEmpty()) Text(tr("Tip: importing a schedule creates the subjects for you.", "نصيحة: استيراد الجدول ينشئ المواد تلقائياً."), Modifier.padding(horizontal = 16.dp, vertical = 4.dp), fontSize = 12.sp, color = C.dim)
    }
    if (adding) AddSlotDialog(store, pager.currentPage + 1) { adding = false }
    if (importing) ImportScheduleDialog(store) { importing = false }
}

@Composable
fun AddSlotDialog(store: Store, initialDay: Int, onClose: () -> Unit) {
    val ar = store.lang == "ar"
    var subId by remember { mutableStateOf(store.data.subjects.first().id) }
    var day by remember { mutableIntStateOf(initialDay) }
    var kind by remember { mutableStateOf("lecture") }
    var start by remember { mutableStateOf("09:00") }
    var end by remember { mutableStateOf("10:30") }
    var place by remember { mutableStateOf("") }
    var picking by remember { mutableIntStateOf(0) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(tr("Add class", "إضافة محاضرة")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("Subject", "المادة"), fontSize = 12.sp, color = C.dim)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    store.data.subjects.forEach { s -> FilterChip(subId == s.id, { subId = s.id }, { Text(s.name) }) }
                }
                Text(tr("Day", "اليوم"), fontSize = 12.sp, color = C.dim)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (1..7).forEach { d -> FilterChip(day == d, { day = d }, { Text(dayName(d, ar, true)) }) }
                }
                Text(tr("Type", "النوع"), fontSize = 12.sp, color = C.dim)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SLOT_KINDS.forEach { k -> FilterChip(kind == k, { kind = k }, { Text(kindLabel(k, ar).substringBefore(" ")) }) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { picking = 1 }) { Text(tr("Starts ", "تبدأ ") + fmtTime(start, ar)) }
                    OutlinedButton(onClick = { picking = 2 }) { Text(tr("Ends ", "تنتهي ") + fmtTime(end, ar)) }
                }
                OutlinedTextField(place, { place = it }, label = { Text(tr("Room / place", "القاعة / المكان")) }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { store.addSlot(subId, day, start, end, kind, place); onClose() }) { Text(tr("Add", "إضافة")) } },
        dismissButton = { TextButton(onClick = onClose) { Text(tr("Cancel", "إلغاء")) } }
    )
    if (picking != 0) TimeDialog(if (picking == 1) start else end, { t -> if (picking == 1) start = t else end = t; picking = 0 }) { picking = 0 }
}

data class EditRow(val subject: String, val day: Int, val start: String, val end: String, val room: String, val kind: String, val code: String, val on: Boolean = true)

private fun aiSchedule(store: Store, ctx: Context, uri: Uri): List<ParsedSlot> {
    val mime = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
    if (mime !in AI_MIMES) throw Exception("Choose a photo or PDF of your schedule.")
    val f = File(ctx.cacheDir, "schedule_import")
    ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
    val prompt = "This is a university class timetable (photo or PDF). Extract every class. Return ONLY a JSON array. " +
        "Each item: {\"subject\":\"name\",\"day\":\"Monday\",\"start\":\"HH:mm\",\"end\":\"HH:mm\",\"room\":\"room or building, or empty\",\"type\":\"lecture or section or lab\"}. " +
        "Use 24-hour times and English day names. Keep subject names as written."
    val t = Ai.ask(store.apiKey, store.model, prompt, f, mime, json = true)
    f.delete()
    val arr = JSONArray(Ai.extractJson(t))
    return (0 until arr.length()).map { arr.getJSONObject(it) }.mapNotNull {
        val d = parseDay(it.optString("day"))
        val st = parseTime(it.optString("start"))
        if (d == 0 || st.isEmpty() || it.optString("subject").isBlank()) null
        else ParsedSlot(it.getString("subject").trim(), d, st, parseTime(it.optString("end")).ifEmpty { st }, it.optString("room"), parseKind(it.optString("type")), "")
    }
}

private fun matchSubject(store: Store, name: String, code: String): Subject? {
    fun toks(x: String) = x.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 3 }.toSet()
    val a = toks(name)
    var best: Subject? = null
    var bestScore = 0.0
    for (s in store.data.subjects) {
        if (s.name.equals(name, true)) return s
        if (code.isNotEmpty() && s.name.contains(code, true)) return s
        val b = toks(s.name)
        if (a.isEmpty() || b.isEmpty()) continue
        val sc = a.intersect(b).size.toDouble() / maxOf(a.size, b.size)
        if (sc > bestScore) { bestScore = sc; best = s }
    }
    return if (bestScore >= 0.6) best else null
}

@Composable
fun ImportScheduleDialog(store: Store, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val ar = store.lang == "ar"
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }
    var rows by remember { mutableStateOf<List<EditRow>>(emptyList()) }
    var lastUri by remember { mutableStateOf<Uri?>(null) }
    val none = tr("I couldn't recognize a timetable in that file. Try a clearer photo or the PDF, or add classes by hand.", "لم أتعرف على جدول في هذا الملف. جرّب صورة أوضح أو ملف PDF، أو أضف المحاضرات يدوياً.")
    fun toRows(r: List<ParsedSlot>) = r.map { EditRow(it.subject, it.day, it.start, it.end, it.room, it.kind, it.code) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            lastUri = uri; busy = true; err = ""
            scope.launch {
                try {
                    val r = LocalImport.readTimetable(ctx, uri)
                    rows = toRows(r)
                    if (r.isEmpty()) err = none
                } catch (e: Exception) { err = e.message ?: "Error" }
                busy = false
            }
        }
    }
    AlertDialog(
        onDismissRequest = { if (!busy) onClose() },
        title = { Text(tr("Import schedule", "استيراد الجدول")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (rows.isEmpty()) {
                    Text(tr("Pick a photo, PDF or Word file of your timetable. Scribe reads it on your phone with no internet and no key. Photos in English work; for Arabic timetables use a PDF.", "اختر صورة أو PDF أو Word لجدولك. يقرأه Scribe على هاتفك بدون إنترنت وبدون مفتاح. الصور الإنجليزية تعمل، وللجداول العربية استخدم ملف PDF."), fontSize = 13.sp, color = C.dim)
                    OutlinedButton(onClick = { picker.launch(arrayOf("image/*", "application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/plain")) }, enabled = !busy) { Text(tr("Choose file", "اختر ملفاً")) }
                    if (busy) { LinearProgressIndicator(Modifier.fillMaxWidth(), color = C.accent); Text(tr("Reading your schedule…", "جارٍ قراءة الجدول…"), fontSize = 12.sp) }
                } else {
                    Text(tr("Found ${rows.size} classes. Fix any name or room, untick what you don't want.", "تم العثور على ${rows.size} محاضرة. صحّح أي اسم أو قاعة وألغِ ما لا تريده."), fontSize = 13.sp, color = C.dim)
                    rows.forEachIndexed { i, r ->
                        Column(Modifier.fillMaxWidth().background(C.bg.copy(alpha = 0.5f), RoundedCornerShape(12.dp)).padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(r.on, { c -> rows = rows.mapIndexed { j, x -> if (j == i) x.copy(on = c) else x } })
                                Text("${dayName(r.day, ar, true)} ${fmtTime(r.start, ar)}–${fmtTime(r.end, ar)} · ${kindLabel(r.kind, ar)}", fontSize = 12.sp, color = C.accent)
                            }
                            OutlinedTextField(r.subject, { v -> rows = rows.mapIndexed { j, x -> if (j == i) x.copy(subject = v) else x } }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(tr("Subject", "المادة")) })
                            OutlinedTextField(r.room, { v -> rows = rows.mapIndexed { j, x -> if (j == i) x.copy(room = v) else x } }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(tr("Room", "القاعة")) })
                        }
                    }
                }
                if (err.isNotEmpty()) Text(err, color = C.rose, fontSize = 13.sp)
                val u = lastUri
                if (err.isNotEmpty() && store.apiKey.isNotBlank() && u != null && !busy) {
                    TextButton(onClick = {
                        busy = true; err = ""
                        scope.launch {
                            try { val r = withContext(Dispatchers.IO) { aiSchedule(store, ctx, u) }; rows = toRows(r); if (r.isEmpty()) err = none }
                            catch (e: Exception) { err = e.message ?: "Error" }
                            busy = false
                        }
                    }) { Text(tr("Try again with AI (optional)", "حاول بالذكاء الاصطناعي (اختياري)"), color = C.dim) }
                }
            }
        },
        confirmButton = {
            if (rows.isNotEmpty()) TextButton(onClick = {
                val p = store.data.profile
                rows.filter { it.on && it.subject.isNotBlank() }.forEach { r ->
                    var sub = matchSubject(store, r.subject, r.code)
                    if (sub == null) {
                        store.addSubject(r.subject, p.year, p.sem, true, true, r.kind == "lab")
                        sub = store.data.subjects.firstOrNull { it.name.equals(r.subject, true) && it.year == p.year && it.sem == p.sem }
                    }
                    if (sub != null) store.addSlot(sub.id, r.day, r.start, r.end, r.kind, r.room.trim())
                }
                onClose()
            }) { Text(tr("Import", "استيراد")) }
        },
        dismissButton = { TextButton(onClick = { if (!busy) onClose() }) { Text(tr("Cancel", "إلغاء")) } }
    )
}
