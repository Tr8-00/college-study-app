package com.tr8.studyhub

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Navy = Color(0xFF0B1B2B)
val CardBg = Color(0xFF13293D)
val Cream = Color(0xFFF3E9D2)
val Teal = Color(0xFF2BB5A5)
val Gold = Color(0xFFE9B949)
val Rose = Color(0xFFE07A8F)

@Composable
fun Serif(text: String, size: TextUnit = 16.sp, color: Color = Cream, modifier: Modifier = Modifier, align: TextAlign? = null) {
    Text(text, fontFamily = FontFamily.Serif, fontSize = size, color = color, modifier = modifier, textAlign = align)
}

@Composable
fun Panel(title: String, titleColor: Color = Teal, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(CardBg, RoundedCornerShape(18.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Serif(title, 18.sp, titleColor)
        content()
    }
}
