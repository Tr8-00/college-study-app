package com.tr8.scribe

import java.security.MessageDigest
import kotlin.math.ln
import kotlin.math.sqrt

data class StudyCard(
    val id: String, val type: String, val front: String, val back: String, val term: String, val sentence: String,
    val lhs: String, val rhs: String, val subjectId: String, val itemId: String, val week: Int
)
data class Hit(val itemId: String?, val title: String, val place: String, val page: Int, val snippet: String, val score: Double)
data class Q(val kind: String, val prompt: String, val options: List<String>, val answer: Int, val explain: String, val cardId: String)

private const val D = "$"
private const val DD = "$$"

/** Study tools that run entirely on the phone: no AI, no internet, no limits. They use the text Scribe already scanned from your files. */
object StudyKit {
    private fun hash(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).take(6).joinToString("") { "%02x".format(it) }

    /* ---------------- definitions & laws ---------------- */
    private val defA = Regex("^(?:definition\\s*[:.\\-–]\\s*)?(.{2,70}?)\\s+(?:is|are)\\s+(?:defined as|called|known as|termed)\\s+(.+)$", RegexOption.IGNORE_CASE)
    private val defB = Regex("^(.{2,70}?)\\s+(?:refers to|means)\\s+(.+)$", RegexOption.IGNORE_CASE)
    private val defC = Regex("^.{8,}?\\s+(?:is|are)\\s+(?:called|known as|termed)\\s+(?:the\\s+|a\\s+|an\\s+)?([A-Za-z][\\w\\- ]{1,40}?)[.,;]?$", RegexOption.IGNORE_CASE)
    private val lawA = Regex("([A-Z][\\w’']*(?:\\s+[A-Z][\\w’']*){0,4}\\s+(?:Law|Theorem|Principle|Rule|Equation|Postulate|Lemma|Hypothesis))")
    private val lawB = Regex("((?:Law|Theorem|Principle|Rule) of [A-Z][\\w ]{2,30}?)(?=[ ,.;:]|$)")

    private fun clean(t: String) = t.replace(Regex("^(the|a|an)\\s+", RegexOption.IGNORE_CASE), "").trim().trimEnd(':', ',', '.', ';')

    /** Splits "X is defined as Y" into (term, full sentence). */
    fun defOf(sentence: String): Pair<String, String>? {
        val s = sentence.trim()
        defA.find(s)?.let { m -> val t = clean(m.groupValues[1]); if (t.length >= 2 && t.split(" ").size <= 5) return t to s }
        defB.find(s)?.let { m -> val t = clean(m.groupValues[1]); if (t.length >= 2 && t.split(" ").size <= 5) return t to s }
        defC.find(s)?.let { m -> val t = clean(m.groupValues[1]); if (t.length >= 2 && t.split(" ").size <= 4) return t to s }
        return null
    }

    fun lawName(sentence: String): String? =
        (lawA.find(sentence) ?: lawB.find(sentence))?.groupValues?.get(1)?.trim()?.takeIf { it.length in 6..50 }

    /* ---------------- flashcards ---------------- */
    fun cards(store: Store, subjectId: String): List<StudyCard> {
        val out = LinkedHashMap<String, StudyCard>()
        for (item in store.data.items) {
            if (subjectId.isNotEmpty() && item.subjectId != subjectId) continue
            val sc = store.loadScan(item.id) ?: continue
            if (sc.scanned) continue
            for (d in sc.definitions) {
                val p = defOf(d) ?: continue
                val id = hash("d|${item.subjectId}|${p.first.lowercase()}")
                out.putIfAbsent(id, StudyCard(id, "def", "What is **${p.first}**?", p.second, p.first, p.second, "", "", item.subjectId, item.id, item.week))
            }
            for (l in sc.laws) {
                val name = lawName(l) ?: continue
                val id = hash("l|${item.subjectId}|${name.lowercase()}")
                out.putIfAbsent(id, StudyCard(id, "law", "State **$name**.", l, name, l, "", "", item.subjectId, item.id, item.week))
            }
            for (f in sc.formulas) {
                val i = f.indexOf('=')
                if (i <= 0) continue
                val lhs = f.substring(0, i).trim()
                val rhs = f.substring(i + 1).trim().trimStart('=', ' ')
                if (lhs.length !in 1..14 || rhs.length !in 2..60 || lhs.split(" ").size > 3) continue
                val id = hash("f|${item.subjectId}|$lhs|$rhs")
                out.putIfAbsent(id, StudyCard(id, "formula", "Write the formula for " + D + Scanner.latexify(lhs) + D, DD + Scanner.latexify("$lhs = $rhs") + DD,
                    lhs, "", lhs, rhs, item.subjectId, item.id, item.week))
            }
        }
        return out.values.toList()
    }

    /* ---------------- quiz (multiple choice built from the cards) ---------------- */
    fun quiz(cards: List<StudyCard>, n: Int, rnd: java.util.Random = java.util.Random()): List<Q> {
        val terms = cards.filter { it.type == "def" || it.type == "law" }.map { it.term }.distinct()
        val rhsAll = cards.filter { it.type == "formula" }.map { Scanner.latexify(it.rhs) }.distinct()
        val out = ArrayList<Q>()
        for (c in cards.shuffled(rnd)) {
            if (out.size >= n) break
            if (c.type == "formula") {
                val right = Scanner.latexify(c.rhs)
                val wrong = rhsAll.filter { it != right }.shuffled(rnd).take(3)
                if (wrong.size < 3) continue
                val opts = (wrong + right).shuffled(rnd)
                out.add(Q("formula", D + Scanner.latexify(c.lhs) + " = \\,?" + D, opts.map { D + it + D }, opts.indexOf(right), c.back, c.id))
            } else {
                if (terms.size < 4) continue
                val blank = c.sentence.replace(Regex(Regex.escape(c.term), RegexOption.IGNORE_CASE), "_____")
                if (blank == c.sentence) continue
                val wrong = terms.filter { !it.equals(c.term, true) }.shuffled(rnd).take(3)
                val opts = (wrong + c.term).shuffled(rnd)
                out.add(Q("term", blank, opts, opts.indexOf(c.term), c.sentence, c.id))
            }
        }
        return out
    }

    /* ---------------- search ---------------- */
    private fun stem(w: String): String {
        for (suf in listOf("ing", "ed", "es", "s")) if (w.length > suf.length + 3 && w.endsWith(suf)) return w.dropLast(suf.length)
        return w
    }

    fun terms(q: String): List<String> = q.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 2 }.map { stem(it) }.distinct()

    fun search(store: Store, q: String, subjectId: String): List<Hit> {
        val ts = terms(q)
        if (ts.isEmpty()) return emptyList()
        val need = maxOf(1, Math.ceil(ts.size * 0.6).toInt())
        val phrase = q.trim().lowercase()
        val hits = ArrayList<Hit>()
        for (item in store.data.items) {
            if (subjectId.isNotEmpty() && item.subjectId != subjectId) continue
            val pages = store.loadPages(item.id) ?: continue
            val sub = store.data.subjects.firstOrNull { it.id == item.subjectId }
            for ((pi, p) in pages.withIndex()) {
                if (p.isBlank()) continue
                val low = p.lowercase()
                var matched = 0
                var score = 0.0
                var first = Int.MAX_VALUE
                for (t in ts) {
                    val c = low.split(t).size - 1
                    if (c > 0) { matched++; score += 2 + ln(1.0 + c); first = minOf(first, low.indexOf(t)) }
                }
                if (matched < need) continue
                if (ts.size > 1 && low.contains(phrase)) score += 3
                val flat = p.replace(Regex("\\s+"), " ")
                val at = maxOf(0, minOf(first, flat.length - 1) - 90)
                val snip = (if (at > 0) "…" else "") + flat.substring(at, minOf(flat.length, at + 260)) + (if (at + 260 < flat.length) "…" else "")
                hits.add(Hit(item.id, item.name, (sub?.name ?: "?") + " · " + kindAbbr(item.kind) + item.week, pi + 1, snip, score))
            }
        }
        for ((k, text) in store.data.notes) {
            val low = text.lowercase()
            if (ts.count { low.contains(it) } < need) continue
            val parts = k.split("|")
            val sub = store.data.subjects.firstOrNull { it.id == parts.getOrNull(0) } ?: continue
            if (subjectId.isNotEmpty() && sub.id != subjectId) continue
            val flat = text.replace(Regex("\\s+"), " ")
            val first = ts.map { low.indexOf(it) }.filter { it >= 0 }.minOrNull() ?: 0
            val at = maxOf(0, first - 90)
            hits.add(Hit(null, "📝 " + sub.name, sub.name + " · " + (parts.getOrNull(2) ?: "") + (parts.getOrNull(1) ?: ""), 0, flat.substring(at, minOf(flat.length, at + 260)), 5.0))
        }
        return hits.sortedByDescending { it.score }.take(40)
    }

    /* ---------------- summaries ---------------- */
    private val stopW = setOf("this", "that", "with", "from", "have", "will", "which", "their", "there", "these", "those", "also", "such", "than", "then", "when", "where", "into", "each", "other", "more", "most", "been", "were", "what", "about", "should", "would", "could", "because", "using", "used")
    private val sentSplit = Regex("(?<=[.!?])\\s+(?=[A-Z0-9(\\[])")

    private fun words(s: String): List<String> = s.lowercase().split(Regex("[^\\p{L}]+")).filter { it.length >= 4 && it !in stopW }

    fun sentences(pages: List<String>): List<String> {
        val out = ArrayList<String>()
        for (p in pages) {
            val text = p.replace(Regex("\\s*\\n\\s*"), " ")
            for (s in text.split(sentSplit)) {
                val t = s.trim()
                if (t.length in 40..320 && t.count { it.isLetter() } > t.length * 0.6) out.add(t)
            }
        }
        return out
    }

    /** Picks the most important sentences (word-frequency scoring) and keeps them in reading order. */
    fun keySentences(pages: List<String>, scan: Scan, n: Int): List<String> {
        val sents = sentences(pages)
        if (sents.isEmpty()) return emptyList()
        val freq = HashMap<String, Int>()
        for (s in sents) for (w in words(s)) freq[w] = (freq[w] ?: 0) + 1
        val kw = scan.keywords.take(6).toSet()
        val scored = sents.mapIndexed { i, s ->
            val ws = words(s)
            var sc = ws.sumOf { freq[it] ?: 0 }.toDouble() / sqrt(ws.size.coerceAtLeast(1).toDouble())
            if (ws.any { it in kw }) sc *= 1.3
            if (defOf(s) != null) sc *= 1.4
            if (i < 3) sc *= 1.15
            i to sc
        }
        return scored.sortedByDescending { it.second }.take(n).sortedBy { it.first }.map { sents[it.first] }
    }

    private fun esc(s: String) = s.replace("$", "\\$")

    /** section: summary | glossary | formulas | questions */
    fun summary(store: Store, item: Item, ar: Boolean, section: String): String {
        val sc = store.loadScan(item.id) ?: return ""
        val pages = store.loadPages(item.id) ?: emptyList()
        val sb = StringBuilder()
        when (section) {
            "summary" -> {
                sb.append("## ").append(sc.title.ifBlank { item.name }).append("\n")
                val ks = keySentences(pages, sc, 9)
                sb.append("\n### ").append(if (ar) "أهم النقاط" else "Key points").append("\n")
                ks.forEach { sb.append("- ").append(esc(it)).append("\n") }
                if (sc.headings.isNotEmpty()) {
                    sb.append("\n### ").append(if (ar) "المواضيع" else "Topics").append("\n")
                    sc.headings.take(14).forEach { sb.append("- ").append(esc(it)).append("\n") }
                }
                if (sc.keywords.isNotEmpty()) sb.append("\n**").append(if (ar) "كلمات مفتاحية: " else "Keywords: ").append("**").append(sc.keywords.joinToString(", ")).append("\n")
            }
            "glossary" -> {
                sb.append("## ").append(if (ar) "المصطلحات" else "Glossary").append("\n")
                val pairs = sc.definitions.mapNotNull { defOf(it) }.sortedBy { it.first.lowercase() }
                pairs.forEach { sb.append("- **").append(it.first).append("** — ").append(esc(it.second)).append("\n") }
                if (pairs.isEmpty()) sb.append(if (ar) "لم أجد تعريفات واضحة في هذا الملف." else "No clear definitions found in this file.")
            }
            "formulas" -> {
                sb.append("## ").append(if (ar) "المعادلات" else "Formulas").append("\n")
                sc.formulas.forEach { sb.append("- ").append(D).append(Scanner.latexify(it)).append(D).append("\n") }
                if (sc.formulas.isEmpty()) sb.append(if (ar) "لم أجد معادلات." else "No formulas found.")
            }
            else -> {
                sb.append("## ").append(if (ar) "الأمثلة والتمارين" else "Examples & exercises").append("\n")
                if (sc.examples.isNotEmpty()) { sb.append("\n### ").append(if (ar) "أمثلة" else "Examples").append("\n"); sc.examples.forEach { sb.append("- ").append(esc(it)).append("\n") } }
                if (sc.exercises.isNotEmpty()) { sb.append("\n### ").append(if (ar) "تمارين" else "Exercises").append("\n"); sc.exercises.forEach { sb.append("- ").append(esc(it)).append("\n") } }
                if (sc.examples.isEmpty() && sc.exercises.isEmpty()) sb.append(if (ar) "لم أجد أمثلة أو تمارين." else "No examples or exercises found.")
            }
        }
        return sb.toString().trim()
    }

    /* ---------------- exam sheet ---------------- */
    fun examSheet(store: Store, subjectId: String, weeks: Set<Int>, ar: Boolean): String {
        val sub = store.data.subjects.firstOrNull { it.id == subjectId } ?: return ""
        val items = store.data.items.filter { it.subjectId == subjectId && (weeks.isEmpty() || it.week in weeks) }.sortedWith(compareBy({ it.week }, { it.kind }))
        val scans = items.mapNotNull { i -> store.loadScan(i.id)?.takeIf { !it.scanned }?.let { i to it } }
        if (scans.isEmpty()) return ""
        fun label(i: Item) = kindLabel(i.kind, ar) + " · " + (if (ar) "أسبوع " else "Week ") + i.week
        val sb = StringBuilder("# ").append(sub.name).append("\n").append(if (ar) "ورقة المراجعة" else "Exam sheet").append("\n")
        fun head(t: String) { sb.append("\n## ").append(t).append("\n") }
        val withF = scans.filter { it.second.formulas.isNotEmpty() }
        if (withF.isNotEmpty()) {
            head(if (ar) "المعادلات" else "Formulas")
            for ((i, sc) in withF) {
                sb.append("\n### ").append(label(i)).append("\n")
                sc.formulas.forEach { sb.append("- ").append(D).append(Scanner.latexify(it)).append(D).append("\n") }
            }
        }
        val defs = scans.flatMap { it.second.definitions }.distinct().map { defOf(it) ?: ("" to it) }.sortedBy { (if (it.first.isNotEmpty()) it.first else it.second).lowercase() }
        if (defs.isNotEmpty()) {
            head(if (ar) "التعريفات" else "Definitions")
            defs.take(80).forEach { (t, s) -> if (t.isNotEmpty()) sb.append("- **").append(t).append("** — ").append(esc(s)).append("\n") else sb.append("- ").append(esc(s)).append("\n") }
        }
        val laws = scans.flatMap { it.second.laws }.distinct()
        if (laws.isNotEmpty()) { head(if (ar) "القوانين والنظريات" else "Laws & theorems"); laws.take(60).forEach { sb.append("- ").append(esc(it)).append("\n") } }
        val ex = scans.filter { it.second.examples.isNotEmpty() }
        if (ex.isNotEmpty()) {
            head(if (ar) "أمثلة محلولة" else "Worked examples")
            for ((i, sc) in ex) { sb.append("\n### ").append(label(i)).append("\n"); sc.examples.take(20).forEach { sb.append("- ").append(esc(it)).append("\n") } }
        }
        val qs = scans.filter { it.second.exercises.isNotEmpty() }
        if (qs.isNotEmpty()) {
            head(if (ar) "تمارين للتدريب" else "Practice exercises")
            for ((i, sc) in qs) { sb.append("\n### ").append(label(i)).append("\n"); sc.exercises.take(20).forEach { sb.append("- ").append(esc(it)).append("\n") } }
        }
        return sb.toString().trim()
    }

    /* ---------------- tracker ---------------- */
    fun doneKey(subjectId: String, week: Int, kind: String) = "$subjectId|$week|$kind"

    /** Weeks that have files but you haven't marked as reviewed, earliest first. */
    fun todo(store: Store, max: Int): List<Triple<Subject, Int, String>> {
        val out = ArrayList<Triple<Subject, Int, String>>()
        for (s in store.data.subjects) for (k in KINDS) {
            val weeks = store.data.items.filter { it.subjectId == s.id && it.kind == k }.map { it.week }.distinct().sorted()
            for (w in weeks) if (doneKey(s.id, w, k) !in store.data.done) out.add(Triple(s, w, k))
        }
        return out.sortedBy { it.second }.take(max)
    }
}
