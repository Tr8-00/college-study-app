package com.tr8.scribe

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs
import kotlin.math.max

/** A piece of text with its position on the page or photo. */
class TLine(val text: String, val x0: Float, val y0: Float, val x1: Float, val y1: Float) {
    val cx: Float get() = (x0 + x1) / 2
    val cy: Float get() = (y0 + y1) / 2
    val w: Float get() = x1 - x0
    val h: Float get() = y1 - y0
}

class RW(val t: String, val x0: Float, val y0: Float, val x1: Float, val y1: Float)

data class ParsedSlot(val subject: String, val day: Int, val start: String, val end: String, val room: String, val kind: String, val code: String)

/**
 * Reads timetables and study plans from photos (on-device ML Kit OCR) and PDFs / Word files (text stream),
 * then understands them with plain rules: days, times, rooms, course codes. No internet, no API key, no limits.
 */
object LocalImport {
    private val DAYS = mapOf(
        "sat" to 6, "saturday" to 6, "sun" to 7, "sunday" to 7, "mon" to 1, "monday" to 1, "tue" to 2, "tues" to 2, "tuesday" to 2,
        "wed" to 3, "wednesday" to 3, "thu" to 4, "thur" to 4, "thurs" to 4, "thursday" to 4, "fri" to 5, "friday" to 5,
        "السبت" to 6, "الأحد" to 7, "الاحد" to 7, "الإثنين" to 1, "الاثنين" to 1, "الثلاثاء" to 2, "الأربعاء" to 3, "الاربعاء" to 3, "الخميس" to 4, "الجمعة" to 5
    )
    private val TIME = Regex("(\\d{1,2})[:.](\\d{2})\\s*([AaPp][Mm])?")
    private val ROOMS = listOf(
        Regex("\\b(?:room|hall|lab|amphi(?:theatre)?|auditorium|class(?:room)?)[ \\t]*[:\\-]?[ \\t]*([A-Za-z]{0,2}\\d[\\w\\-./]{0,8})", RegexOption.IGNORE_CASE),
        Regex("(?:قاعة|معمل|مدرج)[ \\t]*[:\\-]?[ \\t]*([A-Za-z]{0,2}\\d[\\w\\-./]{0,8})"),
        Regex("\\b([A-Z]{1,2}\\d{1,3}[-.]\\d{1,3})\\b"),
        Regex("\\b([A-Z]\\d{3})\\b")
    )
    private val KIND = Regex("\\b(lec(?:ture)?|sec(?:tion)?|tut(?:orial)?|lab(?:oratory)?)\\b|محاضرة|سكشن|تمارين|معمل", RegexOption.IGNORE_CASE)
    private val CODE = Regex("\\b([A-Z]{2,5}\\s?-?\\d{3}[A-Z]?)\\b")
    private val LIST_A = Regex("(?:^|\\s)(sat|sun|mon|tue|wed|thu|fri)[a-z]*\\.?\\s*[-:,]?\\s*(\\d{1,2}[:.]\\d{2}\\s*(?:am|pm)?)\\s*(?:-|–|to)\\s*(\\d{1,2}[:.]\\d{2}\\s*(?:am|pm)?)\\s+(.+)", RegexOption.IGNORE_CASE)
    private val LIST_B = Regex("^\\s*(\\d{1,2}[:.]\\d{2}\\s*(?:am|pm)?)\\s*(?:-|–|to)\\s*(\\d{1,2}[:.]\\d{2}\\s*(?:am|pm)?)\\s+(.+)", RegexOption.IGNORE_CASE)

    private fun mins(m: MatchResult): Int? {
        var h = m.groupValues[1].toInt()
        val mi = m.groupValues[2].toInt()
        val ap = m.groupValues[3].lowercase()
        if (ap == "pm" && h < 12) h += 12
        if (ap == "am" && h == 12) h = 0
        return if (h in 0..23 && mi < 60) h * 60 + mi else null
    }
    private fun hhmm(m: Int) = "%02d:%02d".format((m / 60) % 24, m % 60)
    private fun dayOf(t: String): Int? = DAYS[t.replace(Regex("[^\\p{L}\\p{N}]"), "").lowercase()]
    private fun times(t: String): List<Int> = TIME.findAll(t).mapNotNull { mins(it) }.toList()

    private class Cell(val name: String, val room: String, val kind: String, val code: String)

    private fun parseCell(text: String): Cell {
        var t = text
        val code = CODE.find(t)?.groupValues?.get(1) ?: ""
        var room = ""
        for (r in ROOMS) {
            val m = r.find(t)
            if (m != null) { room = m.groupValues[1].trim(); t = t.replace(m.value, " "); break }
        }
        var kind = "lecture"
        val k = KIND.find(t)
        if (k != null) {
            val s = k.value.lowercase()
            kind = if (s.contains("lab") || s.contains("معمل")) "lab" else if (s.contains("sec") || s.contains("tut") || s.contains("سكشن") || s.contains("تمارين")) "section" else "lecture"
            t = t.replace(k.value, " ")
        }
        var name = t.replace(Regex("[()\\[\\]]"), " ").replace("\n", " ").replace(Regex("\\s+"), " ").trim().trim(' ', '-', '–', ',', ':', '/')
        if (code.isNotEmpty() && name.contains(code) && name.length > code.length + 3) name = name.replace(code, "").trim().trim(' ', '-', '–', ',', ':')
        if (name.count { it.isLetter() } < 2 && code.isNotEmpty()) name = code
        return Cell(name, room, kind, code)
    }

    private class Slot(var start: Int, var end: Int?, val c: Float)

    /** Grid timetables: days down the side or across the top, time slots on the other axis. */
    private fun grid(lines: List<TLine>): List<ParsedSlot> {
        val dl = lines.mapNotNull { l -> dayOf(l.text)?.let { d -> l to d } }
        if (dl.map { it.second }.toSet().size < 3) return emptyList()
        val sy = dl.maxOf { it.first.cy } - dl.minOf { it.first.cy }
        val sx = dl.maxOf { it.first.cx } - dl.minOf { it.first.cx }
        val rows = sy > sx
        fun ax(l: TLine) = if (rows) l.cy else l.cx
        fun tx(l: TLine) = if (rows) l.cx else l.cy
        val sorted = dl.sortedBy { ax(it.first) }
        if (sorted.size < 2) return emptyList()
        val dayc = sorted.map { ax(it.first) }
        val pitch = dayc.zipWithNext { a, b -> b - a }.filter { it > 1f }.minOrNull() ?: 80f
        val dayb = dayc.zipWithNext { a, b -> (a + b) / 2 }
        val daystart = dayc.first() - pitch / 2
        val dayend = dayc.last() + pitch / 2
        val dayLines = sorted.map { it.first }
        fun isDay(l: TLine) = dayLines.any { it === l }

        val hdr = lines.filter { l -> !isDay(l) && times(l.text).isNotEmpty() && ax(l) < daystart }
        if (hdr.isEmpty()) return emptyList()
        val slots = ArrayList<Slot>()
        val singles = ArrayList<Pair<Int, TLine>>()
        for (l in hdr.sortedBy { tx(it) }) {
            val ts = times(l.text)
            if (ts.size >= 2) slots.add(Slot(ts[0], ts[1], tx(l))) else if (ts.size == 1) singles.add(ts[0] to l)
        }
        val used = HashSet<Int>()
        for (i in singles.indices) {
            if (i in used) continue
            val j = i + 1
            if (rows && j < singles.size && j !in used) {
                val (t1, l1) = singles[i]
                val (t2, l2) = singles[j]
                val stacked = abs(l1.cx - l2.cx) < max(l1.w, l2.w) * 0.6f && abs(l1.cy - l2.cy) > 0f && abs(l1.cy - l2.cy) < max(l1.h, l2.h) * 2.6f
                if (stacked) {
                    val a = if (l1.cy < l2.cy) t1 else t2
                    val b = if (l1.cy < l2.cy) t2 else t1
                    if (b > a) { slots.add(Slot(a, b, (tx(l1) + tx(l2)) / 2)); used.add(i); used.add(j); continue }
                }
            }
            slots.add(Slot(singles[i].first, null, tx(singles[i].second)))
        }
        slots.sortBy { it.c }
        var last = -1
        for (s in slots) {   // times without AM/PM: keep them increasing through the day
            while (s.start < last && s.start + 720 <= 1439) s.start += 720
            val e = s.end
            if (e != null && e <= s.start) s.end = e + 720
            last = s.start
        }
        for (i in slots.indices) {
            if (slots[i].end == null) {
                val nxt = slots.getOrNull(i + 1)
                slots[i].end = if (nxt != null && nxt.start > slots[i].start) nxt.start else slots[i].start + 90
            }
        }
        if (slots.isEmpty()) return emptyList()
        val sc = slots.map { it.c }
        val sb = sc.zipWithNext { a, b -> (a + b) / 2 }
        val spitch = if (sc.size > 1) (sc.last() - sc.first()) / (sc.size - 1) else 150f
        val lo = sc.first() - spitch / 2
        val hi = sc.last() + spitch / 2
        val cells = HashMap<Pair<Int, Int>, MutableList<TLine>>()
        for (l in lines) {
            if (isDay(l) || hdr.any { it === l }) continue
            val a = ax(l)
            val b = tx(l)
            if (a < daystart || a > dayend || b < lo || b > hi) continue
            val di = dayb.count { a > it }
            val si = sb.count { b > it }
            cells.getOrPut(di to si) { ArrayList() }.add(l)
        }
        val out = ArrayList<ParsedSlot>()
        for ((key, ls) in cells.toSortedMap(compareBy<Pair<Int, Int>>({ it.first }, { it.second }))) {
            val text = ls.sortedWith(compareBy({ Math.round(it.cy / 10f) }, { it.cx })).joinToString("\n") { it.text }
            val c = parseCell(text)
            if (c.name.count { it.isLetter() } < 2) continue
            out.add(ParsedSlot(c.name, sorted[key.first].second, hhmm(slots[key.second].start), hhmm(slots[key.second].end ?: (slots[key.second].start + 90)), c.room, c.kind, c.code))
        }
        return out
    }

    /** "Sat 09:00-10:30 Physics I Lec Room B204" or a day heading followed by "09:00 - 10:30 Subject" lines. */
    private fun listFormat(texts: List<String>): List<ParsedSlot> {
        val out = ArrayList<ParsedSlot>()
        var cur: Int? = null
        for (t in texts) {
            val a = LIST_A.find(t)
            if (a != null) {
                val d = dayOf(a.groupValues[1])
                val s = TIME.find(a.groupValues[2])?.let { mins(it) }
                val e = TIME.find(a.groupValues[3])?.let { mins(it) }
                val c = parseCell(a.groupValues[4])
                if (d != null && s != null && e != null && c.name.isNotBlank()) out.add(ParsedSlot(c.name, d, hhmm(s), hhmm(e), c.room, c.kind, c.code))
                continue
            }
            val hd = dayOf(t.trim())
            if (hd != null) { cur = hd; continue }
            val b = LIST_B.find(t)
            if (b != null && cur != null) {
                val s = TIME.find(b.groupValues[1])?.let { mins(it) }
                val e = TIME.find(b.groupValues[2])?.let { mins(it) }
                val c = parseCell(b.groupValues[3])
                if (s != null && e != null && c.name.isNotBlank()) out.add(ParsedSlot(c.name, cur, hhmm(s), hhmm(e), c.room, c.kind, c.code))
            }
        }
        return out
    }

    fun rowTexts(lines: List<TLine>): List<String> {
        val rows = ArrayList<MutableList<TLine>>()
        for (l in lines.sortedWith(compareBy({ it.cy }, { it.cx }))) {
            val r = rows.lastOrNull()
            if (r != null && abs(r.first().cy - l.cy) < max(l.h, 1f) * 0.6f) r.add(l) else rows.add(arrayListOf(l))
        }
        return rows.map { r -> r.sortedBy { it.cx }.joinToString(" ") { it.text } }
    }

    fun parseTimetable(lines: List<TLine>): List<ParsedSlot> {
        val g = grid(lines)
        return if (g.isNotEmpty()) g else listFormat(rowTexts(lines))
    }

    /* ---------------- reading the source ---------------- */

    private fun mergeWords(ws: List<RW>): List<TLine> {
        val out = ArrayList<TLine>()
        var cur = ArrayList<RW>()
        fun flush() {
            if (cur.isNotEmpty()) {
                out.add(TLine(cur.joinToString(" ") { it.t }, cur.minOf { it.x0 }, cur.minOf { it.y0 }, cur.maxOf { it.x1 }, cur.maxOf { it.y1 }))
                cur = ArrayList()
            }
        }
        for (w in ws.sortedWith(compareBy({ it.y1 }, { it.x0 }))) {
            val last = cur.lastOrNull()
            if (last != null) {
                val h = max(last.y1 - last.y0, w.y1 - w.y0)
                val sameRow = abs((last.y0 + last.y1) / 2 - (w.y0 + w.y1) / 2) < h * 0.5f
                val gap = w.x0 - last.x1
                if (!(sameRow && gap < h * 1.8f && gap > -h)) flush()
            }
            cur.add(w)
        }
        flush()
        return out
    }

    private class PosStripper : PDFTextStripper() {
        val words = ArrayList<Pair<Int, RW>>()
        override fun writeString(text: String, textPositions: MutableList<TextPosition>) {
            if (text.isBlank() || textPositions.isEmpty()) return
            val f = textPositions.first()
            val l = textPositions.last()
            val h = textPositions.maxOf { it.heightDir }
            words.add(currentPageNo to RW(text.trim(), f.xDirAdj, f.yDirAdj - h, l.xDirAdj + l.widthDirAdj, f.yDirAdj))
        }
    }

    private fun pdfPages(ctx: Context, f: File): List<List<TLine>> {
        PDFBoxResourceLoader.init(ctx.applicationContext)
        PDDocument.load(f).use { doc ->
            val s = PosStripper()
            s.sortByPosition = true
            s.endPage = minOf(doc.numberOfPages, 30)
            s.getText(doc)
            return s.words.groupBy { it.first }.toSortedMap().values.map { pg -> mergeWords(pg.map { it.second }) }
        }
    }

    suspend fun ocr(ctx: Context, uri: Uri): List<TLine> = suspendCancellableCoroutine { cont ->
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            rec.process(InputImage.fromFilePath(ctx, uri))
                .addOnSuccessListener { t ->
                    val ws = ArrayList<RW>()
                    for (b in t.textBlocks) for (l in b.lines) for (e in l.elements) {
                        val r = e.boundingBox ?: continue
                        ws.add(RW(e.text, r.left.toFloat(), r.top.toFloat(), r.right.toFloat(), r.bottom.toFloat()))
                    }
                    rec.close()
                    cont.resume(mergeWords(ws))
                }
                .addOnFailureListener { e -> rec.close(); cont.resumeWithException(e) }
        } catch (e: Exception) { rec.close(); cont.resumeWithException(e) }
    }

    fun displayName(ctx: Context, uri: Uri): String {
        var n = "file"
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) { val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) n = c.getString(i) ?: "file" }
            }
        } catch (e: Exception) { }
        return n
    }

    private fun copyToCache(ctx: Context, uri: Uri, name: String): File {
        val f = File(ctx.cacheDir, "li_" + System.currentTimeMillis() + "_" + name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
        ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        return f
    }

    private fun isImage(ctx: Context, uri: Uri, name: String): Boolean =
        (ctx.contentResolver.getType(uri) ?: "").startsWith("image/") || name.substringAfterLast('.', "").lowercase() in setOf("png", "jpg", "jpeg", "webp", "heic")

    /** Photo, PDF, Word or text file of a timetable -> classes. */
    suspend fun readTimetable(ctx: Context, uri: Uri): List<ParsedSlot> {
        val name = displayName(ctx, uri)
        val ext = name.substringAfterLast('.', "").lowercase()
        if (isImage(ctx, uri, name)) return parseTimetable(ocr(ctx, uri))
        return withContext(Dispatchers.IO) {
            val f = copyToCache(ctx, uri, name)
            try {
                if (ext == "pdf") {
                    pdfPages(ctx, f).asSequence().map { parseTimetable(it) }.firstOrNull { it.isNotEmpty() } ?: emptyList()
                } else {
                    val lines = Scanner.extract(ctx, f, name) ?: emptyList()
                    listFormat(lines.map { it.text })
                }
            } finally { f.delete() }
        }
    }

    /* ---------------- study plan (course list) ---------------- */

    private val ordinals = mapOf("1" to 1, "2" to 2, "3" to 3, "4" to 4, "5" to 5, "6" to 6, "7" to 7, "8" to 8, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5,
        "first" to 1, "second" to 2, "third" to 3, "fourth" to 4, "fifth" to 5, "الأول" to 1, "الاول" to 1, "الأولى" to 1, "الاولى" to 1, "الثاني" to 2, "الثانية" to 2, "الثالث" to 3, "الثالثة" to 3, "الرابع" to 4, "الرابعة" to 4, "الخامس" to 5, "الخامسة" to 5)
    private val semRx = Regex("(?i)(?:semester|term|الفصل(?: الدراسي)?)\\s*[:\\-]?\\s*([\\p{L}\\d]+)")
    private val yearRx = Regex("(?i)(?:year|level|الفرقة|السنة)\\s*[:\\-]?\\s*([\\p{L}\\d]+)")
    private val codeLine = Regex("^\\s*([A-Z]{2,5}\\s?-?\\d{3}[A-Z]?)\\s+(.{4,70}?)(?:\\s+\\d{1,2}(?:\\s+\\d{1,2}){0,4})?\\s*$")
    private val creditLine = Regex("^\\s*([A-Za-z][A-Za-z &()\\-/]{3,50}?)\\s+\\d(?:\\s+\\d){1,4}\\s*$")

    fun planFromLines(lines: List<String>): List<Sug> {
        val out = ArrayList<Sug>()
        var year = 0
        var sem = 0
        for (raw in lines) {
            val t = raw.trim()
            if (t.isEmpty()) continue
            val sm = semRx.find(t)?.let { ordinals[it.groupValues[1].lowercase()] }
            if (sm != null) { if (sm <= 2) sem = sm else { year = (sm + 1) / 2; sem = if (sm % 2 == 1) 1 else 2 } }
            val ym = yearRx.find(t)?.let { ordinals[it.groupValues[1].lowercase()] }
            if (ym != null && ym <= 5) year = ym
            val name = codeLine.find(t)?.groupValues?.get(2) ?: creditLine.find(t)?.groupValues?.get(1) ?: continue
            val clean = name.trim().trim('-', ':', ',')
            if (clean.count { it.isLetter() } < 4 || out.any { it.name.equals(clean, true) }) continue
            val lab = Regex("(?i)\\blab|practical|drawing|programming").containsMatchIn(clean)
            out.add(Sug(clean, true, true, lab, true, year, sem, true))
        }
        return out
    }

    suspend fun readPlan(ctx: Context, uri: Uri): List<Sug> {
        val name = displayName(ctx, uri)
        if (isImage(ctx, uri, name)) return planFromLines(rowTexts(ocr(ctx, uri)))
        return withContext(Dispatchers.IO) {
            val f = copyToCache(ctx, uri, name)
            try {
                val lines = Scanner.extract(ctx, f, name) ?: emptyList()
                planFromLines(lines.map { it.text })
            } finally { f.delete() }
        }
    }
}
