package com.tr8.scribe

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.time.LocalDate

@Composable
fun TodayCard(store: Store) {
    val ar = store.lang == "ar"
    val today = LocalDate.now().dayOfWeek.value
    val list = store.data.slots.filter { it.day == today }.sortedBy { it.time }
    Panel(tr("Today", "اليوم") + " · " + dayName(today, ar), C.gold) {
        if (list.isEmpty()) {
            Text(tr("No classes today. Add class times in the Schedule tab.", "لا توجد محاضرات اليوم. أضف المواعيد من تبويب الجدول."), fontSize = 14.sp, color = C.dim)
        } else list.forEach { sl ->
            val n = store.data.subjects.firstOrNull { it.id == sl.subjectId }?.name ?: "?"
            Text(fmtTime(sl.time, ar) + "   $n (${kindLabel(sl.kind, ar)})" + if (sl.place.isNotEmpty()) " · ${sl.place}" else "", fontSize = 15.sp, color = C.text)
        }
    }
}

@Composable
fun CoursesTab(store: Store, onOpen: (String) -> Unit) {
    val p = store.data.profile
    val ar = store.lang == "ar"
    var year by remember { mutableIntStateOf(p.year) }
    var sem by remember { mutableIntStateOf(p.sem) }
    var adding by remember { mutableStateOf(false) }
    var suggesting by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Subject?>(null) }
    val subs = store.data.subjects.filter { it.year == year && it.sem == sem }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { TopBar(store, "Scribe") }
        item {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Serif(tr("Hi", "أهلاً") + ", ${p.name} 👋", 20.sp)
                val sub = listOf(p.university, p.major.ifBlank { p.faculty }).filter { it.isNotBlank() }.joinToString(" · ")
                if (sub.isNotEmpty()) Text(sub, fontSize = 12.sp, color = C.dim)
            }
        }
        item { Box(Modifier.padding(horizontal = 16.dp)) { TodayCard(store) } }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (1..5).forEach { y -> FilterChip(year == y, { year = y }, { Text(tr("Year $y", "السنة $y")) }) }
            }
        }
        item {
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (1..2).forEach { s -> FilterChip(sem == s, { sem = s }, { Text(tr("Semester $s", "الفصل $s")) }) }
            }
        }
        if (subs.isEmpty()) item {
            Text(tr("No subjects yet for this semester.", "لا توجد مواد لهذا الفصل بعد."), Modifier.padding(horizontal = 16.dp), color = C.dim)
        }
        items(subs, key = { it.id }) { s ->
            val count = store.data.items.count { it.subjectId == s.id }
            Card(
                Modifier.padding(horizontal = 16.dp).fillMaxWidth().clickable { onOpen(s.id) },
                colors = CardDefaults.cardColors(containerColor = C.card)
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Serif(s.name, 18.sp)
                        Text(
                            listOfNotNull(if (s.lecture) kindLabel("lecture", ar) else null, if (s.section) kindLabel("section", ar).substringBefore(" ") else null,
                                if (s.assignment) kindLabel("assignment", ar) else null, if (s.lab) kindLabel("lab", ar) else null).joinToString(" • ") + "  ·  $count " + tr("files", "ملف"),
                            fontSize = 12.sp, color = C.dim
                        )
                    }
                    TextButton(onClick = { deleting = s }) { Text("✕", color = C.rose) }
                }
            }
        }
        item {
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { adding = true }) { Text(tr("+ Add subject", "+ إضافة مادة")) }
                OutlinedButton(onClick = { suggesting = true }) { Text(tr("✨ Suggest", "✨ اقتراح")) }
            }
        }
    }

    if (adding) AddSubjectDialog({ adding = false }) { n, l, s, lab, a -> store.addSubject(n, year, sem, l, s, lab, a); adding = false }
    if (suggesting) AlertDialog(
        onDismissRequest = { suggesting = false },
        title = { Text(tr("Suggested subjects", "مواد مقترحة")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                SuggestBody(store, year, sem, tr("Add selected", "إضافة المحدد")) { chosen ->
                    chosen.forEach { store.addSubject(it.name, if (it.year > 0) it.year else year, if (it.sem > 0) it.sem else sem, it.lecture, it.section, it.lab, it.assignment) }
                    suggesting = false
                }
            }
        },
        confirmButton = { TextButton(onClick = { suggesting = false }) { Text(tr("Close", "إغلاق")) } }
    )
    deleting?.let { d ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(tr("Delete", "حذف") + " ${d.name}?") },
            text = { Text(tr("This removes its files, notes and class times from this phone.", "سيتم حذف ملفاتها وملاحظاتها ومواعيدها من هذا الهاتف.")) },
            confirmButton = { TextButton(onClick = { store.deleteSubject(d.id); deleting = null }) { Text(tr("Delete", "حذف"), color = C.rose) } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text(tr("Cancel", "إلغاء")) } }
        )
    }
}

@Composable
fun AddSubjectDialog(onDismiss: () -> Unit, onAdd: (String, Boolean, Boolean, Boolean, Boolean) -> Unit) {
    var name by remember { mutableStateOf("") }
    var l by remember { mutableStateOf(true) }
    var s by remember { mutableStateOf(true) }
    var lab by remember { mutableStateOf(false) }
    var asg by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Add subject", "إضافة مادة")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text(tr("Subject name", "اسم المادة")) }, singleLine = true)
                Text(tr("What does it have each week?", "ماذا تتضمن كل أسبوع؟"), fontSize = 13.sp, color = C.dim)
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(l, { l = it }); Text(tr("Lecture", "محاضرة")) }
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(s, { s = it }); Text(tr("Section / sheet", "سكشن / شيت")) }
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(asg, { asg = it }); Text(tr("Assignment", "واجب")) }
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(lab, { lab = it }); Text(tr("Lab", "معمل")) }
            }
        },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank() && (l || s || lab || asg)) onAdd(name, l, s, lab, asg) }) { Text(tr("Add", "إضافة")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Cancel", "إلغاء")) } }
    )
}

/* ---------------- Subject / weeks ---------------- */

@Composable
fun SubjectScreen(store: Store, sub: Subject, onBack: () -> Unit) {
    var week by remember { mutableIntStateOf(1) }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text(tr("‹ Back", "رجوع ›"), color = C.accent) }
            Serif(sub.name, 20.sp)
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            (1..store.weeks).forEach { w -> FilterChip(week == w, { week = w }, { Text(tr("Week $w", "الأسبوع $w")) }) }
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            KINDS.filter { (it == "lecture" && sub.lecture) || (it == "section" && sub.section) || (it == "assignment" && sub.assignment) || (it == "lab" && sub.lab) }
                .forEach { kind -> KindCard(store, sub, week, kind) }
        }
    }
}

@Composable
fun KindCard(store: Store, sub: Subject, week: Int, kind: String) {
    val ar = store.lang == "ar"
    val scope = rememberCoroutineScope()
    val items = store.data.items.filter { it.subjectId == sub.id && it.week == week && it.kind == kind }
    var aiItem by remember { mutableStateOf<Item?>(null) }
    var failed by remember { mutableStateOf(false) }
    val key = noteKey(sub.id, week, kind)
    var text by remember(key) { mutableStateOf(store.data.notes[key] ?: "") }
    LaunchedEffect(key, text) { delay(600); store.setNote(key, text) }

    var scanItem by remember { mutableStateOf<Item?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        scope.launch {
            uris.forEach {
                val added = store.addFile(sub, week, kind, it)
                if (added == null) failed = true
                else if (added.name.substringAfterLast('.', "").lowercase() in TEXT_EXTS) launch { store.scanItem(added, true) }
            }
        }
    }

    Panel(kindLabel(kind, ar) + " · " + tr("Week $week", "الأسبوع $week")) {
        if (items.isEmpty()) Text(tr("No files yet.", "لا توجد ملفات بعد."), fontSize = 13.sp, color = C.dim)
        items.forEach { it ->
            Column {
                Text(it.name, Modifier.clickable { store.openFile(it) }, fontSize = 14.sp, color = C.text)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (it.id in store.scanning) Text(tr("⏳ Reading the file…", "⏳ جارٍ قراءة الملف…"), fontSize = 12.sp, color = C.dim)
                    else TextButton(onClick = { scanItem = it }) { Text(tr("🔎 Scan", "🔎 فحص"), color = C.accent) }
                    TextButton(onClick = { aiItem = it }) { Text("✨ AI", color = C.gold) }
                    TextButton(onClick = { store.deleteItem(it) }) { Text("✕", color = C.rose) }
                }
            }
        }
        OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text(tr("+ Add files (PDF, photos, slides)", "+ إضافة ملفات (PDF، صور، شرائح)")) }
        if (failed) Text(tr("Couldn't copy one of the files.", "تعذّر نسخ أحد الملفات."), color = C.rose, fontSize = 12.sp)
        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), label = { Text(tr("My notes", "ملاحظاتي")) }, minLines = 2)
    }
    aiItem?.let { item -> ActionDialog(store, sub, item) { aiItem = null } }
    scanItem?.let { item ->
        ScanDialog(store, item, onSave = { r -> text = (if (text.isBlank()) "" else text + "\n\n") + r }) { scanItem = null }
    }
}

@Composable
private fun ScanSection(title: String, list: List<String>, max: Int = 12) {
    if (list.isEmpty()) return
    Text(title, fontFamily = androidx.compose.ui.text.font.FontFamily.Serif, fontSize = 15.sp, color = C.accent, modifier = Modifier.padding(top = 8.dp))
    list.take(max).forEach { Text("• $it", fontSize = 13.sp, color = C.text) }
    if (list.size > max) Text("+ ${list.size - max} " + tr("more (they're saved in the notes)", "أخرى (محفوظة في الملاحظات)"), fontSize = 11.sp, color = C.dim)
}

@Composable
fun ScanDialog(store: Store, item: Item, onSave: (String) -> Unit, onClose: () -> Unit) {
    val ar = store.lang == "ar"
    var scan by remember { mutableStateOf(store.loadScan(item.id)) }
    var busy by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }
    LaunchedEffect(item.id) {
        if (scan == null) {
            busy = true
            scan = store.scanItem(item, true)
            busy = false
            failed = scan == null
        }
    }
    val sc = scan
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(item.name, fontSize = 15.sp, maxLines = 2) },
        confirmButton = { TextButton(onClick = onClose) { Text(tr("Close", "إغلاق")) } },
        dismissButton = {
            if (sc != null && !sc.scanned) TextButton(enabled = !saved, onClick = { onSave(Scanner.toText(sc, item.name, ar)); saved = true }) {
                Text(if (saved) tr("Saved ✓", "تم الحفظ ✓") else tr("Save to notes", "حفظ في الملاحظات"))
            }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (busy) { LinearProgressIndicator(Modifier.fillMaxWidth(), color = C.accent); Text(tr("Reading the text inside your file…", "جارٍ قراءة النص داخل ملفك…"), fontSize = 12.sp, color = C.dim) }
                else if (failed || sc == null) Text(tr("I can't read text from this file type. Photos need ✨ AI (it can read images).", "لا أستطيع قراءة نص من هذا النوع من الملفات. الصور تحتاج ✨ الذكاء الاصطناعي (يقرأ الصور)."), color = C.rose, fontSize = 13.sp)
                else if (sc.scanned) Text(tr("This PDF looks like scanned images, so there's no selectable text to read. Use ✨ AI on it instead (it can read images).", "يبدو أن هذا الـ PDF صور ممسوحة ولا يحتوي على نص يمكن قراءته. استخدم ✨ الذكاء الاصطناعي بدلاً من ذلك (يقرأ الصور)."), color = C.rose, fontSize = 13.sp)
                else {
                    Text("${sc.pages} " + tr("pages", "صفحة") + " · ${sc.words} " + tr("words", "كلمة"), fontSize = 12.sp, color = C.dim)
                    if (sc.title.isNotBlank()) Serif(sc.title, 17.sp)
                    if (sc.chapter.isNotBlank()) Text(sc.chapter, fontSize = 13.sp, color = C.gold)
                    ScanSection(tr("Headings", "العناوين"), sc.headings, 15)
                    ScanSection(tr("Definitions", "التعريفات"), sc.definitions, 8)
                    ScanSection(tr("Laws & theorems", "القوانين والنظريات"), sc.laws, 8)
                    ScanSection(tr("Formulas", "المعادلات"), sc.formulas, 15)
                    ScanSection(tr("Examples", "الأمثلة"), sc.examples, 8)
                    ScanSection(tr("Exercises & questions", "التمارين والأسئلة"), sc.exercises, 8)
                    if (sc.keywords.isNotEmpty()) ScanSection(tr("Keywords", "كلمات مفتاحية"), listOf(sc.keywords.joinToString(", ")))
                }
            }
        }
    )
}

@Composable
fun ActionDialog(store: Store, sub: Subject, item: Item, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var question by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val started = tr("Started! It runs in the background and you'll get a notification. Find it in the Ask AI tab.", "بدأنا! تعمل في الخلفية وسيصلك إشعار. ستجدها في تبويب المساعد.")
    val cachedMsg = tr("You already made this one. It's in the Ask AI tab.", "سبق وأنشأت هذا. تجده في تبويب المساعد.")
    val noKey = tr("Add your free Gemini key in Settings first.", "أضف مفتاح Gemini المجاني من الإعدادات أولاً.")
    val unsupported = tr("AI can read PDFs, slides, Word files, photos and text files.", "يقرأ الذكاء الاصطناعي ملفات PDF والشرائح وملفات Word والصور والنصوص.")
    val tooBig = tr("This file is too large (limit about 14 MB).", "الملف كبير جداً (الحد حوالي 14 ميجا).")
    val needQ = tr("Type your question first.", "اكتب سؤالك أولاً.")
    fun go(a: String) {
        if (store.apiKey.isBlank()) { err = noKey; return }
        if (!aiReadable(item.name)) { err = unsupported; return }
        val big = if (item.name.substringAfterLast('.', "").lowercase() in TEXT_EXTS) 80_000_000 else 14_000_000
        if (File(store.filesDir, item.file).length() > big) { err = tooBig; return }
        if (a == "ask" && question.isBlank()) { err = needQ; return }
        val cached = store.enqueueFileAction(item, sub, a, question, store.lang)
        if (!cached) startWork(ctx)
        Toast.makeText(ctx, if (cached) cachedMsg else started, Toast.LENGTH_LONG).show()
        onClose()
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(item.name, fontSize = 16.sp, maxLines = 2) },
        confirmButton = { TextButton(onClick = onClose) { Text(tr("Close", "إغلاق")) } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("Scribe reads the file on your phone and sends only its text to Google's Gemini with your own key.", "يقرأ Scribe الملف على هاتفك ويرسل نصه فقط إلى Gemini من Google بمفتاحك الخاص."), fontSize = 12.sp, color = C.dim)
                listOf(
                    "summary" to tr("📋 Summary + formulas", "📋 ملخص + القوانين"), "explain" to tr("💡 Explain simply", "💡 اشرح ببساطة"),
                    "solve" to tr("✅ Solve / review sheet", "✅ حل / مراجعة الشيت"), "quiz" to tr("📝 Practice quiz", "📝 اختبار تدريبي"),
                    "cards" to tr("🃏 Flashcards", "🃏 بطاقات")
                ).forEach { (a, label) -> OutlinedButton(onClick = { go(a) }, modifier = Modifier.fillMaxWidth()) { Text(label) } }
                OutlinedTextField(question, { question = it }, Modifier.fillMaxWidth(), label = { Text(tr("Or ask a question about it", "أو اسأل سؤالاً عنه")) })
                OutlinedButton(onClick = { go("ask") }, modifier = Modifier.fillMaxWidth()) { Text(tr("❓ Ask", "❓ اسأل")) }
                if (err.isNotEmpty()) Text(err, color = C.rose, fontSize = 13.sp)
            }
        }
    )
}

/* ---------------- Files manager ---------------- */

@Composable
fun FilesTab(store: Store) {
    val ar = store.lang == "ar"
    val ctx = LocalContext.current
    var filter by remember { mutableStateOf("") }
    var renaming by remember { mutableStateOf<Item?>(null) }
    var confirmAll by remember { mutableStateOf(false) }
    val items = store.data.items.filter { filter.isEmpty() || it.subjectId == filter }
    val done = tr("Renamed", "تمت إعادة تسمية")

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { TopBar(store, tr("Files", "الملفات")) }
        item {
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("All files live only on this phone. Used: ", "كل الملفات على هذا الهاتف فقط. المستخدم: ") + "%.1f MB".format(store.usedBytes() / 1048576.0), fontSize = 13.sp, color = C.dim)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(store.autoRename, { store.autoRename = it; store.saveSettings() })
                    Spacer(Modifier.width(10.dp))
                    Text(tr("Auto-rename new uploads (e.g. Physics-I_Sem1_Lec1)", "إعادة تسمية الملفات الجديدة تلقائياً (مثال: Physics-I_Sem1_Lec1)"), fontSize = 13.sp, color = C.text)
                }
                OutlinedButton(onClick = { confirmAll = true }, enabled = store.data.items.isNotEmpty()) { Text(tr("✨ Smart-rename all files", "✨ إعادة تسمية كل الملفات")) }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(filter.isEmpty(), { filter = "" }, { Text(tr("All", "الكل")) })
                    store.data.subjects.forEach { s -> FilterChip(filter == s.id, { filter = s.id }, { Text(s.name) }) }
                }
            }
        }
        if (items.isEmpty()) item { Text(tr("No files yet. Add them from a subject's week.", "لا توجد ملفات بعد. أضفها من أسبوع المادة."), Modifier.padding(horizontal = 16.dp), color = C.dim) }
        items(items, key = { it.id }) { it ->
            val sub = store.data.subjects.firstOrNull { s -> s.id == it.subjectId }
            Column(Modifier.padding(horizontal = 16.dp).fillMaxWidth().background(C.card, androidx.compose.foundation.shape.RoundedCornerShape(14.dp)).padding(12.dp)) {
                Text(it.name, Modifier.clickable { store.openFile(it) }, fontSize = 15.sp, color = C.text)
                Text(
                    (sub?.name ?: "?") + " · " + tr("Year", "سنة") + " ${sub?.year} · " + tr("Sem", "فصل") + " ${sub?.sem} · " + kindLabel(it.kind, ar) + " · " + tr("Week", "أسبوع") + " ${it.week}",
                    fontSize = 11.sp, color = C.dim
                )
                Row {
                    TextButton(onClick = { renaming = it }) { Text(tr("✎ Rename", "✎ إعادة تسمية"), color = C.accent) }
                    TextButton(onClick = { store.openFile(it) }) { Text(tr("Open", "فتح"), color = C.accent) }
                    TextButton(onClick = { store.deleteItem(it) }) { Text(tr("Delete", "حذف"), color = C.rose) }
                }
            }
        }
    }

    renaming?.let { item ->
        val sub = store.data.subjects.firstOrNull { it.id == item.subjectId }
        var n by remember(item.id) { mutableStateOf(item.name) }
        val ext = if (item.name.contains('.')) "." + item.name.substringAfterLast('.') else ""
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text(tr("Rename file", "إعادة تسمية الملف")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(n, { n = it }, Modifier.fillMaxWidth(), label = { Text(tr("File name", "اسم الملف")) })
                    if (sub != null) OutlinedButton(onClick = { n = store.smartName(sub, item.week, item.kind, ext, 0) }) { Text(tr("✨ Use smart name", "✨ استخدم الاسم الذكي")) }
                }
            },
            confirmButton = { TextButton(onClick = { store.renameItem(item, n); renaming = null }) { Text(tr("Save", "حفظ")) } },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text(tr("Cancel", "إلغاء")) } }
        )
    }
    if (confirmAll) AlertDialog(
        onDismissRequest = { confirmAll = false },
        title = { Text(tr("Smart-rename all files?", "إعادة تسمية كل الملفات؟")) },
        text = { Text(tr("Every file is renamed from where you filed it: Subject_Sem_Type+Week, like Physics-I_Sem1_Lec1.", "تُسمّى كل الملفات حسب مكانها: المادة_الفصل_النوع+الأسبوع، مثل Physics-I_Sem1_Lec1.")) },
        confirmButton = {
            TextButton(onClick = {
                val c = store.smartRenameAll()
                confirmAll = false
                Toast.makeText(ctx, "$done $c", Toast.LENGTH_SHORT).show()
            }) { Text(tr("Rename", "إعادة تسمية")) }
        },
        dismissButton = { TextButton(onClick = { confirmAll = false }) { Text(tr("Cancel", "إلغاء")) } }
    )
}
