package com.tr8.scribe

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

private const val CH_WORK = "scribe_work"
private const val CH_DONE = "scribe_done"

fun ensureChannels(ctx: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_WORK, "Scribe is working", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Scribe results", NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(Reminders.CH_REMIND, "Class reminders", NotificationManager.IMPORTANCE_HIGH))
    }
}

fun startWork(ctx: Context) {
    try { ContextCompat.startForegroundService(ctx, Intent(ctx, AiService::class.java)) } catch (e: Exception) { }
}

private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
    ctx, 0,
    Intent(ctx, MainActivity::class.java).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP); putExtra("tab", 2) },
    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
)

private fun notifyDone(ctx: Context, id: Int, text: String) {
    try {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val n = NotificationCompat.Builder(ctx, CH_DONE).setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Scribe").setContentText(text).setAutoCancel(true).setContentIntent(openApp(ctx)).build()
        ctx.getSystemService(NotificationManager::class.java).notify(id, n)
    } catch (e: Exception) { }
}

class AiService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureChannels(this)
        val n: Notification = NotificationCompat.Builder(this, CH_WORK).setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Scribe").setContentText("Working on your request…").setOngoing(true)
            .setContentIntent(openApp(this)).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (!running) {
            running = true
            scope.launch {
                try {
                    do { loop() } while (Store.get(this@AiService).nextQueued() != null)
                } finally {
                    running = false
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
        }
        return START_NOT_STICKY
    }

    private suspend fun loop() {
        val store = Store.get(this)
        while (true) {
            val e = store.nextQueued() ?: break
            store.setStatus(e.id, "running")
            try {
                val text = process(store, e)
                store.finishEntry(e.id, text, "done")
                if (!store.visible) notifyDone(this, e.id.hashCode(), (if (store.lang == "ar") "جاهز: " else "Ready: ") + e.title)
            } catch (ex: Exception) {
                store.finishEntry(e.id, friendly(store.lang, ex), "failed")
                if (!store.visible) notifyDone(this, e.id.hashCode(), (if (store.lang == "ar") "تعذّر: " else "Couldn't finish: ") + e.title)
            }
        }
    }

    private fun friendly(lang: String, ex: Exception): String {
        val ar = lang == "ar"
        return when {
            ex is IOException -> if (ar) "انقطع الاتصال بالإنترنت. اضغط إعادة المحاولة. (حاول Scribe ٣ مرات)" else
                "The internet connection dropped, even after 3 tries. Tap Retry when you're back online."
            ex is ApiError && ex.code == 429 -> (if (ar) "وصلت إلى حد الاستخدام المجاني من Google. انتظر دقيقة ثم اضغط إعادة المحاولة، أو اختر النموذج السريع من الإعدادات.\n\nالتفاصيل: " else
                "Google's free limit was reached. Wait a minute and tap Retry, or pick the Fast model in Settings.\n\nDetails: ") + (ex.message ?: "").take(220)
            ex is ApiError && (ex.code == 400 || ex.code == 403) && (ex.message ?: "").contains("API key", true) ->
                if (ar) "مفتاح Gemini غير صالح. تحقق منه في الإعدادات." else "Your Gemini key isn't valid. Check it in Settings."
            else -> ex.message ?: "Something went wrong."
        }
    }

    private suspend fun process(store: Store, e: Entry): String {
        val chat = e.action == "chat"
        var useSearch = chat && (e.mode == "online" || e.mode == "both")
        val ar = store.lang == "ar"

        // 1) Read the files on the phone first (text is tiny compared with sending whole PDFs)
        val texts = ArrayList<Pair<String, List<String>>>()
        val inl = ArrayList<Pair<Item, String>>()
        val notes = StringBuilder()
        for (item in e.fileIds.mapNotNull { id -> store.data.items.firstOrNull { x -> x.id == id } }) {
            val ext = item.name.substringAfterLast('.', "").lowercase()
            val mime = mimeOf(item.name)
            if (ext in TEXT_EXTS) {
                var pages = store.loadPages(item.id)
                if (pages == null) { store.scanItem(item, false); pages = store.loadPages(item.id) }
                val scan = store.loadScan(item.id)
                if (pages != null && scan != null && !scan.scanned) { texts.add(item.name to pages); continue }
                if (ext == "pdf" && File(store.filesDir, item.file).length() <= 6_000_000) { inl.add(item to "application/pdf"); continue }
                notes.append(if (ar) "(${item.name}: لا يوجد نص قابل للقراءة، أو الملف كبير.)\n" else "(${item.name}: no readable text, or the file is too big to send as images.)\n")
            } else if (mime in AI_MIMES) inl.add(item to mime)
        }

        // 2) Build the message
        var material = ""
        if (texts.isNotEmpty()) {
            material = if (chat) Rag.pick(texts, e.prompt, 45_000) else texts.joinToString("\n\n") { Rag.whole(it.first, it.second, 70_000) }
        }
        var prompt = e.prompt
        if (chat) {
            val hist = store.data.chat.filter { it.ts < e.ts && it.status == "done" && it.text.isNotBlank() && (it.role == "user" || it.action == "chat") }
                .takeLast(6).joinToString("\n") { (if (it.role == "user") "Student: " else "Scribe: ") + it.text.take(1200) }
            prompt = (if (hist.isNotEmpty()) "Conversation so far:\n$hist\n\n" else "") +
                (if (material.isNotEmpty() || inl.isNotEmpty()) "Use the student's files below as the main source when they are relevant.\n" else "") +
                "Student's new message:\n" + e.prompt
        }
        if (material.isNotEmpty()) prompt += "\n\nSTUDENT'S FILE TEXT:\n" + material
        if (notes.isNotEmpty()) prompt += "\n\nNote: " + notes
        val parts = JSONArray().put(JSONObject().put("text", prompt))
        var total = 0L
        for ((item, mime) in inl) {
            val f = File(store.filesDir, item.file)
            if (!f.exists() || total + f.length() > 8_000_000) continue
            total += f.length()
            parts.put(JSONObject().put("text", "Attached file: ${item.name} (${item.kind}, week ${item.week})"))
            parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", mime)
                .put("data", android.util.Base64.encodeToString(f.readBytes(), android.util.Base64.NO_WRAP))))
        }

        // 3) Ask Gemini (streams, retries, waits politely when the free limit says "retry in N seconds")
        val system = Ai.system(store.data.profile, store.lang)
        var note = ""
        var last: Exception? = null
        var waited = 0
        var attempt = 0
        while (attempt < 4) {
            attempt++
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            if (useSearch) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            try {
                val (text, sources) = Ai.stream(store.apiKey, store.model, body) { store.setLive(e.id, Ai.clean(it)) }
                var out = Ai.clean(text)
                if (sources.isNotEmpty()) out += "\n\nSources:\n" + sources.take(5).joinToString("\n") { "• $it" }
                return note + out
            } catch (ex: ApiError) {
                last = ex
                if (useSearch && ex.code == 400) {
                    useSearch = false
                    note = if (ar) "(البحث على الإنترنت غير متاح مع هذا النموذج)\n\n" else "(Online search isn't available with this model.)\n\n"
                    continue
                }
                if (ex.code == 429) {
                    val w = Ai.retrySeconds(ex.message ?: "")
                    if (w != null && w <= 50 && waited < 2) {
                        waited++
                        store.setLive(e.id, if (ar) "⏳ حد Google المجاني — سأنتظر $w ثانية ثم أكمل…" else "⏳ Google's free limit: waiting $w s, then continuing…")
                        delay(w * 1000 + 1000)
                        continue
                    }
                    throw ex
                }
                if (ex.code == 500 || ex.code == 503) { delay(2500L * attempt); continue }
                throw ex
            } catch (ex: IOException) {
                last = ex
                store.setLive(e.id, "")
                delay(2500L * attempt)
            }
        }
        throw last ?: Exception("Failed")
    }
}
