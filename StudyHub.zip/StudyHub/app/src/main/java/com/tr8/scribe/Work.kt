package com.tr8.scribe

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

private const val CH_WORK = "scribe_work"
private const val CH_DONE = "scribe_done"

fun ensureChannels(ctx: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_WORK, "Scribe is working", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Scribe results", NotificationManager.IMPORTANCE_DEFAULT))
    }
}

fun startWork(ctx: Context) {
    try { ContextCompat.startForegroundService(ctx, Intent(ctx, AiService::class.java)) } catch (e: Exception) { }
}

private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
    ctx, 0,
    Intent(ctx, MainActivity::class.java).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP); putExtra("tab", 2) },
    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
)

private fun notifyDone(ctx: Context, id: Int, text: String) {
    try {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val n = NotificationCompat.Builder(ctx, CH_DONE).setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Scribe").setContentText(text).setAutoCancel(true).setContentIntent(openApp(ctx)).build()
        ctx.getSystemService(NotificationManager::class.java).notify(id, n)
    } catch (e: Exception) { }
}

class AiService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureChannels(this)
        val n: Notification = NotificationCompat.Builder(this, CH_WORK).setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Scribe").setContentText("Working on your request…").setOngoing(true)
            .setContentIntent(openApp(this)).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (!running) {
            running = true
            scope.launch {
                try {
                    do { loop() } while (Store.get(this@AiService).nextQueued() != null)
                } finally {
                    running = false
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
        }
        return START_NOT_STICKY
    }

    private suspend fun loop() {
        val store = Store.get(this)
        while (true) {
            val e = store.nextQueued() ?: break
            store.setStatus(e.id, "running")
            try {
                val text = process(store, e)
                store.finishEntry(e.id, text, "done")
                if (!store.visible) notifyDone(this, e.id.hashCode(), (if (store.lang == "ar") "جاهز: " else "Ready: ") + e.title)
            } catch (ex: Exception) {
                store.finishEntry(e.id, friendly(store.lang, ex), "failed")
                if (!store.visible) notifyDone(this, e.id.hashCode(), (if (store.lang == "ar") "تعذّر: " else "Couldn't finish: ") + e.title)
            }
        }
    }

    private fun friendly(lang: String, ex: Exception): String {
        val ar = lang == "ar"
        return when {
            ex is IOException -> if (ar) "انقطع الاتصال بالإنترنت. اضغط إعادة المحاولة. (حاول Scribe ٣ مرات)" else
                "The internet connection dropped, even after 3 tries. Tap Retry when you're back online."
            ex is ApiError && ex.code == 429 -> if (ar) "تم الوصول إلى حد الاستخدام المجاني. انتظر دقيقة أو اختر نموذجاً أخف من الإعدادات." else
                "You hit the free-tier limit. Wait a minute, or pick the Fast model in Settings."
            ex is ApiError && (ex.code == 400 || ex.code == 403) && (ex.message ?: "").contains("API key", true) ->
                if (ar) "مفتاح Gemini غير صالح. تحقق منه في الإعدادات." else "Your Gemini key isn't valid. Check it in Settings."
            else -> ex.message ?: "Something went wrong."
        }
    }

    private suspend fun process(store: Store, e: Entry): String {
        val chat = e.action == "chat"
        var useSearch = chat && (e.mode == "online" || e.mode == "both")
        val parts = JSONArray()
        var prompt = e.prompt
        if (chat) {
            val hist = store.data.chat.filter { it.ts < e.ts && it.status == "done" && it.text.isNotBlank() && (it.role == "user" || it.action == "chat") }
                .takeLast(6).joinToString("\n") { (if (it.role == "user") "Student: " else "Scribe: ") + it.text.take(1200) }
            prompt = (if (hist.isNotEmpty()) "Conversation so far:\n$hist\n\n" else "") +
                (if (e.fileIds.isNotEmpty()) "Use the attached files as the main source when they are relevant.\n" else "") +
                "Student's new message:\n" + e.prompt
        }
        parts.put(JSONObject().put("text", prompt))
        var total = 0L
        for (id in e.fileIds) {
            val it = store.data.items.firstOrNull { x -> x.id == id } ?: continue
            val mime = mimeOf(it.name)
            val f = File(store.filesDir, it.file)
            if (mime !in AI_MIMES || !f.exists() || total + f.length() > 14_000_000) continue
            total += f.length()
            parts.put(JSONObject().put("text", "Attached file: ${it.name} (${it.kind}, week ${it.week})"))
            parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", mime)
                .put("data", android.util.Base64.encodeToString(f.readBytes(), android.util.Base64.NO_WRAP))))
        }
        val system = Ai.system(store.data.profile, store.lang)
        var note = ""
        var last: Exception? = null
        for (attempt in 1..3) {
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            if (useSearch) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            try {
                val (text, sources) = Ai.stream(store.apiKey, store.model, body) { store.setLive(e.id, Ai.clean(it)) }
                var out = Ai.clean(text)
                if (sources.isNotEmpty()) out += "\n\nSources:\n" + sources.take(5).joinToString("\n") { "• $it" }
                return note + out
            } catch (ex: ApiError) {
                if (useSearch && ex.code == 400) {
                    useSearch = false
                    note = if (store.lang == "ar") "(البحث على الإنترنت غير متاح مع هذا النموذج)\n\n" else "(Online search isn't available with this model.)\n\n"
                    last = ex
                    continue
                }
                if (ex.code == 500 || ex.code == 503) { last = ex; delay(2500L * attempt); continue }
                throw ex
            } catch (ex: IOException) {
                last = ex
                store.setLive(e.id, "")
                delay(2500L * attempt)
            }
        }
        throw last ?: Exception("Failed")
    }
}
