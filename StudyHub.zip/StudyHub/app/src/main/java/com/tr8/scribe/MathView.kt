package com.tr8.scribe

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import org.json.JSONObject

/** Remembers how tall each rendered message was, so lists don't jump when they scroll back into view. */
object MathCache { val heights = HashMap<String, Float>() }

private fun hex(c: Color) = String.format("#%06X", 0xFFFFFF and c.toArgb())
private fun rgba(c: Color, a: Float) = "rgba(${(c.red * 255).toInt()},${(c.green * 255).toInt()},${(c.blue * 255).toInt()},$a)"

/**
 * Shows Markdown with real math: LaTeX ($\theta$, $$\frac{a}{b}$$) and chemistry ($\ce{2H2 + O2 -> 2H2O}$).
 * Everything is drawn offline by KaTeX that is bundled inside the app.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MathView(text: String, modifier: Modifier = Modifier, cacheKey: String = "", streaming: Boolean = false, fontSp: Int = 15) {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    val ar = LocalLang.current == "ar"
    var heightPx by remember(cacheKey) { mutableStateOf(MathCache.heights[cacheKey] ?: 28f) }
    var ready by remember { mutableStateOf(false) }
    val key by rememberUpdatedState(cacheKey)
    val web = remember {
        WebView(ctx).apply {
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addJavascriptInterface(object {
                @JavascriptInterface
                fun h(px: Float) {
                    Handler(Looper.getMainLooper()).post {
                        heightPx = px
                        if (key.isNotEmpty()) MathCache.heights[key] = px
                    }
                }
            }, "ScribeBridge")
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) { ready = true }
            }
            loadUrl("file:///android_asset/render.html")
        }
    }
    DisposableEffect(web) { onDispose { (web.parent as? android.view.ViewGroup)?.removeView(web); web.destroy() } }

    LaunchedEffect(ready, pal, ar, fontSp) {
        if (!ready) return@LaunchedEffect
        val o = JSONObject().put("text", hex(pal.text)).put("dim", rgba(pal.text, 0.65f)).put("accent", hex(pal.accent))
            .put("gold", hex(pal.gold)).put("card", rgba(pal.text, 0.07f)).put("line", rgba(pal.text, 0.14f))
            .put("fs", "${fontSp}px").put("dir", if (ar) "rtl" else "ltr")
        web.evaluateJavascript("setTheme($o)", null)
    }
    val last = remember { longArrayOf(0L) }
    LaunchedEffect(ready, text, streaming) {
        if (!ready) return@LaunchedEffect
        if (System.currentTimeMillis() - last[0] < 220) delay(90)
        last[0] = System.currentTimeMillis()
        web.evaluateJavascript("setContent(" + JSONObject.quote(text) + "," + streaming + ")", null)
    }
    AndroidView(factory = { web }, modifier = modifier.fillMaxWidth().height(heightPx.dp))
}

/** Card/button that gently shrinks while pressed. */
@Composable
fun Modifier.pressClick(onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.97f else 1f, spring(dampingRatio = 0.55f, stiffness = 500f), label = "press")
    return this.scale(sc).clickable(interactionSource = src, indication = null, onClick = onClick)
}

/** Three bouncing dots, shown while the AI is thinking. */
@Composable
fun TypingDots() {
    val t = rememberInfiniteTransition(label = "dots")
    val c = C.accent
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
        repeat(3) { i ->
            val a by t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(600, delayMillis = i * 160, easing = LinearEasing), RepeatMode.Reverse), label = "d$i")
            Box(Modifier.size(8.dp).graphicsLayer { alpha = a; scaleX = 0.7f + 0.3f * a; scaleY = 0.7f + 0.3f * a }.background(c, CircleShape))
        }
    }
}
