package com.tr8.scribe

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

val AI_MIMES = setOf("application/pdf", "image/png", "image/jpeg", "image/webp", "image/heic", "image/heif", "text/plain")

class ApiError(val code: Int, msg: String) : Exception(msg)

/** Talks to Google's Gemini API with the user's own free key. */
object Ai {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/"

    private fun open(key: String, path: String, body: String?, readTimeout: Int): HttpURLConnection {
        val c = URL(BASE + path).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = readTimeout
        c.setRequestProperty("x-goog-api-key", key)
        if (body != null) {
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        return c
    }

    private fun fail(c: HttpURLConnection, code: Int): Nothing {
        val text = c.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
        val msg = try { JSONObject(text).getJSONObject("error").getString("message") } catch (e: Exception) { text.take(300) }
        throw ApiError(code, "Error $code: $msg")
    }

    private fun call(key: String, path: String, body: String?): String {
        val c = open(key, path, body, 120000)
        val code = c.responseCode
        if (code !in 200..299) fail(c, code)
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun text(res: JSONObject): String {
        val cand = res.optJSONArray("candidates")?.optJSONObject(0)
            ?: throw Exception("No answer came back (the request may have been blocked).")
        val ps = cand.optJSONObject("content")?.optJSONArray("parts") ?: throw Exception("The answer was empty.")
        return (0 until ps.length()).joinToString("") { ps.getJSONObject(it).optString("text") }
    }

    private fun fileParts(prompt: String, file: File?, mime: String?): JSONArray {
        val parts = JSONArray().put(JSONObject().put("text", prompt))
        if (file != null && mime != null) {
            val b64 = Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
            parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", mime).put("data", b64)))
        }
        return parts
    }

    /** One-shot request (used for short tasks like suggestions and schedule import). */
    fun ask(key: String, model: String, prompt: String, file: File?, mime: String?, json: Boolean = false, search: Boolean = false): String {
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", fileParts(prompt, file, mime))))
        if (json && !search) body.put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        if (search) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        return text(JSONObject(call(key, "models/" + model.removePrefix("models/") + ":generateContent", body.toString())))
    }

    /** Streaming request: text arrives piece by piece, so the first words show up quickly. */
    fun stream(key: String, model: String, body: JSONObject, onText: (String) -> Unit): Pair<String, List<String>> {
        val c = open(key, "models/" + model.removePrefix("models/") + ":streamGenerateContent?alt=sse", body.toString(), 90000)
        val code = c.responseCode
        if (code !in 200..299) fail(c, code)
        val sb = StringBuilder()
        val sources = LinkedHashSet<String>()
        c.inputStream.bufferedReader().useLines { lines ->
            for (line in lines) {
                if (!line.startsWith("data:")) continue
                val js = line.removePrefix("data:").trim()
                if (js.isEmpty()) continue
                val o = try { JSONObject(js) } catch (e: Exception) { continue }
                val cand = o.optJSONArray("candidates")?.optJSONObject(0) ?: continue
                val ps = cand.optJSONObject("content")?.optJSONArray("parts")
                if (ps != null) {
                    for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text"))
                    onText(sb.toString())
                }
                val ch = cand.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
                if (ch != null) for (i in 0 until ch.length()) {
                    val w = ch.getJSONObject(i).optJSONObject("web") ?: continue
                    sources.add(w.optString("title", "source") + ": " + w.optString("uri"))
                }
            }
        }
        if (sb.isEmpty()) throw Exception("The answer was empty (the request may have been blocked).")
        return sb.toString() to sources.toList()
    }

    fun models(key: String): List<String> {
        val res = JSONObject(call(key, "models?pageSize=200", null))
        val arr = res.optJSONArray("models") ?: return emptyList()
        return (0 until arr.length()).map { arr.getJSONObject(it) }
            .filter { m ->
                val sm = m.optJSONArray("supportedGenerationMethods")
                sm != null && (0 until sm.length()).any { sm.getString(it) == "generateContent" }
            }
            .map { it.getString("name").removePrefix("models/") }
            .filter { n -> n.contains("flash") && listOf("image", "tts", "live", "audio", "robotics").none { n.contains(it) } }
            .sortedDescending()
    }

    /** Free directory of university names (needs internet). Returns name to country. */
    fun universities(q: String, country: String): List<Pair<String, String>> {
        val path = "search?name=" + URLEncoder.encode(q, "UTF-8") +
            (if (country.isNotBlank()) "&country=" + URLEncoder.encode(country, "UTF-8") else "")
        fun get(u: String): String {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 15000; c.readTimeout = 20000
            return c.inputStream.bufferedReader().use { it.readText() }
        }
        val t = try { get("https://universities.hipolabs.com/$path") } catch (e: Exception) { get("http://universities.hipolabs.com/$path") }
        val arr = JSONArray(t)
        return (0 until minOf(arr.length(), 25)).map { arr.getJSONObject(it) }.map { it.optString("name") to it.optString("country") }
    }

    /** Smart university search: Gemini + Google Search understands abbreviations like AASTMT. Returns name to "city, country". */
    fun universitiesAi(key: String, model: String, q: String, country: String): List<Pair<String, String>> {
        val where = if (country.isNotBlank()) " in $country" else ""
        val prompt = "Using Google search, find universities matching \"$q\"$where. The text may be an abbreviation, an acronym or a partial name. " +
            "Return ONLY a JSON array of up to 6 objects like {\"name\":\"official full English name\",\"city\":\"city\",\"country\":\"country\"} and nothing else. " +
            "Put the best match first. If nothing matches, return []."
        val t = try { ask(key, model, prompt, null, null, search = true) } catch (e: ApiError) { ask(key, model, prompt, null, null, json = true) }
        val arr = JSONArray(extractJson(t))
        return (0 until arr.length()).map { arr.getJSONObject(it) }.filter { it.optString("name").isNotBlank() }
            .map { it.getString("name") to listOf(it.optString("city"), it.optString("country")).filter { x -> x.isNotBlank() }.joinToString(", ") }
    }

    fun extractJson(t: String): String {
        val s = t.replace("```json", "").replace("```", "")
        val a = s.indexOfFirst { it == '[' || it == '{' }
        val b = s.indexOfLast { it == ']' || it == '}' }
        return if (a >= 0 && b > a) s.substring(a, b + 1) else s
    }

    fun clean(s: String): String = s.replace("**", "")
        .replace(Regex("(?m)^\\s*#+\\s*"), "")
        .replace(Regex("(?m)^\\s*\\*\\s+"), "• ")

    fun system(p: Profile, lang: String): String {
        val who = if (p.university.isNotBlank() || p.major.isNotBlank())
            "The student studies ${p.major.ifBlank { p.faculty }} at ${p.university.ifBlank { "a university" }} (year ${p.year}, semester ${p.sem}). " else ""
        return "You are Scribe, a warm, clear study assistant. $who" +
            "Reply in ${if (lang == "ar") "Arabic" else "English"} unless the student writes in another language. " +
            "Use plain text only (no markdown symbols like ** or #). Be concise but complete, and show steps for problems."
    }

    fun prompt(action: String, subject: String, week: Int, kind: String, extra: String, lang: String): String {
        val what = when (kind) { "lecture" -> "lecture slides or notes"; "section" -> "section sheet or assignment"; else -> "lab notes" }
        val head = "Subject: $subject. Week $week. The attached file is $what. Keep it organized with short numbered sections. " +
            (if (lang == "ar") "Write the answer in Arabic, but keep formulas and technical terms in English too. " else "")
        val task = when (action) {
            "summary" -> "Extract: 1) the title and lessons covered, 2) key definitions, 3) laws, rules and theories, " +
                "4) every important formula with what each symbol means, 5) the examples and exercises given (brief), " +
                "6) what to memorize for the exam."
            "explain" -> "Explain the main ideas in very simple language with intuition and small examples, as if teaching " +
                "a classmate who missed the class. Point out common confusions."
            "solve" -> "For every question in the file: give the core idea, the best method, a step-by-step solution, " +
                "the final answer, and a common mistake to avoid. If a question is unclear or missing data, say so. " +
                "At the end, list concepts the student should know that the professor may not have explained."
            "quiz" -> "Create 8 practice questions (a mix of multiple choice and short answer) based only on this file, " +
                "then an answer key with brief explanations."
            "cards" -> "Create 12 flashcards covering the most important concepts and formulas. Use exactly this format " +
                "with a blank line between cards:\nQ: question\nA: answer"
            else -> "Answer this question using the file: $extra"
        }
        return head + task
    }

    fun parseCards(t: String): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        var q = ""
        var a = ""
        var inA = false
        for (raw in t.lines()) {
            val l = raw.trim()
            when {
                l.startsWith("Q:") || l.startsWith("Q.") -> {
                    if (q.isNotEmpty() && a.isNotEmpty()) out.add(q.trim() to a.trim())
                    q = l.drop(2); a = ""; inA = false
                }
                l.startsWith("A:") || l.startsWith("A.") -> { a = l.drop(2); inA = true }
                l.isNotEmpty() -> { if (inA) a += "\n" + l else if (q.isNotEmpty()) q += "\n" + l }
            }
        }
        if (q.isNotEmpty() && a.isNotEmpty()) out.add(q.trim() to a.trim())
        return out
    }
}
