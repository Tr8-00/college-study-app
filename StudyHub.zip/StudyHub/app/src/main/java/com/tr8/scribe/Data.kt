package com.tr8.scribe

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class Profile(
    val name: String = "", val uniType: String = "", val university: String = "", val faculty: String = "",
    val major: String = "", val year: Int = 1, val sem: Int = 1, val done: Boolean = false
)
data class Subject(val id: String, val name: String, val year: Int, val sem: Int, val lecture: Boolean, val section: Boolean, val lab: Boolean, val assignment: Boolean = true)
data class Item(val id: String, val subjectId: String, val week: Int, val kind: String, val name: String, val file: String)
data class Slot(val id: String, val subjectId: String, val day: Int, val time: String, val end: String, val kind: String, val place: String)
data class Entry(
    val id: String, val role: String, val text: String, val status: String, val title: String, val action: String,
    val prompt: String, val fileIds: List<String>, val mode: String, val subjectId: String, val week: Int,
    val kind: String, val ts: Long
)
data class Data(
    val profile: Profile = Profile(),
    val subjects: List<Subject> = emptyList(),
    val items: List<Item> = emptyList(),
    val slots: List<Slot> = emptyList(),
    val notes: Map<String, String> = emptyMap(),
    val chat: List<Entry> = emptyList(),
    val done: Set<String> = emptySet()
)

val KINDS = listOf("lecture", "section", "assignment", "lab")
val SLOT_KINDS = listOf("lecture", "section", "lab")
fun kindLabel(k: String, ar: Boolean) = when (k) {
    "lecture" -> if (ar) "محاضرة" else "Lecture"
    "section" -> if (ar) "سكشن / شيت" else "Section / Sheet"
    "assignment" -> if (ar) "واجب" else "Assignment"
    else -> if (ar) "معمل" else "Lab"
}
fun kindAbbr(k: String) = when (k) { "lecture" -> "Lec"; "section" -> "Sec"; "assignment" -> "Asg"; else -> "Lab" }
fun aiReadable(name: String) = name.substringAfterLast('.', "").lowercase() in (TEXT_EXTS + setOf("png", "jpg", "jpeg", "webp", "heic", "heif"))
fun noteKey(subjectId: String, week: Int, kind: String) = "$subjectId|$week|$kind"
fun newId(): String = UUID.randomUUID().toString()

fun mimeOf(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
    "pdf" -> "application/pdf"
    "png" -> "image/png"
    "jpg", "jpeg" -> "image/jpeg"
    "webp" -> "image/webp"
    "heic" -> "image/heic"
    "heif" -> "image/heif"
    "txt" -> "text/plain"
    "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    else -> "application/octet-stream"
}

fun actionLabel(a: String) = when (a) {
    "summary" -> "Summary + formulas"; "explain" -> "Simple explanation"; "solve" -> "Solve / review sheet"
    "quiz" -> "Practice quiz"; "cards" -> "Flashcards"; else -> "Question"
}

private fun <T> JSONArray?.mapObjs(f: (JSONObject) -> T): List<T> =
    if (this == null) emptyList() else (0 until length()).map { f(getJSONObject(it)) }

/** One shared store: the screens and the background AI service both use it. Everything is saved on this phone. */
class Store private constructor(private val ctx: Context) {
    companion object {
        @Volatile private var inst: Store? = null
        fun get(c: Context): Store = inst ?: synchronized(this) { inst ?: Store(c.applicationContext).also { inst = it } }
    }

    private val dataFile = File(ctx.filesDir, "scribe.json")
    val filesDir = File(ctx.filesDir, "files").apply { mkdirs() }
    private val prefs = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var data by mutableStateOf(load())
        private set
    var live by mutableStateOf<Map<String, String>>(emptyMap())
    var apiKey by mutableStateOf(prefs.getString("key", "") ?: "")
    var model by mutableStateOf(prefs.getString("model", "gemini-flash-lite-latest") ?: "gemini-flash-lite-latest")
    var weeks by mutableIntStateOf(prefs.getInt("weeks", 14))
    var lang by mutableStateOf(prefs.getString("lang", "en") ?: "en")
    var theme by mutableStateOf(prefs.getString("theme", "dark") ?: "dark")
    var autoRename by mutableStateOf(prefs.getBoolean("autoRename", true))
    var chatMode by mutableStateOf(prefs.getString("chatMode", "both") ?: "both")
    var chatSubjectId by mutableStateOf("")
    var chatWeek by mutableIntStateOf(0)
    var pendingTab by mutableIntStateOf(-1)
    var remindersOn by mutableStateOf(prefs.getBoolean("remOn", true))
    var remindMin by mutableIntStateOf(prefs.getInt("remMin", 30))
    var studyRemind by mutableStateOf(prefs.getBoolean("studyOn", true))
    var studyHour by mutableIntStateOf(prefs.getInt("studyHr", 20))
    var lecturesPerWeek by mutableIntStateOf(prefs.getInt("lpw", 1))
    var scanning by mutableStateOf<Set<String>>(emptySet())
    @Volatile var visible = false

    var askedNotif: Boolean
        get() = prefs.getBoolean("askedNotif", false)
        set(v) { prefs.edit().putBoolean("askedNotif", v).apply() }

    fun saveSettings() {
        prefs.edit().putString("key", apiKey.trim()).putString("model", model.trim()).putInt("weeks", weeks)
            .putString("lang", lang).putString("theme", theme).putBoolean("autoRename", autoRename)
            .putString("chatMode", chatMode).putBoolean("remOn", remindersOn).putInt("remMin", remindMin).putBoolean("studyOn", studyRemind).putInt("studyHr", studyHour).putInt("lpw", lecturesPerWeek).apply()
    }
    fun toggleLang() { lang = if (lang == "ar") "en" else "ar"; saveSettings() }
    fun toggleTheme() { theme = if (theme == "dark") "light" else "dark"; saveSettings() }

    /* ---------- load / save ---------- */
    private fun load(): Data = try {
        if (!dataFile.exists()) Data() else {
            val o = JSONObject(dataFile.readText())
            val p = o.optJSONObject("profile")
            val notes = HashMap<String, String>()
            o.optJSONObject("notes")?.let { n -> n.keys().forEach { k -> notes[k] = n.getString(k) } }
            Data(
                if (p == null) Profile() else Profile(p.optString("name"), p.optString("uniType"), p.optString("university"),
                    p.optString("faculty"), p.optString("major"), p.optInt("year", 1), p.optInt("sem", 1), p.optBoolean("done")),
                o.optJSONArray("subjects").mapObjs {
                    Subject(it.getString("id"), it.getString("name"), it.getInt("year"), it.getInt("sem"),
                        it.getBoolean("lecture"), it.getBoolean("section"), it.getBoolean("lab"), it.optBoolean("assignment", true))
                },
                o.optJSONArray("items").mapObjs {
                    Item(it.getString("id"), it.getString("subjectId"), it.getInt("week"), it.getString("kind"),
                        it.getString("name"), it.getString("file"))
                },
                o.optJSONArray("slots").mapObjs {
                    Slot(it.getString("id"), it.getString("subjectId"), it.getInt("day"), it.getString("time"),
                        it.optString("end"), it.getString("kind"), it.optString("place"))
                },
                notes,
                o.optJSONArray("chat").mapObjs {
                    Entry(it.getString("id"), it.getString("role"), it.optString("text"), it.getString("status"),
                        it.optString("title"), it.optString("action"), it.optString("prompt"),
                        it.optString("fileIds").split(",").filter { s -> s.isNotEmpty() }, it.optString("mode"),
                        it.optString("subjectId"), it.optInt("week"), it.optString("kind"), it.getLong("ts"))
                },
                o.optJSONArray("done")?.let { a -> (0 until a.length()).map { i -> a.getString(i) }.toSet() } ?: emptySet()
            )
        }
    } catch (e: Exception) { Data() }

    @Synchronized
    private fun modify(f: (Data) -> Data) {
        val d = f(data)
        data = d
        val o = JSONObject()
        val p = d.profile
        o.put("profile", JSONObject().put("name", p.name).put("uniType", p.uniType).put("university", p.university)
            .put("faculty", p.faculty).put("major", p.major).put("year", p.year).put("sem", p.sem).put("done", p.done))
        o.put("subjects", JSONArray().also { a -> d.subjects.forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("year", it.year).put("sem", it.sem)
                .put("lecture", it.lecture).put("section", it.section).put("lab", it.lab).put("assignment", it.assignment)) } })
        o.put("items", JSONArray().also { a -> d.items.forEach {
            a.put(JSONObject().put("id", it.id).put("subjectId", it.subjectId).put("week", it.week)
                .put("kind", it.kind).put("name", it.name).put("file", it.file)) } })
        o.put("slots", JSONArray().also { a -> d.slots.forEach {
            a.put(JSONObject().put("id", it.id).put("subjectId", it.subjectId).put("day", it.day)
                .put("time", it.time).put("end", it.end).put("kind", it.kind).put("place", it.place)) } })
        val n = JSONObject()
        d.notes.forEach { (k, v) -> n.put(k, v) }
        o.put("notes", n)
        o.put("chat", JSONArray().also { a -> d.chat.forEach {
            a.put(JSONObject().put("id", it.id).put("role", it.role).put("text", it.text).put("status", it.status)
                .put("title", it.title).put("action", it.action).put("prompt", it.prompt)
                .put("fileIds", it.fileIds.joinToString(",")).put("mode", it.mode).put("subjectId", it.subjectId)
                .put("week", it.week).put("kind", it.kind).put("ts", it.ts)) } })
        o.put("done", JSONArray(d.done.toList()))
        dataFile.writeText(o.toString())
    }

    /* ---------- profile & subjects ---------- */
    fun setProfile(f: (Profile) -> Profile) = modify { it.copy(profile = f(it.profile)) }

    fun addSubject(name: String, year: Int, sem: Int, lecture: Boolean, section: Boolean, lab: Boolean, assignment: Boolean = true) = modify {
        if (it.subjects.any { s -> s.year == year && s.sem == sem && s.name.equals(name.trim(), true) }) it
        else it.copy(subjects = it.subjects + Subject(newId(), name.trim(), year, sem, lecture, section, lab, assignment))
    }

    fun deleteSubject(id: String) {
        data.items.filter { it.subjectId == id }.forEach { dropFiles(it) }
        data.slots.filter { it.subjectId == id }.forEach { Reminders.cancel(ctx, it.id) }
        modify { d ->
            d.copy(subjects = d.subjects.filter { it.id != id }, items = d.items.filter { it.subjectId != id },
                slots = d.slots.filter { it.subjectId != id }, notes = d.notes.filterKeys { !it.startsWith("$id|") })
        }
    }

    /* ---------- files ---------- */
    private fun safe(n: String) = n.replace(Regex("[\\\\/:*?\"<>|\\s]+"), "_")

    fun smartName(sub: Subject, week: Int, kind: String, ext: String, index: Int, hint: String = ""): String {
        val base = sub.name.trim().replace(Regex("[\\\\/:*?\"<>|]"), "").replace(Regex("\\s+"), "-") +
            "_Sem${sub.sem}_${kindAbbr(kind)}$week"
        return base + (if (index > 0) "_${index + 1}" else "") + (if (hint.isNotBlank()) "_$hint" else "") + ext
    }

    suspend fun addFile(sub: Subject, week: Int, kind: String, uri: Uri): Item? = try {
        val id = newId()
        val (orig, tmpName) = withContext(Dispatchers.IO) {
            var n = "file"
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) n = c.getString(i) ?: "file"
                }
            }
            val tmp = "${id}_tmp"
            ctx.contentResolver.openInputStream(uri)!!.use { inp -> File(filesDir, tmp).outputStream().use { out -> inp.copyTo(out) } }
            n to tmp
        }
        val ext = if (orig.contains('.')) "." + orig.substringAfterLast('.') else ""
        val sameSlot = data.items.count { it.subjectId == sub.id && it.week == week && it.kind == kind }
        val shown = if (autoRename) smartName(sub, week, kind, ext, sameSlot) else orig
        val phys = "${id}_${safe(shown)}"
        File(filesDir, tmpName).renameTo(File(filesDir, phys))
        val item = Item(id, sub.id, week, kind, shown, phys)
        modify { it.copy(items = it.items + item) }
        item
    } catch (e: Exception) { null }

    fun renameItem(item: Item, newName: String) {
        val n = newName.trim()
        if (n.isEmpty()) return
        val phys = "${item.id}_${safe(n)}"
        File(filesDir, item.file).renameTo(File(filesDir, phys))
        modify { d -> d.copy(items = d.items.map { if (it.id == item.id) it.copy(name = n, file = phys) else it }) }
    }

    fun smartRenameAll(): Int {
        var count = 0
        val groups = data.items.groupBy { Triple(it.subjectId, it.week, it.kind) }
        for ((k, list) in groups) {
            val sub = data.subjects.firstOrNull { it.id == k.first } ?: continue
            list.forEachIndexed { i, it ->
                val ext = if (it.name.contains('.')) "." + it.name.substringAfterLast('.') else ""
                val hint = loadScan(it.id)?.takeIf { sc -> !sc.scanned }?.let { sc -> Scanner.nameHint(sc) } ?: ""
                val n = smartName(sub, k.second, k.third, ext, i, hint)
                if (n != it.name) { renameItem(it, n); count++ }
            }
        }
        return count
    }

    private fun dropFiles(item: Item) {
        File(filesDir, item.file).delete()
        File(ctx.filesDir, "scan_${item.id}.json").delete()
        File(ctx.filesDir, "text_${item.id}.json").delete()
    }

    fun deleteItem(item: Item) {
        dropFiles(item)
        modify { d -> d.copy(items = d.items.filter { it.id != item.id }) }
    }

    /* ---------- smart scan (reads the text inside PDFs, slides and documents on this phone) ---------- */
    fun loadScan(id: String): Scan? = try {
        val f = File(ctx.filesDir, "scan_$id.json"); if (f.exists()) Scanner.fromJson(JSONObject(f.readText())) else null
    } catch (e: Exception) { null }

    fun loadPages(id: String): List<String>? = try {
        val f = File(ctx.filesDir, "text_$id.json")
        if (f.exists()) JSONArray(f.readText()).let { a -> (0 until a.length()).map { a.getString(it) } } else null
    } catch (e: Exception) { null }

    /** Reads the file, saves what it found, and (optionally) adds the real chapter/unit title to the file name. */
    suspend fun scanItem(item: Item, rename: Boolean): Scan? {
        scanning = scanning + item.id
        return try {
            val res = withContext(Dispatchers.IO) {
                val lines = Scanner.extract(ctx, File(filesDir, item.file), item.name) ?: return@withContext null
                val scan = Scanner.analyze(lines)
                File(ctx.filesDir, "scan_${item.id}.json").writeText(Scanner.toJson(scan).toString())
                File(ctx.filesDir, "text_${item.id}.json").writeText(JSONArray(Scanner.pages(lines)).toString())
                scan
            }
            if (res != null && rename && autoRename && !res.scanned) {
                val hint = Scanner.nameHint(res)
                val sub = data.subjects.firstOrNull { it.id == item.subjectId }
                val cur = data.items.firstOrNull { it.id == item.id }
                if (hint.isNotEmpty() && sub != null && cur != null) {
                    val ext = if (cur.name.contains('.')) "." + cur.name.substringAfterLast('.') else ""
                    val idx = data.items.filter { it.subjectId == sub.id && it.week == cur.week && it.kind == cur.kind }.indexOfFirst { it.id == cur.id }.coerceAtLeast(0)
                    renameItem(cur, smartName(sub, cur.week, cur.kind, ext, idx, hint))
                }
            }
            res
        } catch (e: Throwable) { null } finally { scanning = scanning - item.id }
    }

    fun usedBytes(): Long = filesDir.listFiles()?.sumOf { it.length() } ?: 0L

    fun openFile(item: Item) {
        try {
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", File(filesDir, item.file))
            val i = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeOf(item.name))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(ctx, "No app found to open this file.", Toast.LENGTH_SHORT).show()
        }
    }

    fun chatFiles(subjectId: String, week: Int): List<Item> =
        data.items.filter { it.subjectId == subjectId && (week == 0 || it.week == week) && aiReadable(it.name) }.takeLast(12)

    /* ---------- notes & schedule ---------- */
    fun setNote(key: String, text: String) {
        if ((data.notes[key] ?: "") == text) return
        modify { it.copy(notes = if (text.isEmpty()) it.notes - key else it.notes + (key to text)) }
    }

    fun addSlot(subjectId: String, day: Int, time: String, end: String, kind: String, place: String) {
        modify { it.copy(slots = it.slots + Slot(newId(), subjectId, day, time, end, kind, place.trim())) }
        Reminders.scheduleAll(ctx)
    }
    fun deleteSlot(id: String) {
        Reminders.cancel(ctx, id)
        modify { it.copy(slots = it.slots.filter { s -> s.id != id }) }
    }

    /* ---------- AI jobs (they live in the chat list) ---------- */
    /** Returns true if an identical finished result already exists (instant, no new request). */
    fun enqueueFileAction(item: Item, sub: Subject, action: String, question: String, lang: String): Boolean {
        val prev = data.chat.firstOrNull { it.role == "ai" && it.status == "done" && it.action == action && it.fileIds == listOf(item.id) && action != "ask" }
        if (prev != null) {
            modify { d -> d.copy(chat = d.chat.filter { it.id != prev.id } + prev.copy(ts = System.currentTimeMillis())) }
            return true
        }
        val now = System.currentTimeMillis()
        val label = actionLabel(action)
        val user = Entry(newId(), "user", if (action == "ask") question else "$label: ${item.name}", "done", "", action, "",
            listOf(item.id), "local", sub.id, item.week, item.kind, now)
        val ai = Entry(newId(), "ai", "", "queued", "$label - ${item.name}", action,
            Ai.prompt(action, sub.name, item.week, item.kind, question, lang), listOf(item.id), "local", sub.id, item.week, item.kind, now + 1)
        modify { it.copy(chat = it.chat + user + ai) }
        return false
    }

    fun enqueueChat(text: String, mode: String, fileIds: List<String>, subjectId: String) {
        val now = System.currentTimeMillis()
        val user = Entry(newId(), "user", text, "done", "", "chat", "", emptyList(), mode, subjectId, 0, "", now)
        val ai = Entry(newId(), "ai", "", "queued", text.take(40), "chat", text, fileIds, mode, subjectId, 0, "", now + 1)
        modify { it.copy(chat = it.chat + user + ai) }
    }

    fun nextQueued(): Entry? = data.chat.firstOrNull { it.role == "ai" && it.status == "queued" }
    fun setStatus(id: String, status: String) = modify { d -> d.copy(chat = d.chat.map { if (it.id == id) it.copy(status = status) else it }) }
    fun finishEntry(id: String, text: String, status: String) {
        modify { d -> d.copy(chat = d.chat.map { if (it.id == id) it.copy(text = text, status = status) else it }) }
        live = live - id
    }
    fun retry(id: String) {
        live = live - id
        modify { d -> d.copy(chat = d.chat.map { if (it.id == id) it.copy(text = "", status = "queued") else it }) }
    }
    fun setLive(id: String, text: String) { live = live + (id to text) }
    fun clearChat() = modify { it.copy(chat = emptyList()) }

    /* ---------- study: reviewed checklist ---------- */
    fun toggleDone(key: String) = modify { it.copy(done = if (key in it.done) it.done - key else it.done + key) }

    /* ---------- study: spaced repetition (Leitner boxes) ---------- */
    data class Sr(val box: Int, val due: Long, val reps: Int, val lapses: Int)
    private val srFile = File(ctx.filesDir, "sr.json")
    private val intervals = intArrayOf(0, 1, 2, 4, 8, 16, 32)
    var sr by mutableStateOf(loadSr().first)
        private set
    var studyDays by mutableStateOf(loadSr().second)
        private set

    private fun loadSr(): Pair<Map<String, Sr>, Set<Long>> = try {
        if (!srFile.exists()) emptyMap<String, Sr>() to emptySet() else {
            val o = JSONObject(srFile.readText())
            val m = HashMap<String, Sr>()
            o.optJSONObject("sr")?.let { x -> x.keys().forEach { k -> val a = x.getJSONArray(k); m[k] = Sr(a.getInt(0), a.getLong(1), a.getInt(2), a.getInt(3)) } }
            m to (o.optJSONArray("days")?.let { a -> (0 until a.length()).map { i -> a.getLong(i) }.toSet() } ?: emptySet())
        }
    } catch (e: Exception) { emptyMap<String, Sr>() to emptySet() }

    fun today(): Long = java.time.LocalDate.now().toEpochDay()

    @Synchronized
    private fun saveSr() {
        val o = JSONObject()
        val m = JSONObject()
        sr.forEach { (k, v) -> m.put(k, JSONArray().put(v.box).put(v.due).put(v.reps).put(v.lapses)) }
        o.put("sr", m).put("days", JSONArray(studyDays.toList()))
        srFile.writeText(o.toString())
    }

    /** grade: 0 = again, 1 = good, 2 = easy */
    fun srReview(id: String, grade: Int) {
        val cur = sr[id] ?: Sr(0, today(), 0, 0)
        val box = when (grade) { 0 -> 0; 1 -> minOf(cur.box + 1, 6); else -> minOf(cur.box + 2, 6) }
        val due = today() + (if (grade == 0) 0 else intervals[box])
        sr = sr + (id to Sr(box, due, cur.reps + 1, cur.lapses + (if (grade == 0) 1 else 0)))
        studyDays = studyDays + today()
        saveSr()
    }

    fun dueCount(): Int = sr.values.count { it.due <= today() }

    fun streak(): Int {
        var d = today()
        if (d !in studyDays) d -= 1
        var n = 0
        while (d in studyDays) { n++; d -= 1 }
        return n
    }
}
