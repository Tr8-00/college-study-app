package com.tr8.scribe

import android.content.Context
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File

data class Sug(val name: String, val lecture: Boolean, val section: Boolean, val lab: Boolean, val on: Boolean = true, val year: Int = 0, val sem: Int = 0, val assignment: Boolean = true)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Wrap(content: @Composable () -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) { content() }
}

/** Typical subjects of the first year in Egyptian faculties (offline). Always check against your own plan. */
fun builtinSubjects(p: Profile, year: Int, sem: Int): List<Sug> {
    val txt = (p.faculty + " " + p.major).lowercase()
    fun s(n: String, sec: Boolean = true, lab: Boolean = false) = Sug(n, true, sec, lab)
    val eng = txt.contains("engineer") || txt.contains("هندس")
    val cs = txt.contains("computer") || txt.contains("information") || txt.contains("حاسب") || txt.contains("معلومات")
    if (year != 1) return emptyList()
    return when {
        eng && sem == 1 -> listOf(s("Mathematics (1)"), s("Physics (1)", lab = true), s("Chemistry", lab = true), s("Engineering Drawing", sec = false, lab = true),
            s("Mechanics (Statics)"), s("Production Engineering", sec = false, lab = true), s("Computer Programming", lab = true), s("English Language", sec = false))
        eng && sem == 2 -> listOf(s("Mathematics (2)"), s("Physics (2)", lab = true), s("Dynamics"), s("Engineering Materials", lab = true),
            s("Technical Writing", sec = false), s("Computer Applications", lab = true))
        cs && sem == 1 -> listOf(s("Programming 1", lab = true), s("Calculus"), s("Discrete Mathematics"), s("Introduction to Computer Science"), s("Physics", lab = true), s("English Language", sec = false))
        cs && sem == 2 -> listOf(s("Programming 2 (OOP)", lab = true), s("Linear Algebra"), s("Probability & Statistics"), s("Digital Logic Design", lab = true), s("Data Structures", lab = true))
        else -> emptyList()
    }
}

fun typeLabel(t: String, ar: Boolean): String = if (!ar) t else when (t) {
    "Public" -> "حكومية"; "Private" -> "خاصة"; "National" -> "أهلية"; "Technological" -> "تكنولوجية"; "International" -> "دولية"; else -> t
}

/** Subject suggestions are about accuracy, so they use the smarter model even when "Fast" is selected. */
fun smartModel(store: Store): String = if (store.model.contains("lite")) "gemini-flash-latest" else store.model

private fun parseSugs(t: String): List<Sug> {
    val arr = JSONArray(Ai.extractJson(t))
    return (0 until arr.length()).map { arr.getJSONObject(it) }.filter { it.optString("name").isNotBlank() }
        .map {
            Sug(it.getString("name").trim(), it.optBoolean("lecture", true), it.optBoolean("section", true), it.optBoolean("lab", false), true,
                it.optInt("year", 0), it.optInt("semester", 0), it.optBoolean("assignment", true))
        }
}

/** Looks for the official study plan with Google Search. Returns the courses and the web pages it used (so you can check them). */
fun fetchSubjects(store: Store, year: Int, sem: Int): Pair<List<Sug>, List<String>> {
    val p = store.data.profile
    val prompt = "Find the OFFICIAL study plan (course catalogue / program curriculum / bylaws) for ${p.major.ifBlank { p.faculty }} at ${p.university} " +
        "(${p.uniType} university). I need the courses of year $year, semester $sem (semester number ${(year - 1) * 2 + sem} of the program). " +
        "Search the university's own website first. Return ONLY a JSON array like [{\"name\":\"Physics I\",\"lecture\":true,\"section\":true,\"lab\":true}] " +
        "with at most 12 courses. If you cannot find the official plan for this exact major and semester, return [] instead of guessing."
    return try {
        val (t, src) = Ai.askSrc(store.apiKey, smartModel(store), prompt)
        parseSugs(t) to src
    } catch (e: ApiError) {
        parseSugs(Ai.ask(store.apiKey, smartModel(store), prompt, null, null, json = true)) to emptyList()
    }
}

/** Reads a photo / PDF / Word file of your study plan or registration page and returns its courses. */
fun importPlan(store: Store, ctx: Context, uri: Uri): List<Sug> {
    val mime = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
    val f = File(ctx.cacheDir, "plan_import")
    ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
    val ext = when {
        mime == "application/pdf" -> "pdf"; mime.contains("wordprocessingml") -> "docx"
        mime.contains("presentationml") -> "pptx"; mime == "text/plain" -> "txt"; else -> ""
    }
    val prompt = "This is a university study plan, course list or registration page. Extract every course (subject). " +
        "Return ONLY a JSON array like [{\"name\":\"Physics I\",\"year\":1,\"semester\":1,\"lecture\":true,\"section\":true,\"lab\":true}]. " +
        "year and semester: the numbers shown in the document, or 0 if not shown. lecture/section/lab: true if the course has them " +
        "(use the hours columns if present; otherwise lecture and section true). Keep course names as written."
    var text: String? = null
    if (ext.isNotEmpty()) {
        val lines = try { Scanner.extract(ctx, f, "x.$ext") } catch (e: Throwable) { null }
        val t = lines?.joinToString("\n") { it.text } ?: ""
        if (t.length > 100) text = t.take(40000)
    }
    val raw = when {
        text != null -> Ai.ask(store.apiKey, smartModel(store), prompt + "\n\nDOCUMENT TEXT:\n" + text, null, null, json = true)
        mime in AI_MIMES -> Ai.ask(store.apiKey, smartModel(store), prompt, f, mime, json = true)
        else -> throw Exception("Choose a photo, PDF or Word file of your study plan.")
    }
    f.delete()
    return parseSugs(raw)
}

@Composable
fun SuggestBody(store: Store, year: Int, sem: Int, confirmLabel: String, onConfirm: (List<Sug>) -> Unit) {
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val p = store.data.profile
    var list by remember { mutableStateOf<List<Sug>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val none = tr("No typical list for this faculty and year. Import your study plan below, or add subjects by hand.", "لا توجد قائمة معتادة لهذه الكلية والسنة. استورد خطتك الدراسية بالأسفل أو أضف المواد يدوياً.")
    val builtin = tr("Typical subjects for this year. Edit them to match your real plan.", "المواد المعتادة لهذه السنة. عدّلها لتناسب خطتك الحقيقية.")
    val aiNote = tr("From the web: check these against your real plan before adding. Pages used:", "من الإنترنت: راجعها مع خطتك الحقيقية قبل الإضافة. الصفحات المستخدمة:")
    val planDone = tr("Read from your file. Tick the ones you want.", "تمت القراءة من ملفك. اختر ما تريد.")
    val planNone = tr("I couldn't find a course list in that file. A PDF or Word file works best.", "لم أجد قائمة مواد في هذا الملف. ملف PDF أو Word يعمل بشكل أفضل.")
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            loading = true; msg = ""
            scope.launch {
                try {
                    var r = LocalImport.readPlan(ctx, uri)
                    if (r.isEmpty() && store.apiKey.isNotBlank()) r = withContext(Dispatchers.IO) { importPlan(store, ctx, uri) }
                    list = r
                    msg = if (r.isEmpty()) planNone else planDone
                } catch (e: Exception) { msg = e.message ?: "Error" }
                loading = false
            }
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(enabled = !loading, onClick = {
            list = builtinSubjects(p, year, sem)
            msg = if (list.isEmpty()) none else builtin
        }) { Text(tr("✨ Suggest typical subjects", "✨ اقترح المواد المعتادة")) }
        OutlinedButton(enabled = !loading, onClick = { picker.launch(arrayOf("image/*", "application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/plain")) }) {
            Text(tr("📄 Import my study plan (photo / PDF / Word)", "📄 استيراد خطتي الدراسية (صورة / PDF / Word)"))
        }
        if (store.apiKey.isNotBlank()) {
            TextButton(enabled = !loading, onClick = {
                loading = true; msg = ""
                scope.launch {
                    try {
                        val (l, src) = withContext(Dispatchers.IO) { fetchSubjects(store, year, sem) }
                        list = l
                        msg = if (l.isEmpty()) none else aiNote + "\n" + src.take(3).joinToString("\n")
                    } catch (e: Exception) { msg = e.message ?: "Couldn't reach the internet." }
                    loading = false
                }
            }) { Text(tr("🌐 Search the web with AI (optional)", "🌐 ابحث في الإنترنت بالذكاء الاصطناعي (اختياري)"), color = C.dim) }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = C.accent)
        if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = C.dim)
        list.forEachIndexed { i, sg ->
            Row(
                Modifier.fillMaxWidth().clickable { list = list.mapIndexed { j, x -> if (j == i) x.copy(on = !x.on) else x } },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(sg.on, { list = list.mapIndexed { j, x -> if (j == i) x.copy(on = !x.on) else x } })
                Column {
                    Text(sg.name, fontSize = 15.sp, color = C.text)
                    Text(
                        listOfNotNull(if (sg.lecture) tr("Lecture", "محاضرة") else null, if (sg.section) tr("Section", "سكشن") else null,
                            if (sg.assignment) tr("Assignment", "واجب") else null, if (sg.lab) tr("Lab", "معمل") else null).joinToString(" • ") +
                            (if (sg.year > 0) "  ·  " + tr("Y${sg.year}", "س${sg.year}") + (if (sg.sem > 0) " S${sg.sem}" else "") else ""),
                        fontSize = 12.sp, color = C.dim
                    )
                }
            }
        }
        if (list.isNotEmpty()) Button(onClick = { onConfirm(list.filter { it.on }) }) { Text("$confirmLabel (${list.count { it.on }})") }
    }
}

@Composable
fun Onboarding(store: Store) {
    val ctx = LocalContext.current
    val ar = store.lang == "ar"
    val p = store.data.profile
    var step by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf(p.name) }
    var uniType by remember { mutableStateOf(p.uniType) }
    var uniQuery by remember { mutableStateOf("") }
    var uni by remember { mutableStateOf(p.university) }
    var faculty by remember { mutableStateOf(p.faculty) }
    var major by remember { mutableStateOf(p.major) }
    var year by remember { mutableIntStateOf(p.year) }
    var sem by remember { mutableIntStateOf(p.sem) }
    val last = 3
    BackHandler(enabled = step > 0) { step-- }

    fun finish(chosen: List<Sug>) {
        store.setProfile { Profile(name.trim(), uniType, uni.trim(), faculty, major.trim(), year, sem, true) }
        chosen.forEach { store.addSubject(it.name, if (it.year > 0) it.year else year, if (it.sem > 0) it.sem else sem, it.lecture, it.section, it.lab, it.assignment) }
        store.saveSettings()
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        TopBar(store, "Scribe")
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.Center) {
            (0..last).forEach { i ->
                Box(Modifier.padding(3.dp).size(if (i == step) 10.dp else 7.dp).clip(CircleShape).background(if (i == step) C.accent else C.dim))
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            when (step) {
                0 -> {
                    Text("📖", fontSize = 56.sp)
                    Serif(tr("Welcome to Scribe", "مرحباً بك في Scribe"), 30.sp)
                    Text(tr("Your private study notebook: lectures, sheets, labs, schedule and study tools. Everything works offline, and your files never leave your phone.",
                        "دفترك الدراسي الخاص: المحاضرات والشيتات والمعامل والجدول وأدوات المذاكرة. كل شيء يعمل بدون إنترنت وملفاتك لا تغادر هاتفك."), color = C.dim)
                    OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(tr("Choose a username", "اختر اسم مستخدم")) })
                }
                1 -> {
                    Serif(tr("Your university", "جامعتك"), 24.sp)
                    Wrap { EgyptDb.TYPES.forEach { t -> FilterChip(uniType == t, { uniType = if (uniType == t) "" else t }, { Text(typeLabel(t, ar)) }) } }
                    OutlinedTextField(uniQuery, { uniQuery = it }, Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(24.dp),
                        label = { Text(tr("Search: Cairo, AASTMT, Ain Shams, MSA…", "ابحث: القاهرة، AASTMT، عين شمس…")) })
                    val found = EgyptDb.search(ctx, uniQuery, uniType)
                    found.take(12).forEach { u ->
                        Column(Modifier.fillMaxWidth().clickable { uni = if (ar) u.ar else u.en; uniType = u.type; faculty = ""; major = "" }.padding(vertical = 8.dp)) {
                            Text(if (ar) u.ar else u.en, color = if (uni == u.en || uni == u.ar) C.accent else C.text, fontSize = 15.sp)
                            Text(typeLabel(u.type, ar) + " · " + u.city, color = C.dim, fontSize = 12.sp)
                        }
                        HorizontalDivider(color = C.dim.copy(alpha = 0.2f))
                    }
                    if (found.isEmpty()) Text(tr("Not in the list? Type your university's name below.", "غير موجودة في القائمة؟ اكتب اسم جامعتك بالأسفل."), color = C.dim, fontSize = 13.sp)
                    OutlinedTextField(uni, { uni = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(tr("My university", "جامعتي")) })
                }
                2 -> {
                    Serif(tr("Your studies", "دراستك"), 24.sp)
                    Wrap { EgyptDb.faculties(ctx, uni).forEach { f -> FilterChip(faculty == f, { faculty = f; major = "" }, { Text(EgyptDb.facultyLabel(ctx, f, ar)) }) } }
                    OutlinedTextField(faculty, { faculty = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(tr("Faculty (or type your own)", "الكلية (أو اكتب كليتك)")) })
                    Wrap { EgyptDb.majors(ctx, uni, faculty).forEach { m -> FilterChip(major == m.en, { major = m.en }, { Text(if (ar) m.ar else m.en) }) } }
                    OutlinedTextField(major, { major = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(tr("Major / department (or type your own)", "التخصص / القسم (أو اكتب تخصصك)")) })
                    Text(tr("These lists are typical. Faculties differ, so check yours or type your own.", "هذه القوائم معتادة. تختلف الكليات، فراجع كليتك أو اكتبها."), fontSize = 12.sp, color = C.dim)
                    Text(tr("Current year", "السنة الدراسية"), color = C.dim, fontSize = 13.sp)
                    Wrap { (1..5).forEach { y -> FilterChip(year == y, { year = y }, { Text("$y") }) } }
                    Text(tr("Current semester", "الفصل الحالي"), color = C.dim, fontSize = 13.sp)
                    Wrap { (1..2).forEach { x -> FilterChip(sem == x, { sem = x }, { Text("$x") }) } }
                }
                else -> {
                    Serif(tr("Your subjects", "موادك"), 24.sp)
                    Text(tr("Pick the typical subjects for your year, or import your study plan. You can add the rest by hand later.",
                        "اختر المواد المعتادة لسنتك أو استورد خطتك الدراسية. يمكنك إضافة الباقي يدوياً لاحقاً."), color = C.dim)
                    LaunchedEffect(Unit) { store.setProfile { it.copy(university = uni.trim(), uniType = uniType, faculty = faculty, major = major.trim(), year = year, sem = sem) } }
                    SuggestBody(store, year, sem, tr("Add selected & finish", "أضف المحدد وأنهِ")) { chosen -> finish(chosen) }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (step > 0) OutlinedButton(onClick = { step-- }) { Text(tr("Back", "رجوع")) }
            Spacer(Modifier.weight(1f))
            if (step < last) {
                Button(enabled = (step != 0 || name.isNotBlank()) && (step != 1 || uni.isNotBlank()), onClick = { step++ }) { Text(tr("Next", "التالي")) }
            } else {
                TextButton(onClick = { finish(emptyList()) }) { Text(tr("Skip & finish", "تخطي وإنهاء")) }
            }
        }
    }
}
