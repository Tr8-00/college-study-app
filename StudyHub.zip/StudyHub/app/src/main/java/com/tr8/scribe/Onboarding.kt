package com.tr8.scribe

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray

data class Sug(val name: String, val lecture: Boolean, val section: Boolean, val lab: Boolean, val on: Boolean = true)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Wrap(content: @Composable () -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) { content() }
}

fun builtinSubjects(p: Profile, year: Int, sem: Int): List<Sug> {
    val txt = p.faculty + " " + p.major
    val eng = txt.contains("engineer", true) || txt.contains("هندس")
    if (!eng || year != 1) return emptyList()
    return if (sem == 1) listOf(
        Sug("Calculus I", true, true, false), Sug("Physics I", true, true, true), Sug("Chemistry", true, false, true),
        Sug("Engineering Drawing", true, false, true), Sug("English (Technical)", true, true, false),
        Sug("Introduction to Programming", true, true, true), Sug("Manufacturing Technology", true, true, true)
    ) else listOf(
        Sug("Calculus II", true, true, false), Sug("Physics II", true, true, true), Sug("Linear Algebra", true, true, false),
        Sug("Statics", true, true, false), Sug("Materials Science", true, false, true), Sug("Technical Writing", true, true, false)
    )
}

fun fetchSubjects(store: Store, year: Int, sem: Int): List<Sug> {
    val p = store.data.profile
    val prompt = "A student studies ${p.major.ifBlank { p.faculty }} at ${p.university} (${p.uniType} university). " +
        "Year $year, semester $sem. Using web search if useful, list the courses typically taken in this exact semester (max 10). " +
        "Return ONLY a JSON array like [{\"name\":\"Physics I\",\"lecture\":true,\"section\":true,\"lab\":true}] and nothing else. " +
        "If unsure, give the most typical courses for this major and year."
    val t = try { Ai.ask(store.apiKey, store.model, prompt, null, null, search = true) }
    catch (e: ApiError) { Ai.ask(store.apiKey, store.model, prompt, null, null, json = true) }
    val arr = JSONArray(Ai.extractJson(t))
    return (0 until arr.length()).map { arr.getJSONObject(it) }.filter { it.optString("name").isNotBlank() }
        .map { Sug(it.getString("name"), it.optBoolean("lecture", true), it.optBoolean("section", true), it.optBoolean("lab", false)) }
}

fun fetchMajors(store: Store): List<String> {
    val p = store.data.profile
    val prompt = "List the main majors or departments offered by ${p.university} in the faculty of ${p.faculty.ifBlank { "engineering" }}. " +
        "Use web search if useful. Return ONLY a JSON array of short strings (max 12)."
    val t = try { Ai.ask(store.apiKey, store.model, prompt, null, null, search = true) }
    catch (e: ApiError) { Ai.ask(store.apiKey, store.model, prompt, null, null, json = true) }
    val arr = JSONArray(Ai.extractJson(t))
    return (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
}

@Composable
fun SuggestBody(store: Store, year: Int, sem: Int, confirmLabel: String, onConfirm: (List<Sug>) -> Unit) {
    val scope = rememberCoroutineScope()
    val p = store.data.profile
    var list by remember { mutableStateOf<List<Sug>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val none = tr("No suggestions found. You can add subjects by hand.", "لم أجد اقتراحات. يمكنك إضافة المواد يدوياً.")
    val keyHint = tr(" (Add a free Gemini key in Settings for smarter suggestions.)", " (أضف مفتاح Gemini المجاني من الإعدادات لاقتراحات أذكى.)")
    val builtin = tr("Typical first-year subjects. Edit them to match your real plan.", "مواد السنة الأولى المعتادة. عدّلها لتناسب خطتك.")
    val aiNote = tr("AI suggestions: check them against your real schedule.", "اقتراحات الذكاء الاصطناعي: راجعها مع جدولك الحقيقي.")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(enabled = !loading, onClick = {
            loading = true; msg = ""
            scope.launch {
                try {
                    if (store.apiKey.isBlank()) {
                        list = builtinSubjects(p, year, sem)
                        msg = if (list.isEmpty()) none + keyHint else builtin
                    } else {
                        list = withContext(Dispatchers.IO) { fetchSubjects(store, year, sem) }
                        msg = if (list.isEmpty()) none else aiNote
                    }
                } catch (e: Exception) {
                    list = builtinSubjects(p, year, sem)
                    msg = (e.message ?: "Couldn't reach the internet.") + if (list.isEmpty()) "" else "\n$builtin"
                }
                loading = false
            }
        }) { Text(if (loading) tr("Searching…", "جارٍ البحث…") else tr("✨ Find my subjects", "✨ اقترح موادي")) }
        if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = C.dim)
        list.forEachIndexed { i, s ->
            Row(
                Modifier.fillMaxWidth().clickable { list = list.mapIndexed { j, x -> if (j == i) x.copy(on = !x.on) else x } },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(s.on, { list = list.mapIndexed { j, x -> if (j == i) x.copy(on = !x.on) else x } })
                Column {
                    Text(s.name, fontSize = 15.sp, color = C.text)
                    Text(
                        listOfNotNull(if (s.lecture) tr("Lecture", "محاضرة") else null, if (s.section) tr("Section", "سكشن") else null,
                            if (s.lab) tr("Lab", "معمل") else null).joinToString(" • "),
                        fontSize = 12.sp, color = C.dim
                    )
                }
            }
        }
        if (list.isNotEmpty()) Button(onClick = { onConfirm(list.filter { it.on }) }) { Text("$confirmLabel (${list.count { it.on }})") }
    }
}

@Composable
fun Onboarding(store: Store) {
    val scope = rememberCoroutineScope()
    val uri = LocalUriHandler.current
    val p = store.data.profile
    var step by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf(p.name) }
    var uniType by remember { mutableStateOf(p.uniType) }
    var uni by remember { mutableStateOf(p.university) }
    var country by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var searchMsg by remember { mutableStateOf("") }
    var faculty by remember { mutableStateOf(p.faculty) }
    var major by remember { mutableStateOf(p.major) }
    var majors by remember { mutableStateOf<List<String>>(emptyList()) }
    var majorMsg by remember { mutableStateOf("") }
    var finding by remember { mutableStateOf(false) }
    var year by remember { mutableIntStateOf(p.year) }
    var sem by remember { mutableIntStateOf(p.sem) }
    val last = 4
    BackHandler(enabled = step > 0) { step-- }

    fun finish(chosen: List<Sug>) {
        store.setProfile { Profile(name.trim(), uniType, uni.trim(), faculty, major.trim(), year, sem, true) }
        chosen.forEach { store.addSubject(it.name, year, sem, it.lecture, it.section, it.lab) }
        store.saveSettings()
    }

    val types = listOf("Public" to "حكومية", "Private" to "خاصة", "National" to "أهلية", "Technological" to "تكنولوجية", "International" to "دولية", "Online" to "عن بُعد")
    val faculties = listOf("Engineering" to "الهندسة", "Computer Science & IT" to "الحاسبات والمعلومات", "Science" to "العلوم", "Medicine" to "الطب",
        "Pharmacy" to "الصيدلة", "Business" to "التجارة وإدارة الأعمال", "Arts" to "الآداب", "Law" to "الحقوق", "Other" to "أخرى")

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        TopBar(store, "Scribe")
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.Center) {
            (0..last).forEach { i ->
                Box(Modifier.padding(3.dp).size(if (i == step) 10.dp else 7.dp).clip(CircleShape).background(if (i == step) C.accent else C.dim))
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            when (step) {
                0 -> {
                    Text("📖", fontSize = 56.sp)
                    Serif(tr("Welcome to Scribe", "مرحباً بك في Scribe"), 30.sp)
                    Text(tr("Your private study notebook: lectures, sheets, labs, schedule and an AI study buddy. Your files stay on your phone.",
                        "دفترك الدراسي الخاص: المحاضرات والشيتات والمعامل والجدول ومساعد ذكي. ملفاتك تبقى على هاتفك."), color = C.dim)
                    OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true,
                        label = { Text(tr("Choose a username", "اختر اسم مستخدم")) })
                }
                1 -> {
                    Serif(tr("Connect AI (optional)", "اربط الذكاء الاصطناعي (اختياري)"), 24.sp)
                    Text(tr("Scribe uses Google's free Gemini with your own key to suggest subjects, read files and chat. You can skip this and add it later in Settings.",
                        "يستخدم Scribe خدمة Gemini المجانية من Google بمفتاحك الخاص لاقتراح المواد وقراءة الملفات والمحادثة. يمكنك التخطي وإضافته لاحقاً."), color = C.dim)
                    OutlinedButton(onClick = { uri.openUri("https://aistudio.google.com/app/apikey") }) { Text(tr("Get a free key", "احصل على مفتاح مجاني")) }
                    OutlinedTextField(store.apiKey, { store.apiKey = it; store.saveSettings() }, Modifier.fillMaxWidth(), singleLine = true,
                        label = { Text("Gemini API key") }, visualTransformation = PasswordVisualTransformation())
                }
                2 -> {
                    Serif(tr("Your university", "جامعتك"), 24.sp)
                    Wrap { types.forEach { (en, ar) -> FilterChip(uniType == en, { uniType = en }, { Text(tr(en, ar)) }) } }
                    Text(tr("🌐 Searching needs an internet connection.", "🌐 البحث يحتاج اتصالاً بالإنترنت."), fontSize = 13.sp, color = C.dim)
                    OutlinedTextField(uni, { uni = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(tr("University name", "اسم الجامعة")) })
                    OutlinedTextField(country, { country = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(tr("Country (optional, helps the search)", "الدولة (اختياري)")) })
                    Button(enabled = !searching && uni.isNotBlank(), onClick = {
                        searching = true; searchMsg = ""
                        scope.launch {
                            try {
                                results = withContext(Dispatchers.IO) { Ai.universities(uni.trim(), country.trim()) }
                                searchMsg = if (results.isEmpty()) "Nothing found. You can keep what you typed." else ""
                            } catch (e: Exception) {
                                results = emptyList()
                                searchMsg = "Couldn't search (no internet?). You can just keep the name you typed."
                            }
                            searching = false
                        }
                    }) { Text(if (searching) tr("Searching…", "جارٍ البحث…") else tr("🔎 Search", "🔎 بحث")) }
                    if (searchMsg.isNotEmpty()) Text(searchMsg, fontSize = 13.sp, color = C.rose)
                    results.forEach { (n, c) ->
                        Row(Modifier.fillMaxWidth().clickable { uni = n; if (country.isBlank()) country = c; results = emptyList() }.padding(vertical = 8.dp)) {
                            Column {
                                Text(n, color = C.text, fontSize = 15.sp)
                                Text(c, color = C.dim, fontSize = 12.sp)
                            }
                        }
                        HorizontalDivider(color = C.dim.copy(alpha = 0.2f))
                    }
                }
                3 -> {
                    Serif(tr("Your studies", "دراستك"), 24.sp)
                    Wrap { faculties.forEach { (en, ar) -> FilterChip(faculty == en, { faculty = en }, { Text(tr(en, ar)) }) } }
                    OutlinedTextField(major, { major = it }, Modifier.fillMaxWidth(), singleLine = true,
                        label = { Text(tr("Major / department (e.g. Mechanical Engineering)", "التخصص / القسم (مثال: هندسة ميكانيكية)")) })
                    OutlinedButton(enabled = !finding && store.apiKey.isNotBlank() && uni.isNotBlank(), onClick = {
                        finding = true; majorMsg = ""
                        store.setProfile { it.copy(university = uni.trim(), faculty = faculty) }
                        scope.launch {
                            try {
                                majors = withContext(Dispatchers.IO) { fetchMajors(store) }
                                if (majors.isEmpty()) majorMsg = "Nothing found. Type your major above."
                            } catch (e: Exception) { majorMsg = e.message ?: "Couldn't search." }
                            finding = false
                        }
                    }) { Text(if (finding) tr("Searching…", "جارٍ البحث…") else tr("✨ Find majors at my university", "✨ ابحث عن التخصصات في جامعتي")) }
                    if (store.apiKey.isBlank()) Text(tr("Add a Gemini key (previous step) to search majors.", "أضف مفتاح Gemini (الخطوة السابقة) للبحث عن التخصصات."), fontSize = 12.sp, color = C.dim)
                    if (majorMsg.isNotEmpty()) Text(majorMsg, fontSize = 13.sp, color = C.rose)
                    Wrap { majors.forEach { m -> FilterChip(major == m, { major = m }, { Text(m) }) } }
                    Text(tr("Current year", "السنة الدراسية"), color = C.dim, fontSize = 13.sp)
                    Wrap { (1..5).forEach { y -> FilterChip(year == y, { year = y }, { Text("$y") }) } }
                    Text(tr("Current semester", "الفصل الحالي"), color = C.dim, fontSize = 13.sp)
                    Wrap { (1..2).forEach { s -> FilterChip(sem == s, { sem = s }, { Text("$s") }) } }
                }
                else -> {
                    Serif(tr("Your subjects", "موادك"), 24.sp)
                    Text(tr("Let Scribe suggest what you may be studying this semester, tick the right ones, and add the rest by hand later.",
                        "دع Scribe يقترح المواد التي قد تدرسها هذا الفصل، اختر الصحيح منها، وأضف الباقي يدوياً لاحقاً."), color = C.dim)
                    // keep the typed details so suggestions can use them
                    LaunchedEffect(Unit) { store.setProfile { it.copy(university = uni.trim(), uniType = uniType, faculty = faculty, major = major.trim(), year = year, sem = sem) } }
                    SuggestBody(store, year, sem, tr("Add selected & finish", "أضف المحدد وأنهِ")) { chosen -> finish(chosen) }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (step > 0) OutlinedButton(onClick = { step-- }) { Text(tr("Back", "رجوع")) }
            Spacer(Modifier.weight(1f))
            if (step == 1) TextButton(onClick = { step++ }) { Text(tr("Skip", "تخطي")) }
            if (step < last) {
                Button(
                    enabled = (step != 0 || name.isNotBlank()) && (step != 2 || uni.isNotBlank()),
                    onClick = { step++ }
                ) { Text(tr("Next", "التالي")) }
            } else {
                TextButton(onClick = { finish(emptyList()) }) { Text(tr("Skip & finish", "تخطي وإنهاء")) }
            }
        }
    }
}
