package com.tr8.scribe

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ensureChannels(this)
        Reminders.scheduleAll(this)
        handle(intent)
        setContent { StudyApp() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        val t = i?.getIntExtra("tab", -1) ?: -1
        if (t >= 0) Store.get(this).pendingTab = t
    }

    override fun onStart() { super.onStart(); Store.get(this).visible = true }
    override fun onStop() { super.onStop(); Store.get(this).visible = false }
}

@Composable
fun StudyApp() {
    val ctx = LocalContext.current
    val store = remember { Store.get(ctx) }
    val dark = store.theme == "dark"
    val pal = if (dark) DarkPal else LightPal
    val dir = if (store.lang == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr
    val scheme = if (dark) darkColorScheme(
        primary = pal.accent, onPrimary = pal.onAccent, background = pal.bg, onBackground = pal.text, surface = pal.card, onSurface = pal.text,
        surfaceVariant = pal.card, onSurfaceVariant = pal.text, secondaryContainer = pal.accent.copy(alpha = 0.3f), onSecondaryContainer = pal.text,
        surfaceContainerHigh = pal.card, surfaceContainer = pal.card, surfaceContainerHighest = pal.card
    ) else lightColorScheme(
        primary = pal.accent, onPrimary = pal.onAccent, background = pal.bg, onBackground = pal.text, surface = pal.card, onSurface = pal.text,
        surfaceVariant = pal.card, onSurfaceVariant = pal.text, secondaryContainer = pal.accent.copy(alpha = 0.25f), onSecondaryContainer = pal.text,
        surfaceContainerHigh = pal.card, surfaceContainer = pal.card, surfaceContainerHighest = pal.card
    )
    CompositionLocalProvider(LocalPal provides pal, LocalLang provides store.lang, LocalLayoutDirection provides dir) {
        MaterialTheme(colorScheme = scheme) {
            Surface(Modifier.fillMaxSize(), color = pal.bg, contentColor = pal.text) {
                if (!store.data.profile.done) Onboarding(store) else MainShell(store)
            }
        }
    }
}

@Composable
fun MainShell(store: Store) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var openId by remember { mutableStateOf<String?>(null) }
    BackHandler(enabled = openId != null) { openId = null }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (!store.askedNotif && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            store.askedNotif = true
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    LaunchedEffect(store.pendingTab) {
        if (store.pendingTab >= 0) { tab = store.pendingTab; openId = null; store.pendingTab = -1 }
    }

    val sub = store.data.subjects.firstOrNull { it.id == openId }
    if (sub != null) {
        SubjectScreen(store, sub) { openId = null }
        return
    }
    val tabs = listOf(
        "📚" to tr("Courses", "المقررات"), "🗓" to tr("Schedule", "الجدول"), "✨" to tr("Ask AI", "المساعد"),
        "📁" to tr("Files", "الملفات"), "⚙" to tr("Settings", "الإعدادات")
    )
    Scaffold(
        containerColor = C.bg,
        bottomBar = {
            NavigationBar(containerColor = C.card) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(t.first, fontSize = 20.sp) }, label = { Text(t.second, fontSize = 11.sp, maxLines = 1) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).statusBarsPadding().fillMaxSize()) {
            when (tab) {
                0 -> CoursesTab(store) { openId = it }
                1 -> ScheduleTab(store)
                2 -> ChatTab(store)
                3 -> FilesTab(store)
                else -> SettingsTab(store)
            }
        }
    }
}
