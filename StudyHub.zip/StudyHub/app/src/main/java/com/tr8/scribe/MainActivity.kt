package com.tr8.scribe

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ensureChannels(this)
        Reminders.scheduleAll(this)
        handle(intent)
        setContent { StudyApp() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    @Suppress("DEPRECATION")
    private fun handle(i: Intent?) {
        val t = i?.getIntExtra("tab", -1) ?: -1
        if (t >= 0) Store.get(this).pendingTab = t
        if (i != null && (i.action == Intent.ACTION_SEND || i.action == Intent.ACTION_SEND_MULTIPLE)) {
            val found = LinkedHashSet<Uri>()
            if (i.action == Intent.ACTION_SEND) {
                (if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) else i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))?.let { found.add(it) }
            } else {
                (if (Build.VERSION.SDK_INT >= 33) i.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java) else i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM))?.let { found.addAll(it) }
            }
            i.clipData?.let { cd -> for (k in 0 until cd.itemCount) cd.getItemAt(k).uri?.let { found.add(it) } }
            if (found.isNotEmpty()) SharedIn.uris = SharedIn.uris + found
            i.action = null
        }
    }

    override fun onStart() { super.onStart(); Store.get(this).visible = true }
    override fun onStop() { super.onStop(); Store.get(this).visible = false }
}

@Composable
fun StudyApp() {
    val ctx = LocalContext.current
    val store = remember { Store.get(ctx) }
    val dark = store.theme == "dark"
    val pal = if (dark) DarkPal else LightPal
    val dir = if (store.lang == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr
    val scheme = if (dark) darkColorScheme(
        primary = pal.accent, onPrimary = pal.onAccent, background = pal.bg, onBackground = pal.text, surface = pal.card, onSurface = pal.text,
        surfaceVariant = pal.card, onSurfaceVariant = pal.text, secondaryContainer = pal.accent.copy(alpha = 0.3f), onSecondaryContainer = pal.text,
        surfaceContainerHigh = pal.card, surfaceContainer = pal.card, surfaceContainerHighest = pal.card
    ) else lightColorScheme(
        primary = pal.accent, onPrimary = pal.onAccent, background = pal.bg, onBackground = pal.text, surface = pal.card, onSurface = pal.text,
        surfaceVariant = pal.card, onSurfaceVariant = pal.text, secondaryContainer = pal.accent.copy(alpha = 0.25f), onSecondaryContainer = pal.text,
        surfaceContainerHigh = pal.card, surfaceContainer = pal.card, surfaceContainerHighest = pal.card
    )
    CompositionLocalProvider(LocalPal provides pal, LocalLang provides store.lang, LocalLayoutDirection provides dir) {
        MaterialTheme(colorScheme = scheme) {
            Surface(Modifier.fillMaxSize(), color = pal.bg, contentColor = pal.text) {
                if (!store.data.profile.done) Onboarding(store) else MainShell(store)
                if (store.data.profile.done && SharedIn.uris.isNotEmpty()) {
                    key(SharedIn.uris) { ImportSortDialog(store, SharedIn.uris) { SharedIn.uris = emptyList() } }
                }
            }
        }
    }
}

@Composable
fun MainShell(store: Store) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var openId by remember { mutableStateOf<String?>(null) }
    BackHandler(enabled = openId != null) { openId = null }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (!store.askedNotif && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            store.askedNotif = true
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    LaunchedEffect(store.pendingTab) {
        if (store.pendingTab >= 0) { tab = store.pendingTab; openId = null; store.pendingTab = -1 }
    }

    val sign = if (store.lang == "ar") -1 else 1

    // Ask AI shortcut: hides while scrolling down, never shows inside Study sub-screens,
    // and can be dragged out of the way.
    var fabVisible by remember { mutableStateOf(true) }
    var studyBusy by remember { mutableStateOf(false) }
    var fabOff by remember { mutableStateOf(Offset.Zero) }
    LaunchedEffect(tab) { fabVisible = true }
    val fabScroll = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < -6f) fabVisible = false else if (available.y > 6f) fabVisible = true
                return Offset.Zero
            }
        }
    }
    val cfg = LocalConfiguration.current
    val density = LocalDensity.current
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val maxX = with(density) { (cfg.screenWidthDp.dp - 140.dp).toPx() }
    val maxY = with(density) { (cfg.screenHeightDp.dp - 260.dp).toPx() }
    val tabs = listOf(
        "📚" to tr("Courses", "المقررات"), "🗓" to tr("Schedule", "الجدول"), "✨" to tr("Ask AI", "المساعد"),
        "📖" to tr("Study", "المذاكرة"), "⚙" to tr("Settings", "الإعدادات")
    )
    AnimatedContent(
        targetState = openId,
        transitionSpec = {
            if (targetState != null) (slideInHorizontally(tween(340, easing = FastOutSlowInEasing)) { sign * it / 3 } + fadeIn(tween(340))) togetherWith
                (slideOutHorizontally(tween(340, easing = FastOutSlowInEasing)) { -sign * it / 6 } + fadeOut(tween(200)))
            else (slideInHorizontally(tween(340, easing = FastOutSlowInEasing)) { -sign * it / 6 } + fadeIn(tween(340))) togetherWith
                (slideOutHorizontally(tween(340, easing = FastOutSlowInEasing)) { sign * it / 3 } + fadeOut(tween(200)))
        },
        label = "screens"
    ) { id ->
        val sub = store.data.subjects.firstOrNull { it.id == id }
        if (sub != null) {
            SubjectScreen(store, sub, onBack = { openId = null }, onAskAi = { week ->
                store.chatSubjectId = sub.id
                store.chatWeek = week
                if (store.chatMode == "online") store.chatMode = "both"
                store.saveSettings()
                tab = 2
                openId = null
            })
        } else {
            Scaffold(
                containerColor = C.bg,
                bottomBar = {
                    NavigationBar(containerColor = C.card) {
                        tabs.forEachIndexed { i, t ->
                            NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(t.first, fontSize = 20.sp) }, label = { Text(t.second, fontSize = 11.sp, maxLines = 1) })
                        }
                    }
                },
                floatingActionButton = {
                    AnimatedVisibility(visible = tab != 2 && tab != 4 && !(tab == 3 && studyBusy) && fabVisible, enter = scaleIn(tween(250)) + fadeIn(), exit = scaleOut(tween(150)) + fadeOut()) {
                        ExtendedFloatingActionButton(
                            onClick = { tab = 2 },
                            containerColor = C.accent, contentColor = C.onAccent,
                            modifier = Modifier
                                .offset { IntOffset(fabOff.x.roundToInt(), fabOff.y.roundToInt()) }
                                .pointerInput(rtl) {
                                    detectDragGestures { change, drag ->
                                        change.consume()
                                        val nx = fabOff.x + drag.x
                                        val ny = fabOff.y + drag.y
                                        fabOff = Offset(
                                            if (rtl) nx.coerceIn(0f, maxX) else nx.coerceIn(-maxX, 0f),
                                            ny.coerceIn(-maxY, 0f)
                                        )
                                    }
                                }
                        ) {
                            Text("✨ " + tr("Ask AI", "اسأل"), fontSize = 14.sp)
                        }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad).statusBarsPadding().fillMaxSize().nestedScroll(fabScroll)) {
                    AnimatedContent(
                        targetState = tab,
                        transitionSpec = { (fadeIn(tween(240)) + slideInVertically(tween(280, easing = FastOutSlowInEasing)) { it / 18 }) togetherWith fadeOut(tween(120)) },
                        label = "tabs"
                    ) { t ->
                        when (t) {
                            0 -> CoursesTab(store) { openId = it }
                            1 -> ScheduleTab(store)
                            2 -> ChatTab(store) { tab = 4 }
                            3 -> StudyTab(store) { studyBusy = it }
                            else -> SettingsTab(store)
                        }
                    }
                }
            }
        }
    }
}
