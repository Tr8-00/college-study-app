package com.tr8.scribe

import android.content.Context
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipFile

data class Ln(val page: Int, val text: String, val size: Float)

data class Scan(
    val pages: Int, val words: Int, val scanned: Boolean, val title: String, val chapter: String,
    val headings: List<String>, val definitions: List<String>, val laws: List<String>, val formulas: List<String>,
    val examples: List<String>, val exercises: List<String>, val keywords: List<String>
)

val TEXT_EXTS = setOf("pdf", "pptx", "docx", "txt")

/** Reads text out of PDF / PowerPoint / Word / text files on the phone (no AI, no internet) and organizes it. */
object Scanner {
    private var inited = false

    private class Stripper : PDFTextStripper() {
        val lines = ArrayList<Ln>()
        private val sb = StringBuilder()
        private var size = 0f
        private fun flush() {
            val t = sb.toString().trim()
            if (t.isNotEmpty()) lines.add(Ln(currentPageNo, t, size))
            sb.setLength(0)
            size = 0f
        }
        override fun writeString(text: String, textPositions: MutableList<TextPosition>) {
            sb.append(text)
            val s = textPositions.maxOfOrNull { it.fontSizeInPt } ?: 0f
            if (s > size) size = s
        }
        override fun writeWordSeparator() { sb.append(' ') }
        override fun writeLineSeparator() { flush() }
        override fun writeParagraphEnd() { flush() }
        override fun writePageEnd() { flush() }
    }

    private fun pdfLines(ctx: Context, f: File): List<Ln> {
        if (!inited) { PDFBoxResourceLoader.init(ctx.applicationContext); inited = true }
        PDDocument.load(f).use { doc ->
            val s = Stripper()
            s.sortByPosition = true
            s.endPage = minOf(doc.numberOfPages, 400)
            s.getText(doc)
            return s.lines
        }
    }

    private fun unxml(s: String) = s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'")

    private fun pptxLines(f: File): List<Ln> {
        val out = ArrayList<Ln>()
        ZipFile(f).use { z ->
            val slides = z.entries().toList().filter { Regex("ppt/slides/slide\\d+\\.xml").matches(it.name) }
                .sortedBy { Regex("\\d+").find(it.name.substringAfterLast('/'))!!.value.toInt() }
            slides.forEachIndexed { i, e ->
                val xml = z.getInputStream(e).bufferedReader().readText()
                var first = true
                for (p in Regex("<a:p\\b.*?</a:p>", RegexOption.DOT_MATCHES_ALL).findAll(xml)) {
                    val t = unxml(Regex("<a:t[^>]*>([^<]*)</a:t>").findAll(p.value).joinToString("") { it.groupValues[1] }).trim()
                    if (t.isEmpty()) continue
                    out.add(Ln(i + 1, t, if (first) 28f else 14f))
                    first = false
                }
            }
        }
        return out
    }

    private fun docxLines(f: File): List<Ln> {
        val out = ArrayList<Ln>()
        ZipFile(f).use { z ->
            val e = z.getEntry("word/document.xml") ?: return out
            val xml = z.getInputStream(e).bufferedReader().readText()
            var n = 0
            for (p in Regex("<w:p\\b.*?</w:p>", RegexOption.DOT_MATCHES_ALL).findAll(xml)) {
                val t = unxml(Regex("<w:t[^>]*>([^<]*)</w:t>").findAll(p.value).joinToString("") { it.groupValues[1] }).trim()
                if (t.isEmpty()) continue
                val head = Regex("<w:pStyle w:val=\"(Heading\\d|Title)\"").containsMatchIn(p.value)
                out.add(Ln(n / 40 + 1, t, if (head) 20f else 11f))
                n++
            }
        }
        return out
    }

    /** Returns lines of text, or null when the file type has no readable text (photos). */
    fun extract(ctx: Context, f: File, name: String): List<Ln>? = when (name.substringAfterLast('.', "").lowercase()) {
        "pdf" -> pdfLines(ctx, f)
        "pptx" -> pptxLines(f)
        "docx" -> docxLines(f)
        "txt" -> f.readLines().filter { it.isNotBlank() }.mapIndexed { i, l -> Ln(i / 50 + 1, l.trim(), 11f) }
        else -> null
    }

    fun pages(lines: List<Ln>): List<String> {
        val n = lines.maxOfOrNull { it.page } ?: 0
        val g = lines.groupBy { it.page }
        return (1..n).map { p -> (g[p] ?: emptyList()).joinToString("\n") { it.text } }
    }

    private val chapRe = Regex(
        "^(chapter|unit|lecture|lec\\.?|module|topic|part|week|lesson|الفصل|الباب|الوحدة|المحاضرة)\\s*[\\dIVXivx]+\\b[\\s.:\\-–—]*(.*)$",
        RegexOption.IGNORE_CASE
    )
    private val defRe = Regex("\\b(is defined as|are defined as|is called|are called|is known as|are known as|refers to|is the (ratio|rate|measure|study|process|amount|sum|product)|means that)\\b", RegexOption.IGNORE_CASE)
    private val lawRe = Regex("\\b(law|theorem|principle|postulate|axiom|lemma|corollary|rule of|property of)\\b", RegexOption.IGNORE_CASE)
    private val exRe = Regex("^(worked example|example|ex\\.|ex\\s|مثال)\\b[\\s\\d.:)\\-]*", RegexOption.IGNORE_CASE)
    private val qRe = Regex("^(problem|exercise|question|assignment|q\\s?\\d+|تمرين|سؤال)\\b", RegexOption.IGNORE_CASE)
    private val taskRe = Regex("\\b(find|calculate|determine|show that|prove|compute|what is|solve|derive|evaluate)\\b", RegexOption.IGNORE_CASE)
    private val stop = setOf("the", "and", "that", "this", "with", "from", "have", "will", "are", "for", "not", "can", "which", "their", "also", "such", "than", "then", "when", "where", "there", "these", "those", "into", "each", "other", "more", "most", "been", "were", "was", "its", "has", "had", "but", "all", "any", "one", "two", "may", "use", "used", "using", "chapter", "page", "figure", "example")

    fun analyze(lines: List<Ln>): Scan {
        val pagesN = lines.maxOfOrNull { it.page } ?: 0
        val words = lines.sumOf { it.text.split(Regex("\\s+")).size }
        val chars = lines.sumOf { it.text.length }
        val scanned = lines.isEmpty() || (pagesN > 0 && chars / pagesN < 40)
        val body = lines.filter { it.text.length >= 25 }.map { it.size }.sorted()
        val med = if (body.isNotEmpty()) body[body.size / 2] else (lines.map { it.size }.sorted().getOrNull(lines.size / 2) ?: 11f)

        val heads = ArrayList<String>()
        for (l in lines) {
            val t = l.text
            if (t.length !in 3..100) continue
            val big = l.size >= med * 1.2f && !t.endsWith(".") && !t.endsWith(",")
            if ((big || chapRe.containsMatchIn(t)) && heads.none { it.equals(t, true) }) heads.add(t)
            if (heads.size >= 60) break
        }
        val first = lines.filter { it.page == 1 }
        var title = first.filter { it.size >= med * 1.2f && it.text.length in 3..100 }.maxByOrNull { it.size }?.text
            ?: first.firstOrNull { it.text.length in 3..100 }?.text ?: ""
        if (Regex("microsoft|untitled|\\.docx?|\\.pptx?|^slide", RegexOption.IGNORE_CASE).containsMatchIn(title)) title = ""
        val chapter = lines.filter { it.page <= 3 && it.text.length in 3..100 }.map { it.text }.firstOrNull { chapRe.containsMatchIn(it) } ?: ""

        // merge lines into rough paragraphs
        val paras = ArrayList<String>()
        val cur = StringBuilder()
        var prev: Ln? = null
        for (l in lines) {
            val p = prev
            if (p != null && (p.page != l.page || Math.abs(p.size - l.size) > 0.6f || Regex("[.!?:]$").containsMatchIn(p.text))) {
                if (cur.isNotEmpty()) paras.add(cur.toString().trim()); cur.setLength(0)
            }
            cur.append(l.text).append(' ')
            prev = l
        }
        if (cur.isNotEmpty()) paras.add(cur.toString().trim())

        fun uniq(src: List<String>, max: Int, minLen: Int = 18, maxLen: Int = 260): List<String> {
            val seen = HashSet<String>(); val out = ArrayList<String>()
            for (s in src) { val t = s.trim().take(maxLen); if (t.length < minLen) continue; if (seen.add(t.lowercase())) out.add(t); if (out.size >= max) break }
            return out
        }
        val defs = uniq(paras.filter { defRe.containsMatchIn(it) || it.startsWith("Definition", true) || it.startsWith("تعريف") }, 30)
        val laws = uniq(paras.filter { lawRe.containsMatchIn(it) && it.length <= 320 }, 30)
        val formulas = uniq(lines.map { it.text }.filter { t ->
            t.length <= 90 && (Regex("[=≈≤≥≠∝]").containsMatchIn(t) || (Regex("[∑∫√π±∂Δ]").containsMatchIn(t) && t.any { it.isDigit() || it == '(' })) &&
                t.split(Regex("\\s+")).count { it.length > 7 } <= 2
        }, 50, minLen = 5, maxLen = 100)

        val examples = ArrayList<String>(); val exercises = ArrayList<String>()
        for (i in lines.indices) {
            val t = lines[i].text
            val next = lines.getOrNull(i + 1)?.takeIf { it.page == lines[i].page }?.text ?: ""
            if (exRe.containsMatchIn(t) && examples.size < 40) examples.add((t + " " + next).trim().take(220))
            else if ((qRe.containsMatchIn(t) || (Regex("^\\d{1,2}[.)]\\s+.{15,}").containsMatchIn(t) && taskRe.containsMatchIn(t))) && exercises.size < 40)
                exercises.add((t + (if (t.length < 60) " $next" else "")).trim().take(220))
        }

        val freq = HashMap<String, Int>()
        for (l in lines) for (w in l.text.lowercase().split(Regex("[^\\p{L}]+"))) if (w.length >= 4 && w !in stop) freq[w] = (freq[w] ?: 0) + 1
        val keywords = freq.entries.sortedByDescending { it.value }.take(15).map { it.key }

        return Scan(pagesN, words, scanned, title, chapter, heads, defs, laws, formulas, uniq(examples, 30, 5), uniq(exercises, 30, 5), keywords)
    }

    /** Short hint for the file name, like Chapter-1-Kinematics. */
    fun nameHint(s: Scan): String {
        val raw = if (s.chapter.isNotBlank()) s.chapter else s.title
        return raw.replace(Regex("[^\\p{L}\\p{N}\\s-]"), " ").trim().replace(Regex("\\s+"), "-").take(42).trim('-')
    }

    fun toJson(s: Scan): JSONObject = JSONObject().put("pages", s.pages).put("words", s.words).put("scanned", s.scanned)
        .put("title", s.title).put("chapter", s.chapter).put("headings", JSONArray(s.headings)).put("defs", JSONArray(s.definitions))
        .put("laws", JSONArray(s.laws)).put("formulas", JSONArray(s.formulas)).put("examples", JSONArray(s.examples))
        .put("exercises", JSONArray(s.exercises)).put("keywords", JSONArray(s.keywords))

    private fun strs(a: JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).map { a.getString(it) }

    fun fromJson(o: JSONObject): Scan = Scan(o.optInt("pages"), o.optInt("words"), o.optBoolean("scanned"), o.optString("title"), o.optString("chapter"),
        strs(o.optJSONArray("headings")), strs(o.optJSONArray("defs")), strs(o.optJSONArray("laws")), strs(o.optJSONArray("formulas")),
        strs(o.optJSONArray("examples")), strs(o.optJSONArray("exercises")), strs(o.optJSONArray("keywords")))

    private val greekWords = listOf("alpha", "beta", "gamma", "delta", "epsilon", "zeta", "eta", "theta", "kappa", "lambda", "mu", "nu", "xi", "pi", "rho", "sigma", "tau", "phi", "chi", "psi", "omega")
    private val capitalGreek = setOf("gamma", "delta", "theta", "lambda", "xi", "pi", "sigma", "phi", "psi", "omega")

    /** Turns plain formula text like "theta = omega * t" into LaTeX ("\\theta = \\omega \\cdot t"). */
    fun latexify(f: String): String {
        var t = f.trim()
        t = Regex("\\b(" + greekWords.joinToString("|") + ")\\b", RegexOption.IGNORE_CASE).replace(t) { m ->
            val w = m.value
            val lower = w.lowercase()
            if (w[0].isUpperCase() && w.drop(1).all { it.isLowerCase() } && lower in capitalGreek) "\\" + w else "\\" + lower
        }
        t = Regex("sqrt\\s*\\(([^()]*)\\)").replace(t) { "\\sqrt{" + it.groupValues[1] + "}" }
        t = t.replace("<=", "\\le ").replace(">=", "\\ge ").replace("!=", "\\ne ").replace("->", "\\to ").replace("*", "\\cdot ")
        t = Regex("(\\b\\w+)\\s*/\\s*(\\w+\\b)").replace(t) { "\\frac{" + it.groupValues[1] + "}{" + it.groupValues[2] + "}" }
        return t
    }

    /** Pretty Markdown (with real math) for showing and saving a scan. */
    fun toMarkdown(s: Scan, name: String, ar: Boolean): String {
        val sb = StringBuilder()
        fun sec(title: String, l: List<String>, math: Boolean = false) {
            if (l.isEmpty()) return
            sb.append("\n### ").append(title).append("\n")
            l.forEach { sb.append("- ").append(if (math) "$" + latexify(it) + "$" else it.replace("$", "\\$")).append("\n") }
        }
        sb.append("## ").append(s.title.ifBlank { name }).append("\n")
        if (s.chapter.isNotBlank()) sb.append("**").append(s.chapter).append("**\n\n")
        sb.append(if (ar) "${s.pages} صفحة · ${s.words} كلمة\n" else "${s.pages} pages · ${s.words} words\n")
        sec(if (ar) "العناوين" else "Headings", s.headings.take(25))
        sec(if (ar) "التعريفات" else "Definitions", s.definitions)
        sec(if (ar) "القوانين والنظريات" else "Laws & theorems", s.laws)
        sec(if (ar) "المعادلات" else "Formulas", s.formulas, math = true)
        sec(if (ar) "الأمثلة" else "Examples", s.examples)
        sec(if (ar) "التمارين والأسئلة" else "Exercises & questions", s.exercises)
        if (s.keywords.isNotEmpty()) sec(if (ar) "كلمات مفتاحية" else "Keywords", listOf(s.keywords.joinToString(", ")))
        return sb.toString().trim()
    }

    fun toText(s: Scan, name: String, ar: Boolean): String {
        val sb = StringBuilder()
        fun sec(title: String, l: List<String>) { if (l.isNotEmpty()) { sb.append("\n").append(title).append("\n"); l.forEach { sb.append("• ").append(it).append("\n") } } }
        sb.append(name).append("\n")
        if (s.title.isNotBlank()) sb.append(if (ar) "العنوان: " else "Title: ").append(s.title).append("\n")
        sb.append(if (ar) "${s.pages} صفحة · ${s.words} كلمة\n" else "${s.pages} pages · ${s.words} words\n")
        sec(if (ar) "العناوين" else "Headings", s.headings.take(25))
        sec(if (ar) "التعريفات" else "Definitions", s.definitions)
        sec(if (ar) "القوانين والنظريات" else "Laws & theorems", s.laws)
        sec(if (ar) "المعادلات" else "Formulas", s.formulas)
        sec(if (ar) "الأمثلة" else "Examples", s.examples)
        sec(if (ar) "التمارين والأسئلة" else "Exercises & questions", s.exercises)
        sec(if (ar) "كلمات مفتاحية" else "Keywords", listOf(s.keywords.joinToString(", ")).filter { it.isNotBlank() })
        return sb.toString().trim()
    }
}

/** Picks the most relevant pages so AI requests stay small (no more "free limit" from huge PDFs). */
object Rag {
    private val stopQ = setOf("the", "and", "what", "how", "why", "can", "you", "for", "with", "this", "that", "about", "from", "please", "explain", "tell")

    fun whole(name: String, pages: List<String>, budget: Int): String {
        val sb = StringBuilder("FILE: $name\n")
        for ((i, p) in pages.withIndex()) {
            if (p.isBlank()) continue
            if (sb.length + p.length > budget) { sb.append("\n[...text cut to fit the free limit...]"); break }
            sb.append("[Page ${i + 1}]\n").append(p).append("\n")
        }
        return sb.toString()
    }

    fun pick(files: List<Pair<String, List<String>>>, query: String, budget: Int): String {
        val q = query.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 3 && it !in stopQ }.toSet()
        data class P(val f: Int, val p: Int, val score: Int)
        val all = ArrayList<P>()
        files.forEachIndexed { fi, (_, pages) ->
            pages.forEachIndexed { pi, t ->
                val low = t.lowercase()
                all.add(P(fi, pi, q.sumOf { w -> (low.split(w).size - 1).coerceAtMost(5) }))
            }
        }
        val ordered = if (all.any { it.score > 0 }) all.sortedByDescending { it.score } else all.sortedBy { it.p }
        val chosen = ArrayList<P>(); var used = 0
        for (c in ordered) {
            val len = minOf(files[c.f].second[c.p].length, 3000)
            if (len == 0) continue
            if (used + len > budget) continue
            chosen.add(c); used += len
        }
        val sb = StringBuilder()
        for (fi in files.indices) {
            val mine = chosen.filter { it.f == fi }.sortedBy { it.p }
            if (mine.isEmpty()) continue
            sb.append("FILE: ").append(files[fi].first).append("\n")
            mine.forEach { sb.append("[Page ${it.p + 1}]\n").append(files[fi].second[it.p].take(3000)).append("\n") }
            sb.append("\n")
        }
        return sb.toString()
    }
}
