package com.tr8.scribe

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Pal(val bg: Color, val card: Color, val text: Color, val accent: Color, val gold: Color, val rose: Color, val onAccent: Color)

val DarkPal = Pal(Color(0xFF0B1B2B), Color(0xFF13293D), Color(0xFFF3E9D2), Color(0xFF2BB5A5), Color(0xFFE9B949), Color(0xFFE07A8F), Color(0xFF0B1B2B))
val LightPal = Pal(Color(0xFFFBF7EE), Color(0xFFFFFFFF), Color(0xFF14263A), Color(0xFF0E8F82), Color(0xFFB8860B), Color(0xFFC2455E), Color(0xFFFFFFFF))
val LocalPal = staticCompositionLocalOf { DarkPal }
val LocalLang = staticCompositionLocalOf { "en" }

object C {
    val bg: Color @Composable get() = LocalPal.current.bg
    val card: Color @Composable get() = LocalPal.current.card
    val text: Color @Composable get() = LocalPal.current.text
    val dim: Color @Composable get() = LocalPal.current.text.copy(alpha = 0.65f)
    val accent: Color @Composable get() = LocalPal.current.accent
    val gold: Color @Composable get() = LocalPal.current.gold
    val rose: Color @Composable get() = LocalPal.current.rose
    val onAccent: Color @Composable get() = LocalPal.current.onAccent
}

@Composable
fun tr(en: String, ar: String): String = if (LocalLang.current == "ar") ar else en

val DAYS_EN = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
val DAYS_AR = listOf("الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد")
val DAYS_AR_SHORT = listOf("إث", "ثل", "أر", "خم", "جم", "سب", "أح")
fun dayName(d: Int, ar: Boolean, short: Boolean = false): String =
    if (ar) (if (short) DAYS_AR_SHORT[d - 1] else DAYS_AR[d - 1]) else if (short) DAYS_EN[d - 1].take(3) else DAYS_EN[d - 1]

/** Stored as 24h "HH:mm", shown as 12h "9:00 AM". */
fun fmtTime(t: String, ar: Boolean): String {
    val p = t.split(":")
    if (p.size != 2) return t
    val h = p[0].toIntOrNull() ?: return t
    val h12 = if (h % 12 == 0) 12 else h % 12
    val suf = if (h < 12) (if (ar) "ص" else "AM") else (if (ar) "م" else "PM")
    return "$h12:${p[1]} $suf"
}

@Composable
fun Serif(text: String, size: TextUnit = 16.sp, color: Color = Color.Unspecified, modifier: Modifier = Modifier, align: TextAlign? = null) {
    Text(text, fontFamily = FontFamily.Serif, fontSize = size, color = if (color == Color.Unspecified) C.text else color, modifier = modifier, textAlign = align)
}

@Composable
fun Panel(title: String, titleColor: Color = Color.Unspecified, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(C.card, RoundedCornerShape(18.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Serif(title, 18.sp, if (titleColor == Color.Unspecified) C.accent else titleColor)
        content()
    }
}

@Composable
fun TopBar(store: Store, title: String) {
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Serif(title, 28.sp, modifier = Modifier.weight(1f))
        TextButton(onClick = { store.toggleLang() }) { Text(if (store.lang == "ar") "EN" else "عربي", color = C.accent) }
        TextButton(onClick = { store.toggleTheme() }) { Text(if (store.theme == "dark") "☀" else "🌙", fontSize = 20.sp) }
    }
}
