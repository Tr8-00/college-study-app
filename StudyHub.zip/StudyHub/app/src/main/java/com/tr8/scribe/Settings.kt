package com.tr8.scribe

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SettingsTab(store: Store) {
    val scope = rememberCoroutineScope()
    val uri = LocalUriHandler.current
    val ctx = LocalContext.current
    var models by remember { mutableStateOf<List<String>>(emptyList()) }
    var msg by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    val p = store.data.profile
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar(store, tr("Settings", "الإعدادات"))
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Panel(tr("Profile", "الملف الشخصي")) {
                Text("${p.name} · ${p.university}", fontSize = 15.sp, color = C.text)
                Text(listOf(p.major.ifBlank { p.faculty }, tr("Year ${p.year}", "السنة ${p.year}"), tr("Semester ${p.sem}", "الفصل ${p.sem}")).filter { it.isNotBlank() }.joinToString(" · "), fontSize = 13.sp, color = C.dim)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { store.setProfile { it.copy(done = false) } }) { Text(tr("Edit setup", "تعديل الإعداد")) }
                }
            }
            Panel(tr("Look & language", "المظهر واللغة")) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(store.theme == "dark", { store.theme = "dark"; store.saveSettings() }, { Text(tr("🌙 Dark", "🌙 داكن")) })
                    FilterChip(store.theme == "light", { store.theme = "light"; store.saveSettings() }, { Text(tr("☀ Light", "☀ فاتح")) })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(store.lang == "en", { store.lang = "en"; store.saveSettings() }, { Text("English") })
                    FilterChip(store.lang == "ar", { store.lang = "ar"; store.saveSettings() }, { Text("العربية") })
                }
            }
            Panel(tr("Class reminders", "تنبيهات المحاضرات"), C.gold) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(store.remindersOn, { store.remindersOn = it; store.saveSettings(); Reminders.scheduleAll(ctx) })
                    Spacer(Modifier.width(10.dp))
                    Text(tr("Notify me before each class in my schedule", "نبّهني قبل كل محاضرة في جدولي"), fontSize = 14.sp, color = C.text)
                }
                Text(tr("Minutes before the class", "عدد الدقائق قبل المحاضرة"), fontSize = 12.sp, color = C.dim)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(10, 15, 30, 45, 60).forEach { m ->
                        FilterChip(store.remindMin == m, { store.remindMin = m; store.saveSettings(); Reminders.scheduleAll(ctx) }, { Text("$m") })
                    }
                }
                Text(tr("Each notification shows the subject, whether it's a lecture, section or lab, and the room.", "يعرض كل إشعار المادة ونوعها (محاضرة أو سكشن أو معمل) ورقم القاعة."), fontSize = 12.sp, color = C.dim)
                OutlinedButton(onClick = {
                    Reminders.show(ctx, Slot("test", store.data.subjects.firstOrNull()?.id ?: "", 1, "09:00", "10:30", "lecture", "B-204"))
                }) { Text(tr("Send a test notification", "أرسل إشعاراً تجريبياً")) }
                if (!Reminders.canExact(ctx)) {
                    Text(tr("Android may delay reminders unless you allow exact alarms.", "قد يؤخر أندرويد التنبيهات ما لم تسمح بالمنبهات الدقيقة."), fontSize = 12.sp, color = C.rose)
                    OutlinedButton(onClick = {
                        try {
                            if (Build.VERSION.SDK_INT >= 31) ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } catch (e: Exception) { }
                    }) { Text(tr("Allow exact reminders", "السماح بالتنبيهات الدقيقة")) }
                }
            }
            Panel(tr("Privacy", "الخصوصية")) {
                Text(tr(
                    "Your files, notes and schedule are stored only in this app's private storage. Nothing is sent anywhere unless you use AI, search for a university, or import a schedule. AI requests go to Google's Gemini with your own key. Google says free-tier content may be used to improve its products, so don't send anything confidential.",
                    "ملفاتك وملاحظاتك وجدولك محفوظة فقط في مساحة التطبيق الخاصة. لا يُرسل شيء إلا عند استخدام الذكاء الاصطناعي أو البحث عن جامعة أو استيراد جدول. تذهب طلبات الذكاء الاصطناعي إلى Gemini من Google بمفتاحك الخاص. تذكر Google أن محتوى الخطة المجانية قد يُستخدم لتحسين منتجاتها، فلا ترسل أي شيء سري."), fontSize = 13.sp, color = C.text)
            }
            Panel(tr("AI (free)", "الذكاء الاصطناعي (مجاني)"), C.gold) {
                Text(tr("Get a free key from Google AI Studio, then paste it here.", "احصل على مفتاح مجاني من Google AI Studio ثم الصقه هنا."), fontSize = 13.sp, color = C.dim)
                OutlinedButton(onClick = { uri.openUri("https://aistudio.google.com/app/apikey") }) { Text(tr("Get a free key", "احصل على مفتاح مجاني")) }
                OutlinedTextField(store.apiKey, { store.apiKey = it; store.saveSettings() }, Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text("Gemini API key") }, visualTransformation = PasswordVisualTransformation())
                Text(tr("Speed", "السرعة"), fontSize = 12.sp, color = C.dim)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(store.model == "gemini-flash-lite-latest", { store.model = "gemini-flash-lite-latest"; store.saveSettings() }, { Text(tr("⚡ Fast", "⚡ سريع")) })
                    FilterChip(store.model == "gemini-flash-latest", { store.model = "gemini-flash-latest"; store.saveSettings() }, { Text(tr("🧠 Smarter", "🧠 أذكى")) })
                }
                OutlinedTextField(store.model, { store.model = it; store.saveSettings() }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(tr("Model", "النموذج")) })
                OutlinedButton(enabled = !loading && store.apiKey.isNotBlank(), onClick = {
                    loading = true; msg = ""
                    scope.launch {
                        try {
                            models = withContext(Dispatchers.IO) { Ai.models(store.apiKey) }
                            msg = if (models.isEmpty()) "Key works, but no models were listed." else "Key works. Tap a model to use it."
                        } catch (e: Exception) { msg = e.message ?: "Couldn't reach Google."; models = emptyList() }
                        loading = false
                    }
                }) { Text(if (loading) tr("Checking…", "جارٍ الفحص…") else tr("Test key + list models", "اختبر المفتاح + اعرض النماذج")) }
                if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = if (models.isEmpty()) C.rose else C.accent)
                models.forEach { m ->
                    TextButton(onClick = { store.model = m; store.saveSettings() }) {
                        Text((if (store.model == m) "✓ " else "") + m, color = if (store.model == m) C.gold else C.text)
                    }
                }
            }
            Panel(tr("Weeks per semester", "عدد أسابيع الفصل")) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = { if (store.weeks > 1) { store.weeks--; store.saveSettings() } }) { Text("−") }
                    Text("${store.weeks}", fontSize = 20.sp, color = C.text)
                    OutlinedButton(onClick = { if (store.weeks < 30) { store.weeks++; store.saveSettings() } }) { Text("+") }
                }
            }
        }
    }
}
