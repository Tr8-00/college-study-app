package com.tr8.scribe

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters

/** Class reminders: a notification before each class in your schedule (default 30 minutes), every week. */
object Reminders {
    const val CH_REMIND = "scribe_remind"

    private fun pending(ctx: Context, slotId: String): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java).setAction("scribe.remind").putExtra("slotId", slotId)
            .setData(Uri.parse("scribe://slot/$slotId"))
        return PendingIntent.getBroadcast(ctx, slotId.hashCode(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun canExact(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 31 || ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    /** Next time to notify for this slot that is after [after]. */
    fun nextTrigger(slot: Slot, leadMin: Int, after: LocalDateTime): Long? = try {
        val day = LocalDate.now().with(TemporalAdjusters.nextOrSame(DayOfWeek.of(slot.day)))
        var dt = LocalDateTime.of(day, LocalTime.parse(slot.time)).minusMinutes(leadMin.toLong())
        while (!dt.isAfter(after)) dt = dt.plusDays(7)
        dt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    } catch (e: Exception) { null }

    private fun scheduleOne(ctx: Context, slot: Slot, leadMin: Int, after: LocalDateTime) {
        val at = nextTrigger(slot, leadMin, after) ?: return
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = pending(ctx, slot.id)
        try {
            if (canExact(ctx)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun studyPending(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 9001, Intent(ctx, StudyReceiver::class.java).setAction("scribe.study"), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** One notification a day at the chosen hour when flashcards are due. */
    fun scheduleStudy(ctx: Context) {
        val store = Store.get(ctx)
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(studyPending(ctx))
        if (!store.studyRemind) return
        var dt = LocalDateTime.of(LocalDate.now(), LocalTime.of(store.studyHour, 0))
        if (!dt.isAfter(LocalDateTime.now().plusMinutes(1))) dt = dt.plusDays(1)
        val at = dt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        try {
            if (canExact(ctx)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, studyPending(ctx)) else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, studyPending(ctx))
        } catch (e: SecurityException) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, studyPending(ctx)) }
    }

    fun showStudy(ctx: Context) {
        val store = Store.get(ctx)
        val due = store.dueCount()
        if (due <= 0) return
        val ar = store.lang == "ar"
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
            ensureChannels(ctx)
            val open = PendingIntent.getActivity(ctx, 8, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("tab", 3),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = NotificationCompat.Builder(ctx, CH_REMIND).setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(if (ar) "📖 حان وقت المراجعة" else "📖 Time to review")
                .setContentText(if (ar) "لديك $due بطاقة مستحقة اليوم" else "You have $due flashcards due today")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT).setAutoCancel(true).setContentIntent(open).build()
            ctx.getSystemService(NotificationManager::class.java).notify(9001, n)
        } catch (e: Exception) { }
    }

    fun scheduleAll(ctx: Context) {
        val store = Store.get(ctx)
        scheduleStudy(ctx)
        val am = ctx.getSystemService(AlarmManager::class.java)
        store.data.slots.forEach { am.cancel(pending(ctx, it.id)) }
        if (!store.remindersOn) return
        store.data.slots.forEach { scheduleOne(ctx, it, store.remindMin, LocalDateTime.now()) }
    }

    fun cancel(ctx: Context, slotId: String) { ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx, slotId)) }

    fun text(store: Store, slot: Slot): Pair<String, String> {
        val ar = store.lang == "ar"
        val name = store.data.subjects.firstOrNull { it.id == slot.subjectId }?.name ?: "Class"
        val kind = kindLabel(slot.kind, ar)
        val room = if (slot.place.isNotBlank()) slot.place else if (ar) "غير محددة" else "not set"
        val title = if (ar) "$name · $kind بعد ${store.remindMin} دقيقة" else "$name · $kind in ${store.remindMin} min"
        val body = (if (ar) "القاعة: $room · تبدأ " else "Room: $room · starts ") + fmtTime(slot.time, ar)
        return title to body
    }

    fun show(ctx: Context, slot: Slot) {
        val store = Store.get(ctx)
        val (title, body) = text(store, slot)
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
            ensureChannels(ctx)
            val open = PendingIntent.getActivity(ctx, 7, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = NotificationCompat.Builder(ctx, CH_REMIND).setSmallIcon(R.drawable.ic_notif).setContentTitle(title).setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body)).setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER).setAutoCancel(true).setContentIntent(open).build()
            ctx.getSystemService(NotificationManager::class.java).notify(slot.id.hashCode(), n)
        } catch (e: Exception) { }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val store = Store.get(ctx)
        val slot = store.data.slots.firstOrNull { it.id == intent.getStringExtra("slotId") } ?: return
        if (store.remindersOn) Reminders.show(ctx, slot)
        // schedule the same class for next week
        if (store.remindersOn) {
            val at = Reminders.nextTrigger(slot, store.remindMin, LocalDateTime.now().plusMinutes(5)) ?: return
            val am = ctx.getSystemService(AlarmManager::class.java)
            val pi = PendingIntent.getBroadcast(ctx, slot.id.hashCode(),
                Intent(ctx, ReminderReceiver::class.java).setAction("scribe.remind").putExtra("slotId", slot.id).setData(Uri.parse("scribe://slot/${slot.id}")),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            try {
                if (Reminders.canExact(ctx)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } catch (e: SecurityException) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) Reminders.scheduleAll(ctx)
    }
}

class StudyReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Reminders.showStudy(ctx)
        Reminders.scheduleStudy(ctx)
    }
}
