package com.tr8.scribe

data class Suggestion(val subjectId: String, val kind: String, val week: Int, val score: Double, val confidence: String, val reason: String)

/**
 * Sorts a new file into Subject / type / week on the phone: no AI, no internet.
 * It reads the file name and the first pages, matches them with your subjects (name, topic words, and what your
 * existing files already talk about), and reads "Lecture 3", "Sheet 2", "Week 5"... for the number.
 */
object SmartSort {
    private class Topic(val hints: List<String>, val words: List<String>)

    private val topics = listOf(
        Topic(listOf("physics", "فيزياء"), listOf("electricity", "electric", "magnetic", "magnetism", "coulomb", "vector", "vectors", "kinematics", "newton", "force", "optics", "wave", "waves", "thermodynamics", "heat", "quantum", "capacitor", "current", "voltage", "charge", "field", "momentum", "فيزياء", "كهرباء", "مغناطيس", "متجهات", "قوة")),
        Topic(listOf("math", "calculus", "algebra", "رياضيات", "تفاضل", "تكامل", "جبر"), listOf("integral", "integrals", "derivative", "limit", "limits", "differential", "matrix", "matrices", "determinant", "series", "complex", "function", "equation", "theorem", "calculus", "algebra", "تفاضل", "تكامل", "مصفوفات", "نهايات", "دالة")),
        Topic(listOf("chem", "كيمياء"), listOf("chemistry", "chemical", "reaction", "molecule", "acid", "periodic", "bond", "organic", "solution", "mole", "oxidation", "atom", "كيمياء", "تفاعل", "حمض", "ذرة")),
        Topic(listOf("english", "language", "writing", "لغة", "انجليزي", "إنجليزي"), listOf("grammar", "writing", "essay", "report", "vocabulary", "reading", "sentence", "paragraph", "tense", "technical writing")),
        Topic(listOf("programming", "computer", "coding", "software", "برمجة", "حاسب"), listOf("programming", "algorithm", "python", "java", "loop", "array", "function", "pointer", "compiler", "variable", "class", "object", "data structure", "برمجة")),
        Topic(listOf("drawing", "graphics", "رسم"), listOf("orthographic", "projection", "isometric", "drawing", "autocad", "dimension", "sketch", "رسم")),
        Topic(listOf("mechanics", "statics", "dynamics", "ميكانيكا"), listOf("statics", "equilibrium", "moment", "truss", "friction", "dynamics", "kinematics", "particle", "rigid body", "centroid", "inertia", "ميكانيكا", "اتزان")),
        Topic(listOf("production", "manufactur", "workshop", "ورش", "إنتاج"), listOf("manufacturing", "machining", "casting", "welding", "workshop", "lathe", "milling", "forming", "tolerance", "إنتاج")),
        Topic(listOf("circuit", "electrical", "دوائر", "كهربية"), listOf("circuit", "resistor", "voltage", "current", "kirchhoff", "impedance", "ohm", "inductor", "capacitor", "دوائر")),
        Topic(listOf("digital", "logic", "منطق"), listOf("logic", "gate", "boolean", "flip-flop", "multiplexer", "karnaugh", "binary", "counter", "register")),
        Topic(listOf("signal"), listOf("fourier", "laplace", "convolution", "transfer function", "spectrum", "sampling")),
        Topic(listOf("material"), listOf("stress", "strain", "alloy", "crystal", "metal", "ceramic", "polymer", "hardness", "fracture"))
    )
    private val generic = setOf("engineering", "introduction", "fundamentals", "principles", "applied", "basic", "technical", "advanced", "general", "with", "and", "the", "of")

    private val kindRx = listOf(
        "lab" to Regex("(?i)\\b(lab|laboratory|experiment|exp)\\b|معمل|تجربة"),
        "assignment" to Regex("(?i)\\b(assignment|homework|hw|project)\\b|واجب|تكليف"),
        "section" to Regex("(?i)\\b(sheet|section|sec|tutorial|tut|problems|exercises?)\\b|شيت|سكشن|تمارين"),
        "lecture" to Regex("(?i)\\b(lecture|lec|lect|slides|chapter|ch)\\b|محاضرة|المحاضرة|الفصل")
    )
    private val numRx = Regex("(?i)(?:lecture|lec|lect|chapter|ch|sheet|section|sec|tutorial|tut|assignment|hw|homework|lab|experiment|week|wk|شيت|سكشن|واجب|معمل|تجربة|محاضرة|المحاضرة|الفصل|الأسبوع|اسبوع)[\\s._#:\\-]*(\\d{1,2})")
    private val weekRx = Regex("(?i)(?:week|wk|الأسبوع|اسبوع)[\\s._#:\\-]*(\\d{1,2})")

    /** (kind, number, explicitWeek) from the file name first, then the first lines of the file. */
    fun kindAndNumber(fileName: String, head: String): Triple<String, Int?, Int?> {
        val name = fileName.substringBeforeLast('.').replace('_', ' ').replace('-', ' ')
        fun scan(t: String): Triple<String?, Int?, Int?> {
            val kind = kindRx.firstOrNull { it.second.containsMatchIn(t) }?.first
            val n = numRx.find(t)?.groupValues?.get(1)?.toIntOrNull()
            val w = weekRx.find(t)?.groupValues?.get(1)?.toIntOrNull()
            return Triple(kind, n, w)
        }
        val a = scan(name)
        val b = scan(head.take(600))
        return Triple(a.first ?: b.first ?: "lecture", a.second ?: b.second, a.third ?: b.third)
    }

    private fun tokens(s: String): List<String> = s.lowercase().split(Regex("[^\\p{L}]+")).filter { it.length >= 4 && it !in generic }

    fun suggest(store: Store, fileName: String, text: String, scan: Scan?): Suggestion? {
        val p = store.data.profile
        val pool = store.data.subjects.filter { it.year == p.year && it.sem == p.sem }.ifEmpty { store.data.subjects }
        if (pool.isEmpty()) return null
        val blob = (fileName.replace('_', ' ').replace('-', ' ') + " " + text.take(3000)).lowercase()
        val fileWords = HashSet<String>()
        scan?.keywords?.let { fileWords.addAll(it) }
        fileWords.addAll(tokens(text.take(3000)).take(80))

        val scored = pool.map { s ->
            var score = 0.0
            val why = ArrayList<String>()
            val full = s.name.lowercase()
            val noNum = full.replace(Regex("\\b(i{1,3}|iv|v|\\d+)\\b|\\(\\d+\\)"), "").replace(Regex("\\s+"), " ").trim()
            if (full.length >= 4 && blob.contains(full)) { score += 6; why.add("name") }
            else if (noNum.length >= 4 && blob.contains(noNum)) { score += 4; why.add("name") }
            val nameToks = tokens(s.name)
            val tokHit = nameToks.count { blob.contains(it) }
            if (tokHit > 0) { score += minOf(9, tokHit * 3).toDouble(); why.add("name words") }
            val topic = topics.filter { t -> t.hints.any { full.contains(it) } }
            val words = topic.flatMap { it.words }.distinct().count { blob.contains(it) }
            if (words > 0) { score += minOf(9.0, words * 1.5); why.add("$words topic words") }
            val vocab = HashSet<String>()
            store.data.items.filter { it.subjectId == s.id }.forEach { i ->
                store.loadScan(i.id)?.let { sc -> vocab.addAll(sc.keywords); sc.headings.forEach { h -> vocab.addAll(tokens(h)) } }
            }
            val overlap = fileWords.count { it in vocab }
            if (overlap > 0) { score += minOf(6, overlap).toDouble(); why.add("like your other files") }
            Triple(s, score, why)
        }.sortedByDescending { it.second }

        val top = scored.first()
        val margin = top.second - (scored.getOrNull(1)?.second ?: 0.0)
        val conf = when { top.second >= 7 && margin >= 2.5 -> "high"; top.second >= 3.5 -> "medium"; else -> "low" }

        val (kind, n, explicitWeek) = kindAndNumber(fileName, text)
        val lpw = store.lecturesPerWeek.coerceAtLeast(1)
        var week = when {
            explicitWeek != null -> explicitWeek
            kind == "lecture" && n != null -> (n + lpw - 1) / lpw
            n != null -> n
            else -> (1..store.weeks).firstOrNull { w -> store.data.items.none { it.subjectId == top.first.id && it.kind == kind && it.week == w } } ?: 1
        }
        week = week.coerceIn(1, store.weeks)
        val k = if (kind == "lecture" && !top.first.lecture) listOf("section", "assignment", "lab").firstOrNull { x -> when (x) { "section" -> top.first.section; "assignment" -> top.first.assignment; else -> top.first.lab } } ?: kind else kind
        return Suggestion(top.first.id, k, week, top.second, conf, top.third.joinToString(", "))
    }
}
