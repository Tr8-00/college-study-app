package com.tr8.scribe

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class Draft(
    val uri: Uri, val name: String, val subjectId: String, val kind: String, val week: Int,
    val conf: String, val reason: String, val include: Boolean = true, val editing: Boolean = false
)

/** Files shared into Scribe from other apps (e.g. WhatsApp "Share"). Consumed by the import dialog. */
object SharedIn { var uris by mutableStateOf<List<Uri>>(emptyList()) }

private fun analyze(store: Store, ctx: Context, uri: Uri, name: String): Draft? {
    val ext = name.substringAfterLast('.', "").lowercase()
    var head = ""
    var scan: Scan? = null
    if (ext in TEXT_EXTS) {
        val f = File(ctx.cacheDir, "sort_" + System.currentTimeMillis() + "." + ext)
        try {
            ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            val lines = Scanner.extract(ctx, f, name)
            if (lines != null && lines.isNotEmpty()) {
                head = lines.filter { it.page <= 2 }.joinToString("\n") { it.text }
                scan = Scanner.analyze(lines)
            }
        } catch (e: Throwable) { } finally { f.delete() }
    }
    val s = SmartSort.suggest(store, name, head, scan) ?: return null
    return Draft(uri, name, s.subjectId, s.kind, s.week, s.confidence, s.reason)
}

/** Pick many files at once; Scribe reads each one, guesses the subject / type / week, and you confirm. */
@Composable
fun ImportSortDialog(store: Store, initial: List<Uri> = emptyList(), onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val ar = store.lang == "ar"
    var drafts by remember { mutableStateOf<List<Draft>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf("") }
    val reading = tr("Reading", "جارٍ قراءة")
    val addedMsg = tr("Added", "تمت إضافة")
    fun process(uris: List<Uri>) {
        if (uris.isEmpty()) return
        busy = true
        scope.launch {
            val out = ArrayList<Draft>()
            for ((i, uri) in uris.withIndex()) {
                val name = LocalImport.displayName(ctx, uri)
                progress = "$reading ${i + 1}/${uris.size}: $name"
                val d = withContext(Dispatchers.IO) { analyze(store, ctx, uri, name) }
                if (d != null) out.add(d)
            }
            drafts = drafts + out
            busy = false
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> process(uris) }
    LaunchedEffect(Unit) { if (initial.isNotEmpty()) process(initial) }
    val n = drafts.count { it.include }
    AlertDialog(
        onDismissRequest = { if (!busy) onClose() },
        title = { Text(tr("Import & sort files", "استيراد وفرز الملفات")) },
        confirmButton = {
            TextButton(enabled = !busy && n > 0, onClick = {
                scope.launch {
                    busy = true
                    var added = 0
                    for (d in drafts.filter { it.include }) {
                        val sub = store.data.subjects.firstOrNull { it.id == d.subjectId } ?: continue
                        val item = store.addFile(sub, d.week, d.kind, d.uri)
                        if (item != null) {
                            added++
                            if (item.name.substringAfterLast('.', "").lowercase() in TEXT_EXTS) launch { store.scanItem(item, true) }
                        }
                    }
                    Toast.makeText(ctx, "$addedMsg $added", Toast.LENGTH_SHORT).show()
                    busy = false
                    onClose()
                }
            }) { Text(tr("Add", "إضافة") + " ($n)") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onClose) { Text(tr("Cancel", "إلغاء")) } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (store.data.subjects.isEmpty()) {
                    Text(tr("Add your subjects first (Courses → ✨ Suggest, or import your schedule).", "أضف موادك أولاً (المقررات ← ✨ اقتراح، أو استورد جدولك)."), color = C.rose, fontSize = 13.sp)
                } else {
                    Text(tr("Choose your downloaded PDFs, slides and notes. Scribe reads the first page and the file name on your phone and sorts them. Nothing is uploaded.", "اختر ملفات PDF والشرائح والملاحظات التي نزّلتها. يقرأ Scribe الصفحة الأولى واسم الملف على هاتفك ويفرزها. لا يتم رفع أي شيء."), fontSize = 12.sp, color = C.dim)
                    OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !busy) { Text(tr("+ Choose files", "+ اختر ملفات")) }
                }
                if (busy) { LinearProgressIndicator(Modifier.fillMaxWidth(), color = C.accent); Text(progress, fontSize = 12.sp, color = C.dim) }
                drafts.forEachIndexed { i, d ->
                    val sub = store.data.subjects.firstOrNull { it.id == d.subjectId }
                    val conf = when (d.conf) { "high" -> tr("✅ confident", "✅ متأكد"); "medium" -> tr("❔ likely", "❔ محتمل"); else -> tr("⚠ please check", "⚠ يرجى المراجعة") }
                    Column(Modifier.fillMaxWidth().background(C.bg.copy(alpha = 0.5f), RoundedCornerShape(14.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(d.include, { c -> drafts = drafts.mapIndexed { j, x -> if (j == i) x.copy(include = c) else x } })
                            Column(Modifier.weight(1f)) {
                                Text(d.name, fontSize = 13.sp, color = C.text, maxLines = 2)
                                Text("→ ${sub?.name ?: "?"} · ${kindLabel(d.kind, ar)} · " + tr("Week ${d.week}", "الأسبوع ${d.week}") + "  $conf", fontSize = 11.sp, color = if (d.conf == "low") C.rose else C.accent)
                            }
                            TextButton(onClick = { drafts = drafts.mapIndexed { j, x -> if (j == i) x.copy(editing = !x.editing) else x } }) { Text("✎", color = C.gold) }
                        }
                        AnimatedVisibility(d.editing) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    store.data.subjects.forEach { s -> FilterChip(d.subjectId == s.id, { drafts = drafts.mapIndexed { j, x -> if (j == i) x.copy(subjectId = s.id) else x } }, { Text(s.name) }) }
                                }
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    KINDS.forEach { k -> FilterChip(d.kind == k, { drafts = drafts.mapIndexed { j, x -> if (j == i) x.copy(kind = k) else x } }, { Text(kindLabel(k, ar).substringBefore(" ")) }) }
                                }
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    (1..store.weeks).forEach { w -> FilterChip(d.week == w, { drafts = drafts.mapIndexed { j, x -> if (j == i) x.copy(week = w) else x } }, { Text("$w") }) }
                                }
                            }
                        }
                    }
                }
            }
        }
    )
}
