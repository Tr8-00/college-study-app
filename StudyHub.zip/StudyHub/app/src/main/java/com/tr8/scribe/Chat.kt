package com.tr8.scribe

import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Flashcards(cards: List<Pair<String, String>>, key: String) {
    var i by remember { mutableIntStateOf(0) }
    var flipped by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(tr("Card ${i + 1} of ${cards.size} · tap to flip", "بطاقة ${i + 1} من ${cards.size} · اضغط للقلب"), fontSize = 12.sp, color = C.dim)
        AnimatedContent(
            targetState = i to flipped,
            transitionSpec = { (fadeIn(tween(240)) + slideInVertically(tween(260)) { it / 8 }) togetherWith fadeOut(tween(120)) },
            label = "card"
        ) { (idx, fl) ->
            Box(
                Modifier.fillMaxWidth().heightIn(min = 150.dp).background(if (fl) C.card else C.bg, RoundedCornerShape(18.dp))
                    .border(BorderStroke(if (fl) 2.dp else 1.dp, if (fl) C.accent else C.dim.copy(alpha = 0.3f)), RoundedCornerShape(18.dp))
                    .pressClick { flipped = !flipped }.padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                MathView(if (fl) cards[idx].second else cards[idx].first, cacheKey = "$key|$idx|$fl")
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { if (i > 0) { i--; flipped = false } }, enabled = i > 0) { Text(tr("‹ Prev", "السابق")) }
            OutlinedButton(onClick = { if (i < cards.size - 1) { i++; flipped = false } }, enabled = i < cards.size - 1) { Text(tr("Next ›", "التالي")) }
        }
    }
}

@Composable
private fun Avatar() {
    Box(
        Modifier.size(30.dp).background(Brush.linearGradient(listOf(C.accent, C.gold)), CircleShape),
        contentAlignment = Alignment.Center
    ) { Text("✨", fontSize = 15.sp) }
}

@Composable
fun ChatBubble(store: Store, e: Entry) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val vis = remember { MutableTransitionState(false).apply { targetState = true } }
    var saved by remember(e.id) { mutableStateOf(false) }
    val copiedMsg = tr("Copied", "تم النسخ")
    AnimatedVisibility(
        visibleState = vis,
        enter = fadeIn(tween(300)) + slideInVertically(tween(340, easing = FastOutSlowInEasing)) { it / 5 }
    ) {
        if (e.role == "user") {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                Text(
                    e.text, color = C.onAccent, fontSize = 15.sp,
                    modifier = Modifier.widthIn(max = 320.dp)
                        .background(Brush.horizontalGradient(listOf(C.accent, C.accent.copy(alpha = 0.78f))), RoundedCornerShape(20.dp, 20.dp, 4.dp, 20.dp))
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                )
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                Avatar()
                Column(
                    Modifier.weight(1f).background(C.card, RoundedCornerShape(4.dp, 20.dp, 20.dp, 20.dp)).padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (e.title.isNotEmpty() && e.action != "chat") Text(e.title, fontSize = 11.sp, color = C.gold)
                    when (e.status) {
                        "queued" -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            TypingDots(); Text(tr("Waiting to start…", "في الانتظار…"), color = C.dim, fontSize = 13.sp)
                        }
                        "running" -> {
                            val live = store.live[e.id] ?: ""
                            if (live.isEmpty()) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    TypingDots()
                                    Text(tr("Thinking… you can leave the app, Scribe will notify you.", "جارٍ التفكير… يمكنك مغادرة التطبيق وسيصلك إشعار."), color = C.dim, fontSize = 12.sp)
                                }
                            } else MathView(live, cacheKey = e.id, streaming = true)
                        }
                        "failed" -> {
                            Text(e.text, color = C.rose, fontSize = 14.sp)
                            OutlinedButton(onClick = { store.retry(e.id); startWork(ctx) }) { Text(tr("↻ Retry", "↻ إعادة المحاولة")) }
                        }
                        else -> {
                            val cards = if (e.action == "cards") Ai.parseCards(e.text) else emptyList()
                            if (cards.isNotEmpty()) Flashcards(cards, e.id) else MathView(e.text, cacheKey = e.id)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(onClick = {
                                    clipboard.setText(AnnotatedString(e.text))
                                    Toast.makeText(ctx, copiedMsg, Toast.LENGTH_SHORT).show()
                                }) { Text(tr("📋 Copy", "📋 نسخ"), fontSize = 12.sp, color = C.dim) }
                                if (e.subjectId.isNotEmpty() && e.action != "chat") {
                                    TextButton(enabled = !saved, onClick = {
                                        val k = noteKey(e.subjectId, e.week, e.kind)
                                        val old = store.data.notes[k] ?: ""
                                        store.setNote(k, (if (old.isBlank()) "" else "$old\n\n") + e.text)
                                        saved = true
                                    }) { Text(if (saved) tr("Saved ✓", "تم الحفظ ✓") else tr("💾 Save to notes", "💾 حفظ في الملاحظات"), fontSize = 12.sp, color = C.accent) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatTab(store: Store, onOpenSettings: () -> Unit = {}) {
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    var scopeOpen by remember { mutableStateOf(false) }
    val chat = store.data.chat.sortedBy { it.ts }
    val listState = rememberLazyListState()
    val mode = store.chatMode
    val attach = if (mode == "online" || store.chatSubjectId.isEmpty()) emptyList() else store.chatFiles(store.chatSubjectId, store.chatWeek)
    val noKey = tr("Add your free Gemini key in Settings first.", "أضف مفتاح Gemini المجاني من الإعدادات أولاً.")
    val busy = chat.any { it.role == "ai" && (it.status == "queued" || it.status == "running") }
    val scopeName = store.data.subjects.firstOrNull { it.id == store.chatSubjectId }?.name

    LaunchedEffect(chat.size) { if (chat.isNotEmpty()) listState.animateScrollToItem(chat.size - 1) }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        if (store.apiKey.isBlank()) { Toast.makeText(ctx, noKey, Toast.LENGTH_LONG).show(); return }
        store.enqueueChat(t, mode, attach.map { it.id }, store.chatSubjectId)
        input = ""
        startWork(ctx)
    }

    val quick = listOf(
        tr("📋 Summarize", "📋 لخّص") to tr("Summarize the key points, laws and formulas from my files.", "لخّص النقاط الرئيسية والقوانين والمعادلات من ملفاتي."),
        tr("💡 Explain simply", "💡 اشرح ببساطة") to tr("Explain the main ideas in simple language with small examples.", "اشرح الأفكار الرئيسية بلغة بسيطة مع أمثلة صغيرة."),
        tr("📝 Quiz me", "📝 اختبرني") to tr("Give me 5 practice questions on this material, with an answer key at the end.", "أعطني ٥ أسئلة تدريبية على هذه المادة مع مفتاح الإجابات في النهاية."),
        tr("✅ Solve", "✅ حل") to tr("Solve the exercises in my files step by step.", "حل التمارين في ملفاتي خطوة بخطوة.")
    )

    Column(Modifier.fillMaxSize()) {
        TopBar(store, tr("Ask AI", "المساعد"))
        if (store.apiKey.isBlank()) {
            Column(
                Modifier.padding(horizontal = 16.dp).fillMaxWidth().background(C.card, RoundedCornerShape(18.dp)).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Serif(tr("Ask AI is optional", "المساعد الذكي اختياري"), 18.sp, C.gold)
                Text(tr("It needs a free Gemini key. Everything else in Scribe (schedule, file sorting, search, flashcards, quizzes, summaries) works offline without it.", "يحتاج إلى مفتاح Gemini مجاني. كل شيء آخر في Scribe (الجدول وفرز الملفات والبحث والبطاقات والاختبارات والملخصات) يعمل بدون إنترنت وبدونه."), fontSize = 13.sp, color = C.dim)
                Button(onClick = onOpenSettings) { Text(tr("Open Settings", "افتح الإعدادات")) }
            }
        }
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                listOf("local" to tr("📁 My files", "📁 ملفاتي"), "online" to tr("🌐 Online", "🌐 الإنترنت"), "both" to tr("✨ Both", "✨ الاثنان")).forEach { (m, label) ->
                    FilterChip(mode == m, { store.chatMode = m; store.saveSettings() }, { Text(label) })
                }
                if (chat.isNotEmpty()) TextButton(onClick = { store.clearChat() }) { Text(tr("Clear", "مسح"), color = C.rose) }
            }
            if (mode != "online") {
                Row(
                    Modifier.fillMaxWidth().background(C.card, RoundedCornerShape(14.dp)).pressClick { scopeOpen = !scopeOpen }.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "📎 " + (if (scopeName == null) tr("No files attached. Tap to choose a subject.", "لا ملفات مرفقة. اضغط لاختيار مادة.")
                        else scopeName + (if (store.chatWeek > 0) " · " + tr("Week ${store.chatWeek}", "الأسبوع ${store.chatWeek}") else " · " + tr("all weeks", "كل الأسابيع")) + " · ${attach.size} " + tr("files", "ملف")),
                        fontSize = 13.sp, color = C.text, modifier = Modifier.weight(1f)
                    )
                    Text(if (scopeOpen) "▴" else "▾", color = C.dim)
                }
                AnimatedVisibility(scopeOpen) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(store.chatSubjectId.isEmpty(), { store.chatSubjectId = "" }, { Text(tr("No files", "بدون ملفات")) })
                            store.data.subjects.forEach { s -> FilterChip(store.chatSubjectId == s.id, { store.chatSubjectId = s.id }, { Text(s.name) }) }
                        }
                        if (store.chatSubjectId.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(store.chatWeek == 0, { store.chatWeek = 0 }, { Text(tr("All weeks", "كل الأسابيع")) })
                            (1..store.weeks).forEach { w -> FilterChip(store.chatWeek == w, { store.chatWeek = w }, { Text("$w") }) }
                        }
                    }
                }
            }
        }
        if (chat.isEmpty()) {
            val t = rememberInfiniteTransition(label = "float")
            val dy by t.animateFloat(-6f, 6f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "dy")
            Column(Modifier.weight(1f).fillMaxWidth().padding(28.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("✨", fontSize = 52.sp, modifier = Modifier.graphicsLayer { translationY = dy })
                Spacer(Modifier.height(10.dp))
                Serif(tr("Ask me anything", "اسألني أي شيء"), 22.sp, align = TextAlign.Center)
                Text(
                    tr("Math and chemistry show up as real equations. Pick what I can use above: your files, the internet, or both.",
                        "تظهر الرياضيات والكيمياء كمعادلات حقيقية. اختر ما يمكنني استخدامه بالأعلى: ملفاتك أو الإنترنت أو الاثنين."),
                    color = C.dim, textAlign = TextAlign.Center, fontSize = 13.sp
                )
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(chat, key = { it.id }) { e -> ChatBubble(store, e) }
            }
        }
        AnimatedVisibility(!busy && input.isBlank()) {
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                quick.forEach { (label, prompt) ->
                    Text(label, fontSize = 13.sp, color = C.accent,
                        modifier = Modifier.border(1.dp, C.accent.copy(alpha = 0.5f), RoundedCornerShape(18.dp)).pressClick { send(prompt) }.padding(horizontal = 14.dp, vertical = 8.dp))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                input, { input = it }, Modifier.weight(1f), shape = RoundedCornerShape(26.dp),
                placeholder = { Text(tr("Ask Scribe…", "اسأل Scribe…")) }, maxLines = 4, enabled = store.apiKey.isNotBlank()
            )
            Box(
                Modifier.size(50.dp).background(if (input.isNotBlank()) C.accent else C.dim.copy(alpha = 0.25f), CircleShape).pressClick { send(input) },
                contentAlignment = Alignment.Center
            ) { Text("➤", color = C.onAccent, fontSize = 18.sp) }
        }
    }
}
