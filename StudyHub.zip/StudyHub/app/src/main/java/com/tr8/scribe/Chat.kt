package com.tr8.scribe

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Flashcards(cards: List<Pair<String, String>>) {
    var i by remember { mutableIntStateOf(0) }
    var flipped by remember { mutableStateOf(false) }
    val c = cards[i]
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(tr("Card ${i + 1} of ${cards.size} · tap to flip", "بطاقة ${i + 1} من ${cards.size} · اضغط للقلب"), fontSize = 12.sp, color = C.dim)
        Box(
            Modifier.fillMaxWidth().heightIn(min = 150.dp).background(if (flipped) C.accent else C.bg, RoundedCornerShape(16.dp))
                .clickable { flipped = !flipped }.padding(16.dp),
            contentAlignment = Alignment.Center
        ) { Serif(if (flipped) c.second else c.first, 16.sp, if (flipped) C.onAccent else C.text, align = TextAlign.Center) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { if (i > 0) { i--; flipped = false } }, enabled = i > 0) { Text(tr("‹ Prev", "السابق")) }
            OutlinedButton(onClick = { if (i < cards.size - 1) { i++; flipped = false } }, enabled = i < cards.size - 1) { Text(tr("Next ›", "التالي")) }
        }
    }
}

@Composable
fun ChatBubble(store: Store, e: Entry) {
    val ctx = LocalContext.current
    if (e.role == "user") {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
            Text(e.text, color = C.onAccent, fontSize = 14.sp,
                modifier = Modifier.widthIn(max = 300.dp).background(C.accent, RoundedCornerShape(16.dp)).padding(12.dp))
        }
        return
    }
    var saved by remember(e.id) { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth().background(C.card, RoundedCornerShape(16.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (e.title.isNotEmpty() && e.action != "chat") Text(e.title, fontSize = 12.sp, color = C.gold)
        when (e.status) {
            "queued" -> Text(tr("⏳ Waiting to start…", "⏳ في الانتظار…"), color = C.dim, fontSize = 14.sp)
            "running" -> {
                val live = store.live[e.id] ?: ""
                if (live.isEmpty()) {
                    LinearProgressIndicator(Modifier.fillMaxWidth(), color = C.accent)
                    Text(tr("Thinking… you can leave the app, Scribe will notify you.", "جارٍ التفكير… يمكنك مغادرة التطبيق وسيصلك إشعار."), color = C.dim, fontSize = 12.sp)
                } else Text(live, fontSize = 14.sp, color = C.text)
            }
            "failed" -> {
                Text(e.text, color = C.rose, fontSize = 14.sp)
                OutlinedButton(onClick = { store.retry(e.id); startWork(ctx) }) { Text(tr("↻ Retry", "↻ إعادة المحاولة")) }
            }
            else -> {
                val cards = if (e.action == "cards") Ai.parseCards(e.text) else emptyList()
                if (cards.isNotEmpty()) Flashcards(cards) else SelectionContainer { Text(e.text, fontSize = 14.sp, color = C.text) }
                if (e.subjectId.isNotEmpty() && e.action != "chat") {
                    OutlinedButton(enabled = !saved, onClick = {
                        val k = noteKey(e.subjectId, e.week, e.kind)
                        val old = store.data.notes[k] ?: ""
                        store.setNote(k, (if (old.isBlank()) "" else "$old\n\n") + e.text)
                        saved = true
                        Toast.makeText(ctx, "✓", Toast.LENGTH_SHORT).show()
                    }) { Text(if (saved) tr("Saved ✓", "تم الحفظ ✓") else tr("Save to notes", "حفظ في الملاحظات")) }
                }
            }
        }
    }
}

@Composable
fun ChatTab(store: Store) {
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    val chat = store.data.chat.sortedBy { it.ts }
    val listState = rememberLazyListState()
    val mode = store.chatMode
    val attach = if (mode == "online" || store.chatSubjectId.isEmpty()) emptyList() else store.chatFiles(store.chatSubjectId, store.chatWeek)
    val noKey = tr("Add your free Gemini key in Settings first.", "أضف مفتاح Gemini المجاني من الإعدادات أولاً.")

    LaunchedEffect(chat.size) { if (chat.isNotEmpty()) listState.animateScrollToItem(chat.size - 1) }

    fun send() {
        val t = input.trim()
        if (t.isEmpty()) return
        if (store.apiKey.isBlank()) { Toast.makeText(ctx, noKey, Toast.LENGTH_LONG).show(); return }
        store.enqueueChat(t, mode, attach.map { it.id }, store.chatSubjectId)
        input = ""
        startWork(ctx)
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(store, tr("Ask AI", "المساعد"))
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("local" to tr("📁 My files", "📁 ملفاتي"), "online" to tr("🌐 Online", "🌐 الإنترنت"), "both" to tr("✨ Both", "✨ الاثنان")).forEach { (m, label) ->
                    FilterChip(mode == m, { store.chatMode = m; store.saveSettings() }, { Text(label) })
                }
                if (chat.isNotEmpty()) TextButton(onClick = { store.clearChat() }) { Text(tr("Clear", "مسح"), color = C.rose) }
            }
            if (mode != "online") {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(store.chatSubjectId.isEmpty(), { store.chatSubjectId = "" }, { Text(tr("No files", "بدون ملفات")) })
                    store.data.subjects.forEach { s -> FilterChip(store.chatSubjectId == s.id, { store.chatSubjectId = s.id }, { Text(s.name) }) }
                }
                if (store.chatSubjectId.isNotEmpty()) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(store.chatWeek == 0, { store.chatWeek = 0 }, { Text(tr("All weeks", "كل الأسابيع")) })
                        (1..store.weeks).forEach { w -> FilterChip(store.chatWeek == w, { store.chatWeek = w }, { Text("$w") }) }
                    }
                    Text(tr("${attach.size} file(s) will be sent with your message (max 6).", "سيتم إرسال ${attach.size} ملف(ات) مع رسالتك (الحد 6)."), fontSize = 11.sp, color = C.dim)
                }
            }
        }
        if (chat.isEmpty()) {
            Column(Modifier.weight(1f).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("✨", fontSize = 40.sp)
                Text(tr("Ask me anything about your studies. Choose what I can use above: your files, the internet, or both. Long requests run in the background and I'll notify you.",
                    "اسألني أي شيء عن دراستك. اختر ما يمكنني استخدامه بالأعلى: ملفاتك أو الإنترنت أو الاثنين. الطلبات الطويلة تعمل في الخلفية وسأرسل لك إشعاراً."),
                    color = C.dim, textAlign = TextAlign.Center, fontSize = 14.sp)
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(chat, key = { it.id }) { e -> ChatBubble(store, e) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text(tr("Ask Scribe…", "اسأل Scribe…")) }, maxLines = 4)
            Button(onClick = { send() }, enabled = input.isNotBlank()) { Text(tr("Send", "إرسال")) }
        }
    }
}
