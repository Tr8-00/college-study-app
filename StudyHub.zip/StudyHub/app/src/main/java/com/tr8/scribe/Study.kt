package com.tr8.scribe

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
private fun Header(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text(tr("‹ Back", "رجوع ›"), color = C.accent) }
        Serif(title, 22.sp, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun SubjectScope(store: Store, selected: String, allowAll: Boolean = true, onSelect: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (allowAll) FilterChip(selected.isEmpty(), { onSelect("") }, { Text(tr("All subjects", "كل المواد")) })
        store.data.subjects.forEach { s -> FilterChip(selected == s.id, { onSelect(s.id) }, { Text(s.name) }) }
    }
}

@Composable
private fun Hint(text: String) {
    Text(text, fontSize = 13.sp, color = C.dim, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
}

@Composable
fun StudyTab(store: Store) {
    var screen by remember { mutableStateOf("home") }
    BackHandler(enabled = screen != "home") { screen = "home" }
    AnimatedContent(
        targetState = screen,
        transitionSpec = { (fadeIn(tween(240)) + slideInVertically(tween(260)) { it / 16 }) togetherWith fadeOut(tween(120)) },
        label = "study"
    ) { s ->
        when (s) {
            "home" -> StudyHome(store) { screen = it }
            "search" -> SearchScreen(store) { screen = "home" }
            "cards" -> CardsScreen(store) { screen = "home" }
            "quiz" -> QuizScreen(store) { screen = "home" }
            "summary" -> SummaryScreen(store) { screen = "home" }
            "exam" -> ExamScreen(store) { screen = "home" }
            "track" -> TrackerScreen(store) { screen = "home" }
            else -> Column(Modifier.fillMaxSize()) {
                Header(tr("Files", "الملفات")) { screen = "home" }
                FilesTab(store)
            }
        }
    }
}

@Composable
private fun StudyTile(modifier: Modifier, icon: String, title: String, desc: String, onClick: () -> Unit) {
    Column(modifier.pressClick(onClick).background(C.card, RoundedCornerShape(20.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(icon, fontSize = 26.sp)
        Serif(title, 16.sp)
        Text(desc, fontSize = 11.sp, color = C.dim)
    }
}

@Composable
private fun StudyHome(store: Store, go: (String) -> Unit) {
    val ar = store.lang == "ar"
    val due = store.dueCount()
    val streak = store.streak()
    val todo = StudyKit.todo(store, 4)
    val tiles = listOf(
        listOf("search", "🔎", tr("Search my files", "ابحث في ملفاتي"), tr("Find any word, with the page", "اعثر على أي كلمة مع رقم الصفحة")),
        listOf("cards", "🃏", tr("Flashcards", "بطاقات"), tr("Made from your files, spaced repetition", "من ملفاتك مع التكرار المتباعد")),
        listOf("quiz", "📝", tr("Quiz", "اختبار"), tr("Multiple choice from your notes", "اختيار من متعدد من ملاحظاتك")),
        listOf("summary", "📚", tr("Smart summary", "ملخص ذكي"), tr("Key points, glossary, formulas", "أهم النقاط والمصطلحات والمعادلات")),
        listOf("exam", "🧾", tr("Exam sheet", "ورقة المراجعة"), tr("Everything for one subject", "كل شيء لمادة واحدة")),
        listOf("track", "✅", tr("Study tracker", "متابعة المذاكرة"), tr("What you reviewed", "ما راجعته")),
        listOf("files", "📁", tr("Manage files", "إدارة الملفات"), tr("Rename and organize", "إعادة التسمية والتنظيم"))
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar(store, tr("Study", "المذاكرة"))
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Panel(tr("Today", "اليوم"), C.gold) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("🃏 $due " + tr("cards due", "بطاقة مستحقة"), fontSize = 16.sp, color = C.text)
                        Text("🔥 $streak " + tr("day streak", "أيام متتالية"), fontSize = 13.sp, color = C.dim)
                    }
                    Button(onClick = { go("cards") }) { Text(tr("Review", "راجع")) }
                }
                if (todo.isNotEmpty()) {
                    Text(tr("To review next:", "للمراجعة بعد ذلك:"), fontSize = 12.sp, color = C.dim)
                    todo.forEach { (s, w, k) -> Text("• ${s.name} · ${kindLabel(k, ar)} · " + tr("Week $w", "الأسبوع $w"), fontSize = 13.sp, color = C.text) }
                }
            }
            Text(tr("All of these work on your phone, with no AI, no internet and no limits.", "كلها تعمل على هاتفك بدون ذكاء اصطناعي أو إنترنت أو حدود."), fontSize = 12.sp, color = C.dim)
            tiles.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { t -> StudyTile(Modifier.weight(1f), t[1], t[2], t[3]) { go(t[0]) } }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

/* ---------------- search ---------------- */

private fun highlight(text: String, terms: List<String>, color: Color): AnnotatedString = buildAnnotatedString {
    val low = text.lowercase()
    var i = 0
    while (i < text.length) {
        var best = -1
        var bl = 0
        for (t in terms) {
            val at = low.indexOf(t, i)
            if (at >= 0 && (best < 0 || at < best)) { best = at; bl = t.length }
        }
        if (best < 0) { append(text.substring(i)); break }
        var end = minOf(text.length, best + bl)
        while (end < text.length && text[end].isLetterOrDigit()) end++
        append(text.substring(i, best))
        withStyle(SpanStyle(color = color, fontWeight = FontWeight.Bold)) { append(text.substring(best, end)) }
        i = end
    }
}

@Composable
private fun SearchScreen(store: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    var sub by remember { mutableStateOf("") }
    val hits by produceState<List<Hit>>(emptyList(), q, sub) {
        delay(250)
        value = if (q.isBlank()) emptyList() else withContext(Dispatchers.Default) { StudyKit.search(store, q, sub) }
    }
    val ts = remember(q) { StudyKit.terms(q) }
    val ideas = remember(store.data.items.size, store.scanning) { store.data.items.mapNotNull { store.loadScan(it.id) }.flatMap { it.keywords.take(3) }.distinct().take(14) }
    val pageWord = tr("page", "صفحة")
    val accent = C.accent
    Column(Modifier.fillMaxSize()) {
        Header(tr("Search my files", "ابحث في ملفاتي"), onBack)
        OutlinedTextField(
            q, { q = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp), singleLine = true, shape = RoundedCornerShape(26.dp),
            placeholder = { Text(tr("Type a word or a question…", "اكتب كلمة أو سؤالاً…")) }
        )
        Spacer(Modifier.height(8.dp))
        SubjectScope(store, sub) { sub = it }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (q.isBlank()) item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (ideas.isEmpty()) Text(tr("Add files and tap 🔎 Scan on them, then search across all of them here.", "أضف ملفات واضغط 🔎 فحص عليها ثم ابحث فيها كلها من هنا."), color = C.dim, fontSize = 13.sp)
                    else {
                        Text(tr("Try one of these:", "جرّب إحداها:"), color = C.dim, fontSize = 12.sp)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ideas.forEach { w -> FilterChip(false, { q = w }, { Text(w) }) }
                        }
                    }
                }
            } else if (hits.isEmpty()) item { Text(tr("No matches yet. Try another word.", "لا نتائج. جرّب كلمة أخرى."), color = C.dim, fontSize = 13.sp) }
            items(hits) { h ->
                Column(
                    Modifier.fillMaxWidth().pressClick {
                        val item = store.data.items.firstOrNull { it.id == h.itemId }
                        if (item != null) { store.openFile(item); Toast.makeText(ctx, "$pageWord ${h.page}", Toast.LENGTH_LONG).show() }
                    }.background(C.card, RoundedCornerShape(16.dp)).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(h.title, fontSize = 14.sp, color = C.text, fontWeight = FontWeight.Medium)
                    Text(h.place + (if (h.page > 0) " · $pageWord ${h.page}" else ""), fontSize = 11.sp, color = C.gold)
                    Text(highlight(h.snippet, ts, accent), fontSize = 13.sp, color = C.dim)
                }
            }
        }
    }
}

/* ---------------- flashcards (spaced repetition) ---------------- */

@Composable
private fun CardsScreen(store: Store, onBack: () -> Unit) {
    var sub by remember { mutableStateOf("") }
    val cards by produceState<List<StudyCard>>(emptyList(), sub, store.data.items.size, store.scanning) {
        value = withContext(Dispatchers.Default) { StudyKit.cards(store, sub) }
    }
    val today = store.today()
    val due = cards.filter { (store.sr[it.id]?.due ?: Long.MAX_VALUE) <= today }
    val fresh = cards.filter { it.id !in store.sr }
    var queue by remember { mutableStateOf<List<StudyCard>>(emptyList()) }
    var running by remember { mutableStateOf(false) }
    var shown by remember { mutableStateOf(false) }
    var reviewed by remember { mutableIntStateOf(0) }
    var again by remember { mutableIntStateOf(0) }

    fun grade(g: Int) {
        val c = queue.firstOrNull() ?: return
        store.srReview(c.id, g)
        reviewed++
        if (g == 0) again++
        queue = queue.drop(1) + (if (g == 0) listOf(c) else emptyList())
        shown = false
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header(tr("Flashcards", "بطاقات"), onBack)
        if (!running) {
            SubjectScope(store, sub) { sub = it }
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Panel(tr("Your deck", "مجموعتك")) {
                    Text("🃏 ${cards.size} " + tr("cards made from your files", "بطاقة من ملفاتك"), fontSize = 15.sp, color = C.text)
                    Text("⏰ ${due.size} " + tr("due today", "مستحقة اليوم") + "   ✨ ${fresh.size} " + tr("new", "جديدة"), fontSize = 13.sp, color = C.dim)
                    Text("🔥 ${store.streak()} " + tr("day streak", "أيام متتالية"), fontSize = 13.sp, color = C.dim)
                }
                if (cards.isEmpty()) Text(tr("No cards yet. Add PDFs, slides or Word files to a subject and tap 🔎 Scan on them. Scribe turns the definitions, laws and formulas it finds into cards.", "لا توجد بطاقات بعد. أضف ملفات PDF أو شرائح أو Word إلى مادة واضغط 🔎 فحص. يحوّل Scribe التعريفات والقوانين والمعادلات إلى بطاقات."), fontSize = 13.sp, color = C.dim)
                else Button(
                    enabled = due.isNotEmpty() || fresh.isNotEmpty(),
                    onClick = { queue = due.shuffled() + fresh.shuffled().take(15); running = true; shown = false; reviewed = 0; again = 0 }
                ) { Text(tr("Start reviewing", "ابدأ المراجعة")) }
                if (cards.isNotEmpty() && due.isEmpty() && fresh.isEmpty()) Text(tr("🎉 All caught up. Come back tomorrow.", "🎉 أنهيت كل شيء. عد غداً."), color = C.accent, fontSize = 14.sp)
            }
        } else if (queue.isEmpty()) {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("🎉", fontSize = 48.sp)
                Serif(tr("Session done", "انتهت الجلسة"), 22.sp)
                Text(tr("Reviewed $reviewed · repeated $again", "راجعت $reviewed · أعدت $again"), color = C.dim)
                Text("🔥 ${store.streak()} " + tr("day streak", "أيام متتالية"), color = C.gold)
                Button(onClick = { running = false }) { Text(tr("Done", "تم")) }
            }
        } else {
            val c = queue.first()
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                LinearProgressIndicator(
                    progress = { reviewed.toFloat() / (reviewed + queue.size).coerceAtLeast(1) }, color = C.accent, trackColor = C.dim.copy(alpha = 0.15f),
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                )
                Text("${queue.size} " + tr("left", "متبقية"), fontSize = 12.sp, color = C.dim)
                Column(
                    Modifier.fillMaxWidth().heightIn(min = 180.dp).background(C.card, RoundedCornerShape(22.dp)).border(1.dp, C.accent.copy(alpha = 0.4f), RoundedCornerShape(22.dp)).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MathView(c.front, cacheKey = "card|${c.id}|f")
                    AnimatedVisibility(shown) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            HorizontalDivider(color = C.dim.copy(alpha = 0.3f))
                            MathView(c.back, cacheKey = "card|${c.id}|b")
                        }
                    }
                }
                if (!shown) Button(onClick = { shown = true }, modifier = Modifier.fillMaxWidth()) { Text(tr("Show answer", "أظهر الإجابة")) }
                else Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { grade(0) }, Modifier.weight(1f)) { Text(tr("✗ Again", "✗ مرة أخرى"), fontSize = 13.sp) }
                    Button(onClick = { grade(1) }, Modifier.weight(1f)) { Text(tr("✓ Good", "✓ جيد"), fontSize = 13.sp) }
                    OutlinedButton(onClick = { grade(2) }, Modifier.weight(1f)) { Text(tr("⚡ Easy", "⚡ سهل"), fontSize = 13.sp) }
                }
            }
        }
    }
}

/* ---------------- quiz ---------------- */

@Composable
private fun QuizScreen(store: Store, onBack: () -> Unit) {
    var sub by remember { mutableStateOf("") }
    val cards by produceState<List<StudyCard>>(emptyList(), sub, store.data.items.size, store.scanning) {
        value = withContext(Dispatchers.Default) { StudyKit.cards(store, sub) }
    }
    val enough = remember(cards) { StudyKit.quiz(cards, 1).isNotEmpty() }
    var qs by remember { mutableStateOf<List<Q>>(emptyList()) }
    var idx by remember { mutableIntStateOf(0) }
    var picked by remember { mutableIntStateOf(-1) }
    var score by remember { mutableIntStateOf(0) }
    var started by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header(tr("Quiz", "اختبار"), onBack)
        if (!started) {
            SubjectScope(store, sub) { sub = it }
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(tr("Multiple-choice questions built from the definitions, laws and formulas found in your files.", "أسئلة اختيار من متعدد مبنية على التعريفات والقوانين والمعادلات في ملفاتك."), fontSize = 13.sp, color = C.dim)
                if (!enough) Text(tr("Not enough material yet. Scan more files (at least 4 definitions, laws or formulas).", "لا توجد مادة كافية بعد. افحص ملفات أكثر (٤ تعريفات أو قوانين أو معادلات على الأقل)."), fontSize = 13.sp, color = C.rose)
                Button(enabled = enough, onClick = { qs = StudyKit.quiz(cards, 10); idx = 0; picked = -1; score = 0; started = true }) { Text(tr("Start (10 questions)", "ابدأ (١٠ أسئلة)")) }
            }
        } else if (idx >= qs.size) {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(if (score * 100 / qs.size.coerceAtLeast(1) >= 70) "🎉" else "💪", fontSize = 48.sp)
                Serif("$score / ${qs.size}", 30.sp, C.accent)
                Text(tr("Missed questions were added to your flashcards for review.", "أُضيفت الأسئلة التي أخطأت فيها إلى بطاقاتك للمراجعة."), fontSize = 13.sp, color = C.dim, textAlign = TextAlign.Center)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { qs = StudyKit.quiz(cards, 10); idx = 0; picked = -1; score = 0 }) { Text(tr("Try again", "حاول مجدداً")) }
                    OutlinedButton(onClick = { started = false }) { Text(tr("Done", "تم")) }
                }
            }
        } else {
            val q = qs[idx]
            val md = q.prompt + "\n\n" + q.options.mapIndexed { i, o -> "**" + ('A' + i) + ".** " + o }.joinToString("\n\n")
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(tr("Question ${idx + 1} of ${qs.size}", "السؤال ${idx + 1} من ${qs.size}"), fontSize = 12.sp, color = C.dim)
                Serif(if (q.kind == "formula") tr("Complete the formula", "أكمل المعادلة") else tr("Which term fits the blank?", "أي مصطلح يناسب الفراغ؟"), 18.sp, C.accent)
                Column(Modifier.fillMaxWidth().background(C.card, RoundedCornerShape(18.dp)).padding(14.dp)) {
                    MathView(md, cacheKey = "q|${q.cardId}|$idx")
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    q.options.indices.forEach { i ->
                        val good = picked >= 0 && i == q.answer
                        val bad = picked == i && i != q.answer
                        Button(
                            onClick = { picked = i; if (i == q.answer) score++ else store.srReview(q.cardId, 0) },
                            enabled = picked < 0 || good || bad, modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (good) C.accent else if (bad) C.rose else C.card,
                                contentColor = if (good || bad) C.onAccent else C.text, disabledContainerColor = if (good) C.accent else if (bad) C.rose else C.card,
                                disabledContentColor = if (good || bad) C.onAccent else C.dim
                            )
                        ) { Text(('A' + i).toString()) }
                    }
                }
                AnimatedVisibility(picked >= 0) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(if (picked == q.answer) tr("✓ Correct!", "✓ صحيح!") else tr("✗ Not quite. The answer is ${'A' + q.answer}.", "✗ ليس تماماً. الإجابة ${'A' + q.answer}."), color = if (picked == q.answer) C.accent else C.rose, fontSize = 15.sp)
                        Column(Modifier.fillMaxWidth().background(C.card, RoundedCornerShape(14.dp)).padding(12.dp)) { MathView(q.explain, cacheKey = "e|${q.cardId}|$idx") }
                        Button(onClick = { idx++; picked = -1 }, modifier = Modifier.fillMaxWidth()) { Text(if (idx + 1 < qs.size) tr("Next", "التالي") else tr("See score", "اعرض النتيجة")) }
                    }
                }
            }
        }
    }
}

/* ---------------- smart summary ---------------- */

@Composable
private fun SummaryScreen(store: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val ar = store.lang == "ar"
    var sub by remember { mutableStateOf("") }
    var itemId by remember { mutableStateOf("") }
    var section by remember { mutableStateOf("summary") }
    val files = store.data.items.filter { (sub.isEmpty() || it.subjectId == sub) && it.name.substringAfterLast('.', "").lowercase() in TEXT_EXTS }
    val item = store.data.items.firstOrNull { it.id == itemId }
    LaunchedEffect(itemId) { if (item != null && store.loadScan(item.id) == null) store.scanItem(item, false) }
    val md by produceState("", itemId, section, store.lang, store.scanning) {
        value = if (item == null) "" else withContext(Dispatchers.Default) { StudyKit.summary(store, item, ar, section) }
    }
    val copied = tr("Copied", "تم النسخ")
    val savedMsg = tr("Saved to this week's notes", "تم الحفظ في ملاحظات هذا الأسبوع")

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header(tr("Smart summary", "ملخص ذكي"), onBack)
        if (item == null) {
            SubjectScope(store, sub) { sub = it }
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (files.isEmpty()) Text(tr("Add a PDF, slides or Word file to a subject first.", "أضف ملف PDF أو شرائح أو Word إلى مادة أولاً."), fontSize = 13.sp, color = C.dim)
                files.forEach { f ->
                    val s = store.data.subjects.firstOrNull { it.id == f.subjectId }
                    Column(Modifier.fillMaxWidth().pressClick { itemId = f.id; section = "summary" }.background(C.card, RoundedCornerShape(14.dp)).padding(12.dp)) {
                        Text(f.name, fontSize = 14.sp, color = C.text)
                        Text((s?.name ?: "?") + " · " + kindLabel(f.kind, ar) + " · " + tr("Week ${f.week}", "الأسبوع ${f.week}"), fontSize = 11.sp, color = C.dim)
                    }
                }
            }
        } else {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(item.name, fontSize = 13.sp, color = C.gold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("summary" to tr("Summary", "ملخص"), "glossary" to tr("Glossary", "مصطلحات"), "formulas" to tr("Formulas", "معادلات"), "questions" to tr("Questions", "أسئلة")).forEach { (k, label) ->
                        FilterChip(section == k, { section = k }, { Text(label) })
                    }
                }
                if (item.id in store.scanning || (md.isEmpty() && store.loadScan(item.id) == null)) {
                    LinearProgressIndicator(Modifier.fillMaxWidth(), color = C.accent)
                    Text(tr("Reading your file…", "جارٍ قراءة ملفك…"), fontSize = 12.sp, color = C.dim)
                } else if (store.loadScan(item.id)?.scanned == true) {
                    Text(tr("This looks like a scanned PDF with no readable text.", "يبدو أن هذا PDF ممسوح ولا يحتوي على نص مقروء."), color = C.rose, fontSize = 13.sp)
                } else {
                    Column(Modifier.fillMaxWidth().background(C.card, RoundedCornerShape(18.dp)).padding(14.dp)) { MathView(md, cacheKey = "sum|${item.id}|$section") }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { clipboard.setText(AnnotatedString(md)); Toast.makeText(ctx, copied, Toast.LENGTH_SHORT).show() }) { Text(tr("📋 Copy", "📋 نسخ"), fontSize = 12.sp) }
                        OutlinedButton(onClick = {
                            val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, md) }
                            ctx.startActivity(Intent.createChooser(i, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }) { Text(tr("↗ Share", "↗ مشاركة"), fontSize = 12.sp) }
                        OutlinedButton(onClick = {
                            val k = noteKey(item.subjectId, item.week, item.kind)
                            val old = store.data.notes[k] ?: ""
                            store.setNote(k, (if (old.isBlank()) "" else "$old\n\n") + md)
                            Toast.makeText(ctx, savedMsg, Toast.LENGTH_SHORT).show()
                        }) { Text(tr("💾 Notes", "💾 ملاحظات"), fontSize = 12.sp) }
                    }
                }
                TextButton(onClick = { itemId = "" }) { Text(tr("‹ Choose another file", "‹ اختر ملفاً آخر"), color = C.accent) }
            }
        }
    }
}

/* ---------------- exam sheet ---------------- */

@Composable
private fun ExamScreen(store: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val ar = store.lang == "ar"
    var sub by remember { mutableStateOf("") }
    var weeks by remember { mutableStateOf(setOf<Int>()) }
    val weeksWith = store.data.items.filter { it.subjectId == sub }.map { it.week }.distinct().sorted()
    val md by produceState("", sub, weeks, store.data.items.size, store.scanning, store.lang) {
        value = if (sub.isEmpty()) "" else withContext(Dispatchers.Default) { StudyKit.examSheet(store, sub, weeks, ar) }
    }
    val copied = tr("Copied", "تم النسخ")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header(tr("Exam sheet", "ورقة المراجعة"), onBack)
        SubjectScope(store, sub, allowAll = false) { sub = it; weeks = emptySet() }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (sub.isEmpty()) Text(tr("Pick a subject. Scribe gathers every formula, definition, law and example from its files on one page.", "اختر مادة. يجمع Scribe كل المعادلات والتعريفات والقوانين والأمثلة من ملفاتها في صفحة واحدة."), fontSize = 13.sp, color = C.dim)
            else {
                if (weeksWith.isNotEmpty()) {
                    Text(tr("Weeks to include (none = all):", "الأسابيع المضمّنة (لا شيء = الكل):"), fontSize = 12.sp, color = C.dim)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        weeksWith.forEach { w -> FilterChip(w in weeks, { weeks = if (w in weeks) weeks - w else weeks + w }, { Text("$w") }) }
                    }
                }
                if (md.isEmpty()) Text(tr("Nothing to show yet. Add files and tap 🔎 Scan on them.", "لا يوجد ما يُعرض بعد. أضف ملفات واضغط 🔎 فحص."), fontSize = 13.sp, color = C.rose)
                else {
                    Column(Modifier.fillMaxWidth().background(C.card, RoundedCornerShape(18.dp)).padding(14.dp)) { MathView(md, cacheKey = "exam|$sub|${weeks.sorted()}") }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { clipboard.setText(AnnotatedString(md)); Toast.makeText(ctx, copied, Toast.LENGTH_SHORT).show() }) { Text(tr("📋 Copy", "📋 نسخ")) }
                        OutlinedButton(onClick = {
                            val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, md) }
                            ctx.startActivity(Intent.createChooser(i, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }) { Text(tr("↗ Share", "↗ مشاركة")) }
                    }
                }
            }
        }
    }
}

/* ---------------- tracker ---------------- */

@Composable
private fun TrackerScreen(store: Store, onBack: () -> Unit) {
    val ar = store.lang == "ar"
    var total = 0
    var done = 0
    store.data.subjects.forEach { s -> KINDS.forEach { k ->
        store.data.items.filter { it.subjectId == s.id && it.kind == k }.map { it.week }.distinct().forEach { w ->
            total++
            if (StudyKit.doneKey(s.id, w, k) in store.data.done) done++
        }
    } }
    val frac by androidx.compose.animation.core.animateFloatAsState(if (total == 0) 0f else done.toFloat() / total, tween(700), label = "track")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header(tr("Study tracker", "متابعة المذاكرة"), onBack)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Panel(tr("Overall", "الإجمالي"), C.gold) {
                Text("$done / $total " + tr("weeks reviewed", "أسابيع تمت مراجعتها") + "   🔥 ${store.streak()}", fontSize = 14.sp, color = C.text)
                LinearProgressIndicator(progress = { frac }, color = C.accent, trackColor = C.dim.copy(alpha = 0.15f), modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)))
            }
            Text(tr("Tap a week to mark it reviewed. Only weeks with files can be marked.", "اضغط على أسبوع لتحديده كمُراجَع. يمكن تحديد الأسابيع التي بها ملفات فقط."), fontSize = 12.sp, color = C.dim)
            store.data.subjects.forEach { s ->
                val kinds = KINDS.filter { (it == "lecture" && s.lecture) || (it == "section" && s.section) || (it == "assignment" && s.assignment) || (it == "lab" && s.lab) }
                Panel(s.name) {
                    kinds.forEach { k ->
                        Text(kindLabel(k, ar), fontSize = 12.sp, color = C.dim)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            (1..store.weeks).forEach { w ->
                                val has = store.data.items.any { it.subjectId == s.id && it.kind == k && it.week == w }
                                val key = StudyKit.doneKey(s.id, w, k)
                                val isDone = key in store.data.done
                                Box(
                                    Modifier.size(34.dp).clip(RoundedCornerShape(10.dp))
                                        .background(if (isDone) C.accent else Color.Transparent)
                                        .border(1.dp, if (isDone) C.accent else if (has) C.accent.copy(alpha = 0.6f) else C.dim.copy(alpha = 0.2f), RoundedCornerShape(10.dp))
                                        .clickable(enabled = has) { store.toggleDone(key) },
                                    contentAlignment = Alignment.Center
                                ) { Text(if (isDone) "✓" else "$w", fontSize = 12.sp, color = if (isDone) C.onAccent else if (has) C.text else C.dim.copy(alpha = 0.4f)) }
                            }
                        }
                    }
                }
            }
            if (store.data.subjects.isEmpty()) Hint(tr("Add subjects and files first.", "أضف مواد وملفات أولاً."))
        }
    }
}
