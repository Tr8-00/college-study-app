package com.tr8.studyhub

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

val AI_MIMES = setOf("application/pdf", "image/png", "image/jpeg", "image/webp", "image/heic", "image/heif", "text/plain")

/** Talks to Google's Gemini API with the user's own free key. Runs only when a button is tapped. */
object Ai {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/"

    private fun call(key: String, path: String, body: String?): String {
        val c = URL(BASE + path).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 180000
        c.setRequestProperty("x-goog-api-key", key)
        if (body != null) {
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = try { JSONObject(text).getJSONObject("error").getString("message") } catch (e: Exception) { text.take(300) }
            throw Exception("Error $code: $msg")
        }
        return text
    }

    fun ask(key: String, model: String, prompt: String, file: File?, mime: String?): String {
        val parts = JSONArray().put(JSONObject().put("text", prompt))
        if (file != null && mime != null) {
            val b64 = Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
            parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", mime).put("data", b64)))
        }
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts))).toString()
        val res = JSONObject(call(key, "models/" + model.removePrefix("models/") + ":generateContent", body))
        val cand = res.optJSONArray("candidates")?.optJSONObject(0)
            ?: throw Exception("No answer came back (the request may have been blocked).")
        val ps = cand.optJSONObject("content")?.optJSONArray("parts") ?: throw Exception("The answer was empty.")
        return (0 until ps.length()).joinToString("") { ps.getJSONObject(it).optString("text") }
    }

    fun models(key: String): List<String> {
        val res = JSONObject(call(key, "models?pageSize=200", null))
        val arr = res.optJSONArray("models") ?: return emptyList()
        return (0 until arr.length()).map { arr.getJSONObject(it) }
            .filter { m ->
                val sm = m.optJSONArray("supportedGenerationMethods")
                sm != null && (0 until sm.length()).any { sm.getString(it) == "generateContent" }
            }
            .map { it.getString("name").removePrefix("models/") }
            .filter { n -> n.contains("flash") && listOf("image", "tts", "live", "audio", "robotics").none { n.contains(it) } }
            .sortedDescending()
    }

    fun clean(s: String): String = s.replace("**", "")
        .replace(Regex("(?m)^\\s*#+\\s*"), "")
        .replace(Regex("(?m)^\\s*\\*\\s+"), "• ")

    fun prompt(action: String, subject: String, week: Int, kind: String, extra: String): String {
        val what = when (kind) { "lecture" -> "lecture slides or notes"; "section" -> "section sheet or assignment"; else -> "lab notes" }
        val head = "You are a patient study assistant for a university engineering student. Subject: $subject. Week $week. " +
            "The attached file is $what. Use plain text only (no markdown symbols like ** or #). " +
            "Keep it clear and organized with short numbered sections. "
        val task = when (action) {
            "summary" -> "Extract: 1) the title and lessons covered, 2) key definitions, 3) laws, rules and theories, " +
                "4) every important formula with what each symbol means, 5) the examples and exercises given (brief), " +
                "6) what to memorize for the exam."
            "explain" -> "Explain the main ideas in very simple language with intuition and small examples, as if teaching " +
                "a classmate who missed the class. Point out common confusions."
            "solve" -> "For every question in the file: give the core idea, the best method, a step-by-step solution, " +
                "the final answer, and a common mistake to avoid. If a question is unclear or missing data, say so. " +
                "At the end, list concepts the student should know that the professor may not have explained."
            "quiz" -> "Create 8 practice questions (a mix of multiple choice and short answer) based only on this file, " +
                "then an answer key with brief explanations."
            "cards" -> "Create 12 flashcards covering the most important concepts and formulas. Use exactly this format " +
                "with a blank line between cards:\nQ: question\nA: answer"
            else -> "Answer this question using the file: $extra"
        }
        return head + task
    }

    fun parseCards(t: String): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        var q = ""
        var a = ""
        var inA = false
        for (raw in t.lines()) {
            val l = raw.trim()
            when {
                l.startsWith("Q:") || l.startsWith("Q.") -> {
                    if (q.isNotEmpty() && a.isNotEmpty()) out.add(q.trim() to a.trim())
                    q = l.drop(2); a = ""; inA = false
                }
                l.startsWith("A:") || l.startsWith("A.") -> { a = l.drop(2); inA = true }
                l.isNotEmpty() -> { if (inA) a += "\n" + l else if (q.isNotEmpty()) q += "\n" + l }
            }
        }
        if (q.isNotEmpty() && a.isNotEmpty()) out.add(q.trim() to a.trim())
        return out
    }
}
